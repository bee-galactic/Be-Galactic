<?php
#include "./ser-header_frames.php";
#include "./ser-header_links.php";
$doublequote='"';

/*---------------------------------------------------------------
include_pagelink_SEARCH.php

There are 2 files 
	include_pagelink_AUTHOR.php and 
	include_pagelink_SEARCH.php.

The files are similar, but the important difference is
the functions in include_pagelink_AUTHOR.php rely on passing 
the cgi value &rec= to construct the link built in go_to_page()
while
the functions in include_pagelink_SEARCH.php do not use &rec
because view_search_only.php and edit_search.php do not have
the &rec cgi variable.


The functions in the file include_pagelink_SEARCH.php are for 
	edit_search.php 
	view_search_only.php

The functions in the file include_pagelink_AUTHOR.php are for 
	view_author_title_index.php
	view_batch_select.php
	view_cart_index.php
	view_cart_display.php

function go_to_page (called by PageLinkTop and PageLinkBottom)
	When you click prev or next button, go_to_page is called.
function PageLinkTop()
	calls go_to_page()
function PageLinkBottom()
	calls go_to_page()

-----------------------------------------------------------------*/

?>

<script language="javascript">

function go_to_page(type,display_page_number,limitt,numhits,inc,dec,max) {

//alert("go_to_page: \ntype="+type+"\ndisplay_page_number="+display_page_number+"\nlimit="+limitt);
var INC = new Number(inc);
var DEC = new Number(dec);
var limit = new Number(limitt);
var str_limit = new String(limit);
var nh    = new Number(numhits);
var MAX = new Number(max);
var curr_page = new String(document.form_go_button.this_DPN.value);
//var curr_page = new String(display_page_number);
//var target_page = new Number(curr_page);
//var target_page = new Number(1);
var top_page = new Number(MAX);

var target_page = new Number(curr_page);

if (type=="next") {
    	//target_page++;
	target_page = target_page;
	INC=limit;
	DEC=0;
    	if (target_page > MAX) target_page=MAX;
}else if (type=="prev") {
    	//target_page--;
	target_page = target_page;
	INC=0;
	DEC=limit;
    	if (target_page < 1) target_page=1;
}else if (type=="stay") {
	target_page = target_page;
}

	/*
	alert("D. curr_page="+curr_page
	+"\nINC="+INC+"\nDEC="+DEC
	+"\ntarget_page="+target_page +"\ntype="+type);
	*/

target_page=target_page-1;/////FIVE STAR
var record_num = limit * target_page;
//if(!confirm("F. record_num="+record_num+"\ntarget_page="+target_page))return;
var str_record_num = new String(record_num);
/*
if(!confirm("SEARCH go_to_page: \ncurr_page="+curr_page+"\ntarget_page="+target_page+"\nrecord_num="+record_num
+"\nINC="+INC+"\nDEC="+DEC
+"\nlimit="+limit+"\nnumhits="+nh ))return;
*/
var LINK=new String(location.href);
var lnk=new String(location.href);
//alert ("location.href="+LINK);

//SEARCH
if (type=="stay") {
	lnk=lnk;
}else if (LINK.indexOf("this_page_pid_list")>-1) {
	//first page load treated differently
	lnk = LINK;
	lnk = lnk.substring(0,lnk.indexOf("&this_page_pid_list"));
	lnk = lnk.replace("%2c",",");
	lnk = lnk + "&rec="+record_num+"&inc="+INC+"&dec="+DEC;
}else{
	lnk = LINK;
        if(lnk.indexOf("&rec=")>-1 ){
	lnk = lnk.substr(0, lnk.indexOf("&rec=") ); //trim off location.href at "&rec="
	}
	lnk = lnk.replace("%2c",",");
	lnk = lnk + "&rec="+record_num+"&inc="+INC+"&dec="+DEC;
}

//if(!confirm ("FIRST SET SEARCH\n\nlocation.href="+LINK+"\n\nlnk="+lnk))return;

//alert ("go_to_page: 1 lnk="+lnk);
//alert ("document.pageformA.serid_list.value="+document.pageformA.serid_list.value);

var srh = new String(lnk);

srh = srh +"&serid_list="+document.formW.serid_list.value;


//lnk = lnk+srh;
//if(!confirm("LAST SEARCH \n\nlnk="+lnk+"\n\nsrh="+srh))return;

location.replace(srh);

} //end function go_to_page() 




</script>
<?php





function PageLinkTop()
{
//print "PageLinkTop() uses function go_to_page via form_go_button<br>";
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;


$MaxDisplayPageNumber=(int)($numhits/$lim)+1;

 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
	if($DisplayPageNumber>$MaxDisplayPageNumber){
		$DisplayPageNumber=$MaxDisplayPageNumber;
		}
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
	if($DisplayPageNumber<1){
		$DisplayPageNumber=1;
		}
 }

$max=$MaxDisplayPageNumber;



 $DisplayRecord=$rec+1;
 //print "before go_to_page: \$DisplayPageNumber=$DisplayPageNumber<br>";
 //print "before go_to_page: \$MaxDisplayPageNumber=$MaxDisplayPageNumber<br>";

 print "<div class=\"instruct2\">";


 //this form has to have the name form_go_button to match name on view_author_title_index
 //need because function go_to_page refers to some of these form elements
 print "<form name=\"form_go_button\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"hidden\" name=\"this_page\" value=\"\" >";

 if ($numhits>$lim)
  {
  print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        if ($rec!=0)
          {
        print "&nbsp;<input type=\"button\" name=\"link_back\" ";
print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$inc,$dec,$max)\" ";
        print " value=\"<< Back\" class=\"bluebutton100\" >";
        }
 } else {
   print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}

  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
        $chnk=$rec+$lim;
        if ($chnk > $numhits) $chnk=$numhits;
        print "$chnk of $numhits) ";

  if($rec<$numhits-$lim)
          {
        print "&nbsp;<input type=\"button\" name=\"link_next\" ";
print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$inc,$dec,$max)\" ";
        print " value=\"Next >>\" class=\"bluebutton100\" >";
    	}
        else 
	{
	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
     
 print "</form>";
 //print "after go_to_page: \$DisplayPageNumber=$DisplayPageNumber<br>";
 print "</div>";
}//end function PageLinkTop();



function PageLinkBottom()
{

//print "PageLinkBottom() uses function go_to_page via form_go_button<br>";

 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;
 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $DisplayRecord=$rec+1;

 print "<div class=\"instruct2\">";

 print "<form name=\"form_bottom_buttons\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"hidden\" name=\"this_page\" value=\"\" >";

 print "<br>";
 if ($numhits>$lim)
  {
  print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($rec!=0) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_back\" ";
	print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim)\" ";
 	print " value=\"<< Back\" class=\"bluebutton100\" >";
	}	
       else 
  	{
  	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
  	}
   }

  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
	$chnk=$rec+$lim;
	if ($chnk > $numhits) $chnk=$numhits;
	print "$chnk of $numhits) ";

  if($rec<$numhits-$lim) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_next\" ";
	print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim)\" ";
 	print " value=\"Next >>\" class=\"bluebutton100\" >";
        }
	else 
	{
	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
 print "</form>";
 print "</div>";
}//end function PageLinkBottom();





?>


