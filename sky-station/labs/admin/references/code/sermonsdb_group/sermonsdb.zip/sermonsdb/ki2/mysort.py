#mysort.py

#usage: python mysort.py input.txt
# input is a comma separated list of numbers
# input is in this directory

import sys, os

inputfile = sys.argv[1]
D = open(inputfile,'r')
Dall = D.read()
Dall = Dall.replace("\n",",")
D.close()
D = open(inputfile,'a')
D.write("\n---\n")

a = Dall.split(",")
b = []
i = 0
while i<len(a):
	D.write("a["+str(i)+"]="+a[i]+"\n")
	if len(a[i])<1:
		break
		#
		#
	a[i]=a[i].replace(" ","")
	if len(a[i]) ==1:
		a[i]='a0000'+a[i]
		#
		#
	if len(a[i])==2:
		a[i]='a000'+a[i]
		#
		#
	if len(a[i])==3:
		a[i]='a00'+a[i]
		#
		#
	if len(a[i])==4:
		a[i]='a0'+a[i]
		#
		#
	b.append(a[i])
	i = i+1
	#
	#
D.write("b=")
D.write(str(b))
b.sort()
D.write("\nafter b.sort() b=")
D.write(str(b))

c = ","
D.write("\nc=")
for item in b:
	c = c+", "+item
	#D.write(c)
	#D.write("\n")
	#
	#
c= c.replace(",,","")
c= c.replace("\n","")
c= c.replace("a0000","")
c= c.replace("a000","")
c= c.replace("a00","")
c= c.replace("a0","")
D.write("\nb=")
D.write(str(b))
D.write("\nc=")
D.write(c)
D.close()
print "end"
print sys.argv
print "result:\n"
print c
print "\n"
