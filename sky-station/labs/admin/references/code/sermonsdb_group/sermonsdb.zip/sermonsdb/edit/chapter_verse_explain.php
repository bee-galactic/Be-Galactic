<?php
#chapter_verse_explain.php
?>
<html>
<head><title>chapter_verse_explain</title>
<link rel="stylesheet" type="text/css" href="ser.css" />
<?php
include "include_standard2.php";
print $html_header;
print $html_header_closer;
?>
</head>
<body>
<div class=\"instruct\">
<table summary="" xbgcolor="a99999" bgcolor="ffffff" border="00" cellspacing="0" cellpadding="2" xwidth="740" width="720" name="first_upper">
<tr><td >
<font face="verdana" size="2" color="#000000">&nbsp;University of Tennessee  Digital Library</font>
<div>
<div class="info">
<div class="infotag">
Southern Manuscript Sermons before 1800:  A Bibliographic Database<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;edited by Michael A. Lofaro</div>
</div>
</div>
</td></tr>
<tr><td>
<table summary="" border="00" cellspacing="0" cellpadding="2" width="720" xwidth="640">
<tr><td align="left">
<div>
<div class="info">
<div class="infotag">
How to search Chapter and Verse for Biblical References in the Sermons Database
</div>
</div>
</div>
</td></tr>
<tr><td align="left" class="form2">
<br>&nbsp;<br>
To limit a search further within a Book of the Bible, first select the name of the book from the drop down menu, then manually insert chapter number(s), and verse number(s) in the "Book of Bible" input box at the left of the screen in one of the following ways:  
<p>
1)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For a Book whose name is abbreviated (such as Ex. for Exodus)-insert 1 space after the period and add the number of chapter followed by a comma, and then add 1 space and insert the number of the verse.  Numbers added must be in Arabic.  Example:  Ex. 20, 7
<p>
2)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For a Book whose name is not abbreviated (such as John)-insert 1 space after the name and add the number of chapter followed by a comma, and then add 1 space and insert the number of the verse.  Numbers added must be in Arabic.  Example:  John 16, 24
<p>
3)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For a Book whose abbreviation ends with a number (such as Ch.1 for the first Book of Chronicles)-insert a period immediately after the number of the Book.  Then insert 1 space after the period and add the number of chapter followed by a comma, and then add 1 space and insert the number of the verse.  Numbers added must be in Arabic.  Example:  Ch.1. 24, 15
<p>
4)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To search only by chapter, be sure to insert a comma after the chapter (Ec. 1, not Ec. 1).  Not using the comma to limit the search would yield references for Ec. Chapter 10, 11, 12, and 19 as well as 1.  If further limitation by verse is desired, place a semicolon after the verse number to insure similar accuracy.
<p>
Be sure not to add a space(s) at the end of the biblical reference that is being searched; doing so will prevent the search from yielding any entries.
<p>
Results are displayed below the menus and input boxes.
</td></tr></table>
</td></tr></table>

</div>

</body>
</html>
