<?php

/*
   getldapinfo.php
	 a function that accepts a netid and returns either an error 
	 or an array of  
	 lastname, fullname, email, affliation, local phone
	 
	 this makes a secure connection to the ldap server here at ut
	 you have to make sure you are using ssl on your pages to protect the 
	 form you get the netid from.
	 
	 20050705 Paul Cummins
	 UT Library Technology Services
	 -------------
*/
function GetLdapInfo($anetid)
{
global $ldapinfo;
// your servers host name
$server = "ldaps://ldap.utk.edu";
// the base dn of your ldap server
$dn1="dc=tennessee, dc=edu";
// using the user name that was obtained, check it against the ldap server
$uid=$anetid;
$pass='';
//$netid=$uid;
$auth = 0;
$ds=ldap_connect($server);
// must be a valid LDAP server!
if ($ds) // the server is there, try a bind
  { 
	// Successfully connected to server
  if ( ldap_bind($ds) )
    { 
    // Anonymous bind successful
    $sr=ldap_search($ds,$dn1, "uid=$uid");  
    if ( $info = ldap_get_entries($ds, $sr))
      {      
	    $i=0; 
      // Retrieving the dn as stored in LDAP
      $dn = $info[0]["dn"];
			//print "$dn<br />\n";
			$lastname = $info[$i]["sn"][0];
		  $fullname = $info[$i]["cn"][0];
		  $aff = $info[$i]["edupersonaffiliation"][0];
		  $useremail = $info[$i]["mail"][0];
		  $locph = $info[$i]["telephonenumber"][0];
			} // end of if info anonymous
		else
		  {
			$neterr="Invalid Net ID.";
			}	
		ldap_unbind($ds);
   }//end of if bind ds
	else
	 {
	 $neterr="Bind to ldap server failed.";
	 return $neterr;
	 }
	}
$ldapinfo=array("lastname"=>"$lastname","fullname"=>"$fullname","aff"=>"$aff","useremail"=>"$useremail","locph"=>"$locph");
}	// end function 
?>
