<html>
<head>
<title>shs</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shs";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- S</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Sacrament, Of the</option>
<option>Sacrament of penance, On the</option>
<option>Sacred Heart, On the</option>
<option>Sacred to the Memory of George Washington</option>
<option>Sacrifice made by Xt, On the</option>
<option>Sacrifice of Mass, Of ye</option>
<option>Safety & happiness of following that which is good, The</option>
<option>Safety & Security of upright walking, The</option>
<option>Salvation</option>
<option>Salvation, Of</option>
<option>Salvation, On</option>
<option>Salvation for the Righteous and Sinful, On the</option>
<option>Sanctity, On</option>
<option>Satisfaction made by Christ, On the</option>
<option>Scoffers, On</option>
<option>Scourging of Christ, On the</option>
<option>Scribes and Pharisees, On the</option>
<option>Scripture Doctrine of Regeneration, The</option>
<option>Search the Scriptures</option>
<option>Second Coming(1), On the</option>
<option>Second Coming(2), On the</option>
<option>Second Coming(3), On the</option>
<option>Second Coming, The</option>
<option>Second Commandment, On the</option>
<option>Secret Faults</option>
<option>Seed among Thorns, The</option>
<option>Seed by the Way-side, The</option>
<option>Seed in the good ground, The</option>
<option>Seed on the Rock, The</option>
<option>Seek the[e] first Kingdom of God</option>
<option>Seek ye first the Kingdom of God</option>
<option>Seek ye first the Kingdom of God--Sermon I</option>
<option>Seek ye first the Kingdom of God--Sermon II</option>
<option>Seek ye first the Kingdom of God & his Righteousness, But</option>
<option>Self-communion recommended</option>
<option>Self-deceit of the wicked</option>
<option>Self-examination, On</option>
<option>Self-love</option>
<option>Self-love, On</option>
<option>Serious Advice not to---</option>
<option>Sermon #14 from Psalm LXXIII. 25th, A</option>
<option>Sermon 1st from John 14 Ch 23 vs</option>
<option>Sermon 2d from 1st Tim 1st Ch & 15 vs</option>
<option>Sermon 2d from 2d Peter 3d Ch & 11 vs</option>
<option>Sermon 2d from Col 3d Ch 2, 3, 4 vs</option>
<option>Sermon 2d from Isai 26 Ch 8, 9 vs</option>
<option>Sermon 2d from John 14 Ch 23</option>
<option>Sermon 2d from John 3d Ch 3 & 5 vs</option>
<option>Sermon 2d from Luke 1st Ch 17 vs</option>
<option>Sermon 2d from Phillip 1, 27</option>
<option>Sermon 3d from John 3 Ch 3 & 5 vs</option>
<option>Sermon 3d from Luke 10 Ch 41, 42 vs</option>
<option>Sermon 4th from John 3 Ch 3 & 5 vs</option>
<option>Sermon 4th from Luke 10 Ch 41, 42 vs</option>
<option>Sermon 5 from John 3d Ch 3 & 5 vs</option>
<option>Sermon 7 from Titus 2, 11, 12</option>
<option>Sermon against slavery</option>
<option>Sermon at the opening of S. Annes Ch</option>
<option>Sermon before General Assembly in 1689</option>
<option>Sermon delivered at the Bank Meeting House, A</option>
<option>Sermon first from Isai 55 Ch 7 vs</option>
<option>Sermon for Christmas</option>
<option>Sermon for Easter</option>
<option>Sermon for the Anniversary of American Independence, A</option>
<option>Sermon for Whitsunday</option>
<option>Sermon for ye 6th Sunday after ye Epiphany, A</option>
<option>Sermon Fragments of Charles Clay</option>
<option>Sermon from 1 Ep John 1 & 7</option>
<option>Sermon from 1 Ep John 1 Ch & 7 vs lt pt</option>
<option>Sermon from 1st Ep Peter 1st Ch 6 & 7 vs</option>
<option>Sermon from 1st Tim 1st Ch & 15 vs</option>
<option>Sermon from 2d Peter 3d Ch & 11 vs</option>
<option>Sermon from Colos 3d Ch 2, 3, 4 vs</option>
<option>Sermon from Deut 5 ch 29 vs, A</option>
<option>sermon from deut 5 ch 29 vs, A 2d</option>
<option>Sermon from Deuteronomy, A</option>
<option>Sermon from Exod 20, 8 vs</option>
<option>Sermon from Ezek 33, 33</option>

<option>Sermon from Gal 5, 15</option>
<option>Sermon from Isai 26 Ch, 8, 9 vs, A</option>
<option>Sermon from Isai 53 ch & 5 vs, A</option>
<option>Sermon from Isai 66 & 2d</option>
<option>Sermon from Jerem 31 & 20</option>
<option>Sermon from Job 31 Ch & 6 vs, A</option>
<option>Sermon from John 14, 23</option>
<option>Sermon from John 3d Ch 3 & 5 vs</option>
<option>Sermon from John 4, 24</option>
<option>Sermon from John [14] Ch & 47 vs, A</option>
<option>Sermon from Luke 1st Ch 17 vs lt pt</option>
<option>Sermon from Matt 22 Ch & 4 vs., A</option>
<option>Sermon from Matt 22 Ch 4 vs., A</option>
<option>Sermon from Matt 4, 10</option>
<option>Sermon from Matthew 6, 33</option>
<option>Sermon from Phillip 1, 27</option>
<option>Sermon from Ps 103, 19</option>
<option>Sermon from Ps 116, 16 vs, A</option>
<option>Sermon from Ps 26 & 6</option>
<option>Sermon from Ps 39, 10, 11, 12 vs</option>
<option>Sermon from Psal 14 & 1</option>
<option>Sermon from Psalme 38 vs 18</option>
<option>Sermon from Rev 2, 17</option>
<option>Sermon from Rev 4 Ch 10 vs</option>
<option>Sermon from songs 8 ch & 2d vs, A</option>
<option>sermon from songs 8 ch & 2d vs, A 2d</option>
<option>Sermon notes on the books of Timothy</option>
<option>Sermon Notes on the Lord's Supper</option>
<option>Sermon ... the death of Deacon Thomas Quarterman</option>
<option>Sermon on 2 Cor. 4. 13</option>
<option>Sermon on Acts 2[4]. 25</option>
<option>Sermon on Acts X, 33</option>
<option>Sermon on Be not ashamed</option>
<option>Sermon on Easter</option>
<option>Sermon on Everlasting Life</option>
<option>Sermon on Godliness with Contentment, A</option>
<option>Sermon on Grace</option>
<option>Sermon on Hebrews 12th C & 14 V, A</option>
<option>Sermon on Isaiah XLIV: 5</option>
<option>Sermon on Judgment and the Jews</option>
<option>Sermon on Matthew 11, 28-30</option>
<option>Sermon on Prayer</option>
<option>Sermon on Psal. 118, 2d, A</option>
<option>Sermon on Romans 7th 18th, A</option>
<option>Sermon on St. Luke 22, 19 & 20</option>
<option>Sermon on the Advantages of Religion</option>
<option>Sermon on the Ascension</option>
<option>Sermon On the Constitution ... of the Christian Church</option>
<option>Sermon on The Creation of Man, A</option>
<option>Sermon on the death of Col. George Carrington</option>
<option>Sermon on the flesh and the spirit</option>
<option>Sermon on The Law of God, A</option>
<option>Sermon on the Lord's Supper</option>
<option>Sermon on The Love of God, A</option>
<option>Sermon on the married state</option>
<option>Sermon on the Nature of true Holiness, A</option>
<option>Sermon on the parable of the Rich Man and Lazarus</option>
<option>Sermon on the profanation of the name of God, A</option>
<option>Sermon on the Sacrament of the Lord's Supper</option>
<option>Sermon on the World</option>
<option>Sermon Preached at James City in Virginia, A</option>
<option>Sermon preached at New York</option>
<option>Sermon Preached at the Death of General Washington</option>
<option>Sermon Preached in Annapolis</option>
<option>Sermon preached in my own Parish Church, A</option>
<option>Sermon upon the decay of Christianity</option>
<option>Sermons, 1792-1802 [by Armistead Smith]</option>
<option>Sermons (1770) of an unidentified minister, Three</option>
<option>Sermons [by Archibald Simpson]</option>
<option>Sermons by Enoch Green</option>
<option>Sermons of Thomas Cradock</option>
<option>Sermons ... by the Rev. Paul Turquand, Volume I</option>
<option>Sermons ... by the Rev. Paul Turquand, Volume II</option>
<option>Sermons ... by the Rev. Paul Turquand, Volume III</option>
<option>Sermons preached after 1800 by John Durbarrow Blair</option>
<option>Sermons Vollume Thirteenth [by Archibald Simpson]</option>
<option>Serve the Lord with Gladness</option>
<option>Service of the Lord neither vain nor unprofitable, The</option>
<option>Serving God, On</option>
<option>Serving Two Masters, On</option>
<option>Set thine House in Order</option>
<option>Set your affection on things above</option>
<option>Seven Mss. Sermons Delivered [by Samuel Frink] ... Savannah</option>
<option>Seventeen Manuscript ... 1760-1804, [by Samuel Stillman]</option>
<option>Seventh Commandment, On the</option>
<option>Sexagesima Sunday, On</option>
<option>Shewing thyself a pattern of good works</option>
<option>Shine to enter at the strait Gate</option>
<option>Short Acct. ... Nature ... Conditions of the Baptismal Covenant</option>
<option>Short Discorce [sic] on the 14C. of Reveration [sic] & 13V, A</option>
<option>Sign of the Cross, On ye</option>
<option>Simeon's Apostrophe</option>
<option>Sin's Burdens and Christ's Yoke, On</option>
<option>Sin, On</option>
<option>Sin and the Follies of Youth</option>
<option>Sincere conversion, On</option>
<option>Sinners, their allurements to be guarded against</option>
<option>Sins of Infirmity</option>
<option>Sittensperger, see Manners</option>
<option>Sixth Article of the Creed, On the</option>
<option>Slavery to human respects, On</option>
<option>Slothful man & his lion, The</option>
<option>So shall he sprinkle many Nations</option>
<option>So then, after the Lord had spoken unto them</option>
<option>Son of God, The</option>
<option>Sorrow & heaviness of our Lord in Gethsemane, The</option>
<option>Sorrow & mourning become all</option>
<option>Souls rest, The</option>
<option>Sow to yourselves in Righteousness, reap in mercy</option>
<option>Speaking truth</option>
<option>Speedy Conversion, On</option>
<option>Spirit of the world, On the</option>
<option>Spirit of the World, The</option>
<option>Spirit preventeth the works of the flesh, The</option>
<option>Spiritual benefits, On</option>
<option>Spiritual blessings bestowed on man, On the</option>
<option>Spiritual or moral pride, On</option>
<option>Spiritual Vigilance</option>
<option>Spiritual Warfare, On</option>
<option>St. Francis Xavier, On</option>
<option>St. Ignatius' Feast, On</option>
<option>St. Ignatius, On</option>
<option>St. John Baptist, For</option>
<option>St. John the Baptist, On</option>
<option>St. Paul's Choice</option>
<option>St. Paul's Discourse to Felix</option>
<option>St. Paul before Felix, On</option>
<option>St Ignatius, On</option>
<option>St John</option>
<option>St John, Epistle 1: 3 Chapter, 8 Verse, On</option>
<option>St Peter's Denial of his Master, On</option>
<option>State between Death & the Resurrection, On a</option>
<option>State of Protestantism, On</option>
<option>State of the wicked considered, The</option>
<option>Steadfastness, On</option>
<option>Study to shew thyself approved unto God</option>
<option>Submission to ye will of god, On</option>
<option>Submitting to the Will of God, On</option>
<option>Substance of a Sermon, preached by Tho. Coke</option>
<option>Success of Xtianity an evidence of its truth, The</option>
<option>Sudden death, On</option>
<option>Suffering in this world, On</option>
<option>Summary of the arguments in favor of Christianity</option>
<option>Superior excellence of Christ's preaching, The</option>
<option>Superiority of the Gospel over Natural Religion, The</option>
<option>Suspension of Andrew Nugent, On the</option>
<option>Swearing, On</option>


<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
