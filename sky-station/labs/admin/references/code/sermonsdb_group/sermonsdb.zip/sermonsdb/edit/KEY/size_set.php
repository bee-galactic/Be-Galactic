<?php
#size_set.php


$menu_size="20";
$menu_size="14";
print "<select name=\"pselect\" id=\"id_pselect\" size=\"$menu_size\" onclick=\"pchange()\">";
?>
