<h5 align="right"></h5>
<?php
#-------------------begin with a line of php comment
?>
<script language="javascript">

//=============================begin functions for view_search_only.php
function my_edit_clear(){

//alert("my_edit_clear()");

submit_formEsearch(); //makes the page blink
//document.search_form.reset();
document.search_form.serid.value = "";
document.search_form.smarkov_key.value = "";
document.search_form.sacc.value = "";
document.search_form.snameauthor.value = "";
document.search_form.cetitle.value = "";
document.search_form.state.value = "";
document.search_form.denom.value = "";
document.search_form.CSDval.value = "";
document.search_form.stitle.value = "";
//document.search_form.sloc.value = "";
document.search_form.slibloc_code.value = "";
document.search_form.sibr.value = "";
document.search_form.sida.value = "";
document.search_form.skey.value = "";
document.search_form.scmt.value = "";
//document.search_form.sbr.value = "";

document.search_form.smarkov_key.value="nau";

document.all.CSD.innerHTML="Cover Entry Title";
}




function char_check(sbox) {
var s = new String(sbox.value);
var i = s.indexOf("'");
if ( i > -1 ) {
	sbox.value=s.replace("'","%");
	//sbox.value=s.replace("...","%");
	}
return;
}//end function

	

//============================end functions for view_search.php

//=============================begin functions for edit_search.php



//====================================================
//====================================================
//====================================================

var aCode = new Array();
var aLoc = new Array();
var aDet = new Array();

aCode[aCode.length++]="";aLoc[aLoc.length++]="";aDet[aDet.length++]="none"; 
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA"; 
aCode[aCode.length++]="??????";aLoc[aLoc.length++]="??????";aDet[aDet.length++]="none"; 
aCode[aCode.length++]="ViU";aLoc[aLoc.length++]="Albert H. Small Special Collections Library";aDet[aDet.length++]="University of Virginia"; 
aCode[aCode.length++]="Bodleian";aLoc[aLoc.length++]="Bodleian Library, Oxford University, Additional Manuscripts, A. 31; SUmm.  Cat. no. 30143;";aDet[aDet.length++]="Bodleian Library, University of Oxford, Oxford, Great Britain"; 
aCode[aCode.length++]="CSmH";aLoc[aLoc.length++]="CSmH;";aDet[aDet.length++]="Henry H. Huntington Library, San Marino, CA"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (John Gilmary Shea Papers);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives and Woodstock College Archives);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives);   ";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 1);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 13);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 15);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 18);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 19);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 2);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 20);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 22);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 24);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 25);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 27);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 28);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 29); ";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 3-a);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 3-b);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 30);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 31);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 32);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 33);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 34);";aDet[aDet.length++]="Georgetown University, Washington, DC"; 
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 38);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 39);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 4);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 41);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 42);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 43); ";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 44);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 45);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 47);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 48);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 49);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 5);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 50);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 51);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 52);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 6);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no. 7);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no.14);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no.17);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no.21);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no.26);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--no.45); ";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--nos. 37, 36 and Woodstock College Archives);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives--pp. 1-4) and (Woodstock College Archives--pp. 5-12);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives-no. 23);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives-no. 35);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Maryland Province Archives-no. 40);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Special Collections);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (University Archives);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Woodstock College Archives)";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Woodstock College Archives);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Woodstock College Archives); ";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DGU";aLoc[aLoc.length++]="DGU (Woodstock College Library);";aDet[aDet.length++]="Georgetown University, Washington, DC";  
aCode[aCode.length++]="DLC";aLoc[aLoc.length++]="DLC (Dawson Papers);";aDet[aDet.length++]="Library of Congress, Washington, DC";  
aCode[aCode.length++]="DLC";aLoc[aLoc.length++]="DLC (Dawson Papers, 2: 284-93);";aDet[aDet.length++]="Library of Congress, Washington, DC";  
aCode[aCode.length++]="NjR";aLoc[aLoc.length++]="Enoch Green Papers, Special Collections and University Archives, accession number 709.";aDet[aDet.length++]="Rutgers, The State University of New Jersey, New Brunswick, NJ";  
aCode[aCode.length++]="GU";aLoc[aLoc.length++]="GU (De Reune Collection);";aDet[aDet.length++]="University of Georgia, Athens, GA";  
aCode[aCode.length++]="MdDA";aLoc[aLoc.length++]="MdDA";aDet[aDet.length++]="F. Garner Ranney Archives of the Episcopal Diocese of Maryland, Baltimore, MD";  
aCode[aCode.length++]="MdDA.";aLoc[aLoc.length++]="MdDA.";aDet[aDet.length++]="F. Garner Ranney Archives of the Episcopal Diocese of Maryland, Baltimore, MD";  
aCode[aCode.length++]="MdDA";aLoc[aLoc.length++]="MdDA;";aDet[aDet.length++]="F. Garner Ranney Archives of the Episcopal Diocese of Maryland, Baltimore, MD";  
aCode[aCode.length++]="MdDA";aLoc[aLoc.length++]="MdDA; ";aDet[aDet.length++]="F. Garner Ranney Archives of the Episcopal Diocese of Maryland, Baltimore, MD";  
aCode[aCode.length++]="MdHi";aLoc[aLoc.length++]="MdHi;";aDet[aDet.length++]="Maryland Historical Society, Baltimore, MD";  
aCode[aCode.length++]="MdWC";aLoc[aLoc.length++]="MdWC;";aDet[aDet.length++]="Washington College, Chestertown, MD";  
aCode[aCode.length++]="MH-H";aLoc[aLoc.length++]="MH-H";aDet[aDet.length++]="Houghton Library, Harvard University, Cambridge, MA";  
aCode[aCode.length++]="MH-H";aLoc[aLoc.length++]="MH-H;";aDet[aDet.length++]="Houghton Library, Harvard University, Cambridge, MA";  
aCode[aCode.length++]="MHi";aLoc[aLoc.length++]="MHi (Ezra Stiles Collection of the Holmes Papers);";aDet[aDet.length++]="Massachusetts Historical Society, Boston, MA";  
aCode[aCode.length++]="MHi";aLoc[aLoc.length++]="MHi (Ezra Stiles Collection); ";aDet[aDet.length++]="Massachusetts Historical Society, Boston, MA";  
aCode[aCode.length++]="MHi";aLoc[aLoc.length++]="MHi;";aDet[aDet.length++]="Massachusetts Historical Society, Boston, MA";  
aCode[aCode.length++]="MNtcA";aLoc[aLoc.length++]="MNtcA;";aDet[aDet.length++]="Andover Newton Theological School Library, Newton Centre, MA";  
aCode[aCode.length++]="MWA";aLoc[aLoc.length++]="MWA;";aDet[aDet.length++]="American Antiquarian Society, Worcester, MA";  
aCode[aCode.length++]="Nc";aLoc[aLoc.length++]="Nc (State Archives); ";aDet[aDet.length++]="Department of Archives and History, North Carolina State Library, Raleigh, NC";  
aCode[aCode.length++]="Nc";aLoc[aLoc.length++]="Nc;";aDet[aDet.length++]="Department of Archives and History, North Carolina State Library, Raleigh, NC";  
aCode[aCode.length++]="NcD";aLoc[aLoc.length++]="NcD; ";aDet[aDet.length++]="Duke University, Durham, NC";  
aCode[aCode.length++]="NcD";aLoc[aLoc.length++]="NcD;";aDet[aDet.length++]="Duke University, Durham, NC";  
aCode[aCode.length++]="NcU";aLoc[aLoc.length++]="NcU (Southern Historical Collection);";aDet[aDet.length++]="University of North Carolina at Chapel Hill, Chapel Hill, NC";  
aCode[aCode.length++]="NcU";aLoc[aLoc.length++]="NcU;";aDet[aDet.length++]="Department of Archives and History, North Carolina State Library, Raleigh, NC";  
aCode[aCode.length++]="";aLoc[aLoc.length++]="No manuscript yet located.";aDet[aDet.length++]="none";  
aCode[aCode.length++]="Public Rec";aLoc[aLoc.length++]="Public Record Office, L. D. [library drawer?] S/718, folios 71-76.";aDet[aDet.length++]="none";  
aCode[aCode.length++]="ScHi";aLoc[aLoc.length++]="ScHi;";aDet[aDet.length++]="South Carolina Historical Society, Charleston, SC";  
aCode[aCode.length++]="ScU";aLoc[aLoc.length++]="ScU (South Caroliniana Library); ";aDet[aDet.length++]="University of South Carolina, Columbia, SC";  
aCode[aCode.length++]="ScU";aLoc[aLoc.length++]="ScU (South Caroliniana);";aDet[aDet.length++]="University of South Carolina, Columbia, SC";  
aCode[aCode.length++]="ScU";aLoc[aLoc.length++]="ScU;";aDet[aDet.length++]="University of South Carolina, Columbia, SC";  
aCode[aCode.length++]="NoCode";aLoc[aLoc.length++]="St. Thomas Parish, Baltimore County, MD";aDet[aDet.length++]="Stored in a repository with no library code.";  
aCode[aCode.length++]="Vi";aLoc[aLoc.length++]="Vi;";aDet[aDet.length++]="Virginia State Library, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay Family Papers, 1769-1951.  Mss1 C5795a, Sermons 12-13)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951.  Mss1 C5795a, Sermons, folder 6)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="";aLoc[aLoc.length++]="ViHi (Clay Family Papers, 1769-1951. Mss1 C5795a, Sermons 12-13)";aDet[aDet.length++]="none";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder )";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 12-13)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 14-15)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 16-17)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 18-19)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 20-21)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 22-23)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 24-25)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 26-27)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 28-29)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 30-31)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 32-33)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 34-35)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 36-37)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 38-39)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 40-41)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 42-43)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 44-45)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 46-47)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 48-49)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 50-51)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 52-53)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 54-55)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 56-57)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi (Clay family papers, 1769-1951. Mss1 C5795a, Sermons, folder 58-59)";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViHi";aLoc[aLoc.length++]="ViHi;";aDet[aDet.length++]="Virginia Historical Society, Richmond, VA";  
aCode[aCode.length++]="ViRU";aLoc[aLoc.length++]="ViRU (Virginia Baptist Historical Society);";aDet[aDet.length++]="Virginia Baptist Historical Society, at the University of Richmond, Richmond, VA";  
aCode[aCode.length++]="ViRUT";aLoc[aLoc.length++]="ViRUT;";aDet[aDet.length++]="Virginia Baptist Historical Society, at the University of Richmond, Richmond, VA";  
aCode[aCode.length++]="ViU";aLoc[aLoc.length++]="ViU";aDet[aDet.length++]="Virginia State Library, Richmond, VA";  
aCode[aCode.length++]="ViU";aLoc[aLoc.length++]="ViU;";aDet[aDet.length++]="University of Virginia, Charlottesville, VA";  
aCode[aCode.length++]="ViU";aLoc[aLoc.length++]="ViU;";aDet[aDet.length++]="Virginia State Library, Richmond, VA";  
aCode[aCode.length++]="ViWC";aLoc[aLoc.length++]="ViWC;";aDet[aDet.length++]="Colonial Williamsburg, Inc. Williamsburg, VA";  
/*090829
NjR_AAA_Enoch Green Papers, Special Collections and University Archives, accession number 709._BBB_Rutgers, The State University of New Jersey, New Brunswick, NJ
*/
aCode[aCode.length++]="NjR";aLoc[aLoc.length++]="Enoch Green Papers, Special Collections and University Archives, accession number 709.";aDet[aDet.length++]="Rutgers, The State University of New Jersey, New Brunswick, NJ";





//====================================================
//====================================================
//====================================================

	

function write_data_triplet(N) {
//document.forms[13].name=edit_form_1815
var pid = new String(N);
var formname = new String(document.forms[13].name);

var formvar = new String("document."+formname+".slibloc_code_select");
var LEN = eval(formvar+".length");
//alert("write_data_triplet("+N+") -- formvar.length: LEN="+LEN); //25
//alert("aCode.length="+aCode.length); //129

/**/
//from loc.php
var save_i=0;
var save_j=0;
for ( i=0; i< LEN; i++ ) {
	var TF = eval(formvar+"[i].selected");
        //if (formvar[i].selected == true ) {
	if (TF == true){
                sText = eval(formvar+"[i].value");
		//alert("sText="+sText+"\ni="+i);
		save_i=i;
                break;
                }//end if
        }//end for

for (j=0;j<aCode.length;j++){
	if(aCode[j]==sText){
		save_j=j;
		break;
		}//end if
	}//end for
/**/
var detail_msg=new String(" ");
var count_detail=0;
for (k=0;k<aCode.length;k++){
	if(aCode[k]==sText){
		detail_msg+=aLoc[k]+"<br>";
		count_detail++;
		}//end if
	}//end for
/**/

document.forms[13].edit_loc_code.value=aCode[save_j];
document.forms[13].edit_loc.value=aLoc[save_j];
document.forms[13].edit_loc_repository.value=aDet[save_j];

/*
alert("aCode["+save_j+"]="+aCode[save_j]
   +"\n aLoc["+save_j+"]="+aLoc[save_j]
   +"\n aDet["+save_j+"]="+aDet[save_j]
   +"\n sText="+sText
   +"\n\n detail_msg:\n"+detail_msg
);
*/


document.all.DET.innerHTML="Repository Details for Repository Code=["+sText+"]<br>and Repository Location=["+aDet[save_j]+"]<br>are listed below. (Total of "+count_detail+" different detail specifications.)<br>"+detail_msg;

}


</script>
<?
//============================end functions for view_search.php

?>

