<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

view_print_options.php
database: cricket_ser.ser2_test2 on dlc


*/
?>


<?php

include "include_upper.php";
include "include_standard.php";


print $html_header;

?>
<script language="javascript">
//these are all functions for buttons on this page

function submit_formF01(NUM) {
// view_cart_print, Print One Per page
//document.formF01.action=view_cart_print.php
document.formF01.preview.value=NUM;
document.formF01.serid_list.value=document.formW.serid_list.value;
//alert("document.formF01.serid_list.value="+document.formF01.serid_list.value);
//alert("document.formF01.action="+document.formF01.action);
document.formF01.submit();
}

function submit_formF02(NUM) {
//view_batch_print full format, NO hdrs no page breaks
//document.formF02.action=view_noheaders_print.php
document.formF02.preview.value=NUM;
document.formF02.serid_list.value=document.formW.serid_list.value;
//alert("document.formF02.serid_list.value="+document.formF02.serid_list.value);
//alert("document.formF02.action="+document.formF02.action);
document.formF02.submit();
}


function submit_formF03(NUM) {
// Condensed Print of Cart
//document.formF03.action=view_condensed_print.php
document.formF03.preview.value=NUM;
document.formF03.serid_list.value=document.formW.serid_list.value;
//alert("document.formF03.serid_list.value="+document.formF03.serid_list.value);
//alert("document.formF03.action="+document.formF03.action);
document.formF03.submit();
}

function submit_formF03all(NUM) {
// Condensed Print All, no auto option
// document.formF03all.action=view_condensed_print_all.php
if (NUM=="0"){
	alert("This will print EVERYTHING!"
		+"\n Push the other button and "
		+"\n\nLOOK AT IT BEFORE PRINTING!");
	return;
	}
document.formF03all.preview.value=NUM;
document.formF03all.serid_list.value=document.formW.serid_list.value;
//alert("document.formF03.serid_list.value="+document.formF03.serid_list.value);
//alert("document.formF03all.action="+document.formF03all.action);
document.formF03all.submit();
}

function submit_formAST(NUM) {
//Print ALL Lines(1700) Format, Author ShTitle Sort
//document.formAST.action=view_authortitle_print.php
document.formAST.preview.value=NUM;
//document.formAST.serid_list.value=document.formW.serid_list.value;
document.formAST.serid_list.value="0,550";
//alert("document.formAST.serid_list.value="+document.formAST.serid_list.value);
//alert("document.formAST.action="+document.formAST.action);
document.formAST.submit();
}
function submit_formACC(NUM) {
// Print ALL Lines(1700) Format, Accession sort 
// document.formACC.action=view_accession_print.php
document.formACC.preview.value=NUM;
//document.formACC.serid_list.value=document.formW.serid_list.value;
document.formACC.serid_list.value="0,550";
//alert("document.formACC.serid_list.value="+document.formACC.serid_list.value);
//alert("document.formACC.action="+document.formACC.action);
document.formACC.submit();
}

</script>
<?php
print $html_header_closer;
?>

<script language="javascript">
//document.write("document.formW.serid_list.value="+document.formW.serid_list.value);
//document.write("location.href="+location.href);
//document.write("document.formW.top.value="+document.formW.top.value);

</script>

<table summary="" border="00" cellspacing="0" cellpadding="2" xwidth="720" width="740">
<tr><td align="left">
<div>
<div class="info">
<div class="infotag">
Print Options for the Sermons Database
</div>
</div>
</div>
</td></tr>

<tr><td>
<table border="01" class="list" summary="" width="100%" cellpadding="2">

<tr class=""><td valign="top" width="50%">
<p>Print item(s) saved to Cart, full format, <br>one entry per page.
</td>
<td valign="top" width="50%">
<form name="formF01" action="view_cart_print.php" target="_blank">
<input type="hidden" name="serid_list" 
<?php
print " value=\"$serid_str\">\n";
?>
<input type="hidden" name="preview" value="0">
<input type="hidden" name="this_page_pid_list" value="">
<input type="hidden" name="other_page_pid_list" value="">
<input type="button" onclick="submit_formF01(1)" value="Preview"
name="pre01" class="bluebutton80">
<input type="button" onclick="submit_formF01(0)" value="Print One Per Page" 
name="bF01" class="bluebutton200">
</form>
</td></tr>



<tr class=""><td valign="top">
<p>Print item(s) saved to Cart, full format, NO headers or page breaks. 
<br>Multiple entries may split between pages.
</td>
<td valign="top">
<form name="formF02" action="view_noheaders_print.php" xaction="view_short_print.php" target="_blank">
<input type="hidden" name="serid_list" 
<?php
print " value=\"$serid_str\">\n";
?>
<input type="hidden" name="preview" value="0">
<input type="hidden" name="this_page_pid_list" value="">
<input type="hidden" name="other_page_pid_list" value="">
<input type="button" onclick="submit_formF02(1)" value="Preview"
name="pre02" class="bluebutton80">
<input type="button" onclick="submit_formF02(0)" value="Print" 
name="bF02" class="bluebutton200">
</form>
</td></tr>


<tr class=""><td valign="top">
<p>Print item(s) saved to Cart, condensed format, NO page breaks or headers.
Multiple entries may split between pages. Book format.
</td>
<td valign="top">
<form name="formF03" action="view_condensed_print.php" target="_blank">
<input type="hidden" name="serid_list" 
<?php
print " value=\"$serid_str\">\n";
?>
<input type="hidden" name="preview" value="0">
<input type="hidden" name="this_page_pid_list" value="">
<input type="hidden" name="other_page_pid_list" value="">
<input type="button" onclick="submit_formF03(1)" value="Preview"
name="pre03" class="bluebutton80">
<input type="button" onclick="submit_formF03(0)" value="Condensed Print"
name="bF03" class="bluebutton200">
</form>
</td></tr>

<script>
if(document.formW.top.value=='private2'){
document.write('<tr class="" bgcolor="ffddff"><td valign="top">'
+'<p>Print All Entries, condensed format, NO page breaks or headers.'
+'Multiple entries may split between pages. Book format. 220 pages.'
+'</td> <td valign="top">'
+'<form name="formF03all" action="view_condensed_print_all.php" target="_blank">'
+'<input type="hidden" name="serid_list" value=\"0\"> '
+'<input type="hidden" name="preview" value="0">'
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="button" onclick="submit_formF03all(1)" value="Prev.All" '
+'name="pre01all" class="bluebutton80">'
+'<input type="button" onclick="submit_formF03all(0)" '
+' value="Condensed Print All" name="bF01all" class="bluebutton200">'
+'</form> </td></tr>'
); 
}
</script>

<tr class=""><td valign="top">
<p>Print for all entries:<br> Accession Number, Author, Short Title.
<br>Entries ordered by Author, Short Title.
<br>Approximately 1700 lines.
</td>
<td valign="top">
<form name="formAST" action="view_authortitle_print.php" target="_blank">
<input type="hidden" name="serid_list" 
<?php
print " value=\"$serid_str\">\n";
?>
<input type="hidden" name="preview" value="0">
<input type="hidden" name="this_page_pid_list" value="">
<input type="hidden" name="other_page_pid_list" value="">
<input type="button" onclick="submit_formAST(1)" value="Preview"
name="pre03" class="bluebutton80">
<input type="button" onclick="submit_formAST(0)" value="Print by Author, Title"
name="bACC" class="bluebutton200">
</form>
</td></tr>

<tr class=""><td valign="top">
<p>Print for all entries:<br> Accession Number, Author, Short Title.
<br>Entries ordered by Accession Number.
<br>Approximately 1700 lines.
</td>
<td valign="top">
<form name="formACC" action="view_accession_print.php" target="_blank">
<input type="hidden" name="serid_list" 
<?php
print " value=\"$serid_str\">\n";
?>
<input type="hidden" name="preview" value="0">
<input type="hidden" name="this_page_pid_list" value="">
<input type="hidden" name="other_page_pid_list" value="">
<input type="button" onclick="submit_formACC(1)" value="Preview"
name="pre03" class="bluebutton80">
<input type="button" onclick="submit_formACC(0)" value="Print by Accession Number"
name="bACC" class="bluebutton200">
</form>
</td></tr>

<tr class=""><td valign="top" colspan="2"><p>&nbsp;<p>You may download sermons results from Preview by using the "Save File As" option on your browser.
</td></tr>

</table>
</div>
<?php
#print $footer;

/*
print "\$ser2_test2_alias: ";
print $ser2_test2_alias;
print "<hr>";
print "'$ser2_test2_alias '";
*/
?>

</td></tr></table>
<form name="pageformA">
<input type="hidden" name="serid_list">
</form>

<script language=javascript src="elements.js"></script>
<script>

//document.pageformA.serid_list.value=document.formW.serid_list.value;

//show_elements defined in include_upper.php
show_elements=0;
if (show_elements==1) {
	elements();
}
</script>
</body>
</html>
