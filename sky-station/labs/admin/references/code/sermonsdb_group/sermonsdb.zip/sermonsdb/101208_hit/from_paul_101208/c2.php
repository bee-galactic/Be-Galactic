<?php
$q1= "SELECT SUM(hits) FROM hitcounts WHERE filename='$fn' AND directory='$dir' ";
$r1 = mysql_query($q1, $link) or die ("Error in   query: $q1. " . mysql_error());
while (list($h) = mysql_fetch_row($r1)) {
  print "<p class=\"smaller\">";
  print "This page has been accessed $h times since Dec. 8, 2010.</p>";
}
?>

