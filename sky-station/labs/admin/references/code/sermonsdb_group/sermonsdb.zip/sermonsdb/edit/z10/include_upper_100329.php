<?php
#ser8/include_upper.php

$ser_debug=0;

$top = $_GET['top']; #this is the switch for top_htm public vs private

$serid_str    = $_GET['serid_list'];
if ($serid_str=="") {
	#$serid_str = $_POST['serid_list'];
	}

if (!$serid_str=="") {
	$serid_str="0";
	}
/*title for all pages*/
$SM_TITLE = "Southern Manuscript Sermons before 1800:  A Bibliographic Database<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;edited by Michael A. Lofaro";


/* footer  print_ser-footer.php*/
$footer ="<p><hr />"; 
$footer.="<font face=\"verdana\" size=\"2\" color=\"#000000\">&nbsp;University of Tennessee Digital Library</font>\n";

?>
<html>
<head>
<title>view_upper</title>
<link rel="stylesheet" type="text/css" href="ser.css" />
<script language="javascript">
///write full url at very top of page
///document.write(location.href);
</script>

<!--- switch for public vs private --->
<form name="formTop">
<?php
print "<input type=\"hidden\" name=\"top_mode\" value=\"$top\" >";
?>
</form>

<script language="javascript">
//document.write(parent.location.href);
var show_elements = 0;//when 1, print elements, when 0 do not print elements

//used by *pagelink*
function reset_formW(){
//document.formW.serid_list.value="0";
}


function submit_formWelcome() { //welcome.php  INTRODUCTION BUTTON
//alert("submit_formWelcome");
//var welcomeAction = new String();
//welcomeAction = "welcome_"+document.formW.top.value+".php";
//document.formWelcome.action = welcome.php;
//alert("welcomeAction="+welcomeAction);
document.formWelcome.top.value=document.formW.top.value;
document.formWelcome.serid_list.value=document.formW.serid_list.value;
//if(!c onfirm("document.formWelcome.serid_list.value="+document.formWelcome.serid_list.value))return;
document.formWelcome.submit();
}

function submit_formA() { //view_author_title_index  INDEX BUTTON
//alert("submit_formA");
document.formA.top.value=document.formW.top.value;
document.formA.serid_list.value=document.formW.serid_list.value;
//if(!c onfirm("document.formA.serid_list.value="+document.formA.serid_list.value))return;
document.formA.submit();
}

function submit_formB() { //view_batch_select  BATCH BUTTON
//alert("submit_formB");
document.formB.top.value=document.formW.top.value;
//alert("document.formW.serid_list.value="+document.formW.serid_list.value);
if(!confirm("Entering the Batch Select page will clear all checkboxes.\n\nDo you wish to continue?")){return;}
document.formB.batch_print_list.value="0";///document.formW.serid_list.value;
//alert("document.formB.serid_list.value="+document.formB.serid_list.value);
document.formB.submit();
}

function submit_formB2() { //view_batch2_select  BATCH2 BUTTON
//alert("submit_formB2");
document.formB.top.value=document.formW.top.value;
//alert("document.formW.serid_list.value="+document.formW.serid_list.value);
if(!confirm("Entering the Batch2 Select page will clear all checkboxes.\n\nDo you wish to continue?")){return;}
document.formB2.batch_print_list.value="0";///document.formW.serid_list.value;
//alert("document.formB.serid_list.value="+document.formB.serid_list.value);
document.formB2.submit();
}


function submit_formCi() {//view_search_index
//alert("submit_formCi");
document.formCi.top.value=document.formCi.top.value;
document.formCi.serid_list.value=document.formW.serid_list.value;
//alert("document.formCi.serid_list.value="+document.formCi.serid_list.value);
document.formCi.submit();
}

function submit_formC() {//view_search_only SEARCH BUTTON
//alert("submit_formC");
document.formC.top.value=document.formW.top.value;
document.formC.serid_list.value=document.formW.serid_list.value;
//if(!c onfirm("document.formC.serid_list.value="+document.formC.serid_list.value))return;
document.formC.submit();
}

function submit_formEsearch() {//edit_search.php EDIT BUTTON
//alert("submit_formEsearch");
document.formEsearch.top.value="private";
document.formEsearch.serid_list.value=document.formW.serid_list.value;
//if(!c onfirm("document.formEsearch.serid_list.value="+document.formEsearch.serid_list.value))return;
document.formEsearch.submit();
}


function submit_formD() {//view_cart_index CART SUMMARY BUTTON
//alert("submit_formD");
document.formD.top.value=document.formW.top.value;
//alert("document.formW.serid_list.value="+document.formW.serid_list.value);
document.formD.serid_list.value=document.formW.serid_list.value;
//if(!c onfirm("document.formD.serid_list.value="+document.formD.serid_list.value))return;
document.formD.submit();
}

function submit_formE() {//view_cart_display  CART DISPLAY BUTTON
/*
alert("submit_formE"
	+"\nserid_list="+document.formW.serid_list.value
	+"\nserid="+document.formW.serid.value
	+"\nthis_page_pid_list="+document.formW.this_page_pid_list.value
	+"\nother_page_pid_list="+document.formW.other_page_pid_list.value);
*/
document.formE.top.value=document.formW.top.value;
document.formE.serid_list.value=document.formW.serid_list.value;
/*
if(!confirm("document.formE.serid_list.value="+document.formE.serid_list.value))return;
*/
document.formE.submit();
}


function submit_formPrintOpt() {// print options  PRINT BUTTON
//alert("submit_formPrintOpt");
document.formPrintOpt.top.value=document.formW.top.value;
document.formPrintOpt.serid_list.value=document.formW.serid_list.value;
//if(!confirm("document.formPrintOpt.serid_list.value="+document.formPrintOpt.serid_list.value))return;
document.formPrintOpt.submit();
}


</script>

</head>
<body  xbgcolor="adeeff" vlink="003366" alink="003366" link="003366">

<table summary="" xbgcolor="a99999" bgcolor="ffffff" border="00" cellspacing="0" cellpadding="2" width="740" xwidth="720" name="first_upper">
<tr bgcolor="#000000"><td width="100%"><img src="sermons_wrapper5.jpg"></td></tr>
<tr><td bgcolor="ffffff"></hr style="color:#a00000; height:10; width:740">
<?php

#from frame reference: src="include_upper.php?top=XXX"
#where top=public or top=private
#see above: $top=$_GET['top'];
#this is the switch for hidden formvar document.formTop.top_mode.value
# which in turn defines the switch top_htm public vs private
#print "include_upper.php \$top=$top";

$serid_str  = $_GET['serid_list'];
#print "\$serid_string=$serid_str<hr>";
if ($serid_str==""){
	$serid_str="0";
	}

print "<!--- PRIMARY LOCATION for document.formW.serid_list.value -->\n";
print "<form name=\"formW\" >\n";
print "<input type=\"hidden\" name=\"top\" value=\"$top\">\n";
print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\">\n";
print "<input type=\"hidden\" name=\"serid\" value=\"0\">\n";
print "<input type=\"hidden\" name=\"batch_print_list\" value=\"0\">\n";
print "<input type=\"hidden\" name=\"this_page_pid_list\" value=\"0\">\n";
print "<input type=\"hidden\" name=\"other_page_pid_list\" value=\"0\">\n";
print "</form>\n";

#print "<font face=\"verdana\" size=\"2\" color=\"#000000\">&nbsp;University of Tennessee  Digital Library</font>\n";


/*title for all pages*/
$SM_TITLE = "Southern Manuscript Sermons before 1800:  A Bibliographic Database<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;edited by Michael A. Lofaro";

$SM_TITLE3 = "<img src=\"sermons_wrapper3.jpg\">";
$SM_TITLE4 = "<img src=\"sermons_wrapper4.jpg\">";

/*
//title text wrapper 3
print "<font face=\"verdana\" size=\"2\" color=\"#000000\">&nbsp;University of Tennessee  Digital Library</font>\n";
print "<div>\n";
print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print $SM_TITLE3;
print "</div>\n";
print "</div>\n";
print "</div>\n";

//title text wrapper 4
print "<font face=\"verdana\" size=\"2\" color=\"#000000\">&nbsp;&nbsp;University of Tennessee  Digital Library</font>\n";
print "<div>\n";
print "<div class=\"info\">\n";
print "<div class=\"infotagNFP\">\n";
print $SM_TITLE4;
print "</div>\n";
print "</div>\n";
print "</div>\n";
*/
?>
</td></tr><tr><td>
<table width="700" xbgcolor="aaffff" summary="" border="00" cellspacing="0" cellpadding="2" name="second_upper">
<tr><td>

</td></tr>
<tr><td width="100%" >

<table border="00" cellpadding="2" cellspacing="0" width="100%" xbgcolor="ffffaa" name="third_upper"><tr> 

<td valign="top">

<!--- //INTRODUCTION BUTTON introductionc--->
<form name="formWelcome" action="welcome.php" target="D">
<input type="hidden" name="top" value="">
<input type="hidden" name="serid_list" value=""> 
<input type="hidden" name="serid" value="0"> 
<input type="hidden" name="this_page_pid_list" value="">
<input type="hidden" name="other_page_pid_list" value="">
<input type="button" 
value='Introduction' 
name="bWel" onclick="submit_formWelcome();" class="bluebutton106">
</form>
</td>

<script language="javascript">

//alert("location.href="+location.href);
var top_htm = new String("");
if (document.formTop.top_mode.value == "private"){
	top_htm = "private";
}else{
	top_htm = "public";
}


//INDEX BUTTON
var author_title_button=new String('<td valign="top">'
+'<form name="formA" action="view_author_title_index.php?hide=deleted" target="D">'
+'<input type="hidden" name="top" value="">'
+'<input type="hidden" name="serid_list" value="">'
+' <input type="hidden" name="serid" value="0"> '
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="button"'
+'value="Index"'
+'name="bA" onclick="submit_formA();"');
if (top_htm.indexOf("private")>-1){
    author_title_button += 'class="bluebutton60"></form></td>';
}else{
    author_title_button += 'class="bluebutton106"></form></td>';
}


if (top_htm.indexOf("private")==-10){
//INDEX BUTTON v2
var author_title_button=new String('<td valign="top">'
+'<form name="formA" action="v2_author_title_index.php?hide=deleted" target="D">'
+'<input type="hidden" name="top" value="">'
+'<input type="hidden" name="serid_list" value="">'
+' <input type="hidden" name="serid" value="0"> '
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="button"'
+'value="Indv2"'
+'name="bA" onclick="submit_formA();"');
if (top_htm.indexOf("private")>-1){
    author_title_button += 'class="bluebutton60"></form></td>';
}else{
    author_title_button += 'class="bluebutton106"></form></td>';
}
}//v2

//SEARCH BUTTON
var search_full_button=new String('<td valign="top">'
+'<form name="formC" action="view_search_only.php" target="D">'
+'<input type="hidden" name="top" value="">'
+'<input type="hidden" name="serid_list" value="">'
+'<input type="hidden" name="serid" value="0">'
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="hidden" name="search_submit" value="first">'
+'<input type="hidden" name="display_choice" value="0">'
+'<input type="button" value="Search"'
+'name="bC" onclick="submit_formC();"');
if (top_htm.indexOf("private")>-1){
    search_full_button+='class="bluebutton60"></form></td>';
}else{
    search_full_button+='class="bluebutton106"></form></td>';
}


//EDIT BUTTON //used by private
var edit_search_button = new String('<td valign="top">'
+'<form name="formEsearch" action="edit_search.php" target="D">'
+'<input type="hidden" name="top" value="private">'
+'<input type="hidden" name="serid_list" value="">'
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="hidden" name="display_choice" value="0">'
+'<input type="hidden" name="serid" value="">'
+'<input type="hidden" name="search_submit" value="first">'
+'<input type="button" value="Edit" name="bEsearch" onclick="submit_formEsearch();" '
+' class="pinkbutton60">'
+'</form></td>');

//BATCH BUTTON //used by private
var batch_select_button = new String(' <td valign="top"> '
+' <form name="formB" action="view_batch_select.php?hide=deleted" target="D"> '
+'<input type="hidden" name="top" value="private">'
+' <input type="hidden" name="serid_list" value=""> '
+' <input type="hidden" name="serid" value="0"> '
+' <input type="hidden" name="batch_print_list" value=""> '
+' <input type="hidden" name="this_page_pid_list" value=""> '
+' <input type="hidden" name="other_page_pid_list" value=""> '
+' <input type="button" value="Batch" name="bB" onclick="submit_formB();" '
+' class="pinkbutton60"> '
+' </form></td> ');

//BATCH2 BUTTON //used by private
var batch2_select_button = new String(' <td valign="top"> '
+' <form name="formB2" action="view_batch2_select.php?hide=deleted" target="D"> '
+'<input type="hidden" name="top" value="private">'
+' <input type="hidden" name="serid_list" value=""> '
+' <input type="hidden" name="serid" value="0"> '
+' <input type="hidden" name="batch_print_list" value=""> '
+' <input type="hidden" name="this_page_pid_list" value=""> '
+' <input type="hidden" name="other_page_pid_list" value=""> '
+' <input type="button" value="Batch2" name="bB2" onclick="submit_formB2();" '
+' class="pinkbutton60"> '
+' </form></td> ');

//CART SUMMARY BUTTON
var cart_summary_button = new String('<td valign="top">'
+'<form name="formD" action="view_cart_index.php?serid=document.formD.serid_list.value" target="D">'
+'<input type="hidden" name="top" value="">'
+'<input type="hidden" name="serid_list" value="">'
+' <input type="hidden" name="serid" value="0"> '
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="button" onclick="submit_formD();" value="Cart Summary" name="bD"');
if (top_htm.indexOf("private")>-1){
    cart_summary_button+='class="bluebutton106"></form></td>';
}else{
    cart_summary_button+='class="bluebutton106"></form></td>';
}

//CART DISPLAY BUTTON
var cart_display_button = new String('<td valign="top">'
+'<form name="formE" action="view_cart_display.php" target="D">'
+'<input type="hidden" name="top" value="">'
+'<input type="hidden" name="serid_list" value="">'
+' <input type="hidden" name="serid" value="0"> '
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="button" onclick="submit_formE()" value="Cart Display" name="bE"');
if (top_htm.indexOf("private")>-1){
    cart_display_button+='class="bluebutton100"></form></td>';
}else{
    cart_display_button+='class="bluebutton106"></form></td>';
}

//PRINT BUTTON
var print_options_button=new String('<td valign="top">'
+'<form name="formPrintOpt" action="view_print_options.php" target="D">'
+'<input type="hidden" name="top" value="">'
+'<input type="hidden" name="serid_list" value="">'
+' <input type="hidden" name="serid" value="0"> '
+'<input type="hidden" name="this_page_pid_list" value="">'
+'<input type="hidden" name="other_page_pid_list" value="">'
+'<input type="button" onclick="submit_formPrintOpt()" value="Print" name="bPO"');

if (top_htm.indexOf("private")>-1){
    print_options_button+='class="bluebutton60"></form></td>';
}else{
    print_options_button+='class="bluebutton106"></form></td>';
}

//===========================================================
//BUTTON NOT ON include_upper.php
//but in view_batch_select.php and in view_batch2_select.php


//function submit_formBp() { //BATCH PRINT BUTTON, view_batch_select.php
//needs batch_print_form shown here
var batch_print_form = new String(' <form name="formBp" action="view_batch_print.php?hide=deleted" target="_blank"> '
+'<input type="hidden" name="top" value="">'
+' <input type="hidden" name="serid_list" value=""> '
+' <input type="hidden" name="serid" value="0"> '
+' <input type="hidden" name="batch_print_list" value=""> '
+' <input type="hidden" name="this_page_pid_list" value=""> '
+' <input type="hidden" name="other_page_pid_list" value=""> '
+' </form>');

//===========================================================
//BUTTON NOT ON include_upper.php
//but in view_batch_select.php and in view_batch2_select.php

//function submit_formB2p() { //BATCH2 PRINT BUTTON, view_batch2_select.php
//needs batch2_print_form shown here
var batch2_print_form = new String(' <form name="formB2p" action="view_batch2_print.php?hide=deleted" target="_blank"> '
+'<input type="hidden" name="top" value="">'
+' <input type="hidden" name="serid_list" value=""> '
+' <input type="hidden" name="serid" value="0"> '
+' <input type="hidden" name="batch_print_list" value=""> '
+' <input type="hidden" name="this_page_pid_list" value=""> '
+' <input type="hidden" name="other_page_pid_list" value=""> '
+' </form>');




/////////////////////end_top_htm

document.write(search_full_button);
document.write(author_title_button);

if (top_htm.indexOf("private")>-1){
	//document.write(author_title_buttonv2);
        document.write(edit_search_button);
	document.write(batch_select_button);
	document.write(batch_print_form); //needed by view_batch_select.php
	//document.write(batch2_select_button);
	//document.write(batch2_print_form); //needed by view_batch2_select.php
}
document.write(cart_summary_button);
document.write(cart_display_button);
document.write(print_options_button);

</script>

</tr></table name="third_upper">
</tr></table name="second_upper">
</td></tr></table name="first_upper">

