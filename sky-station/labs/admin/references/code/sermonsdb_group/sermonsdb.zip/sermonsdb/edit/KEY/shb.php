<html>
<head>
<title>shb</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shb";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- B</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Baalam's [sic] Wish</option>
<option>Backsliding</option>
<option>Balaam's Wish</option>
<option>Baptism, On</option>
<option>Be not conformed to this world</option>
<option>Be not overmuch wicked</option>
<option>Be not weary in well-doing</option>
<option>Be ye doers of the word</option>
<option>Be Ye Perfect</option>
<option>Become as little children</option>
<option>Before or after Easter... the Death of Christ</option>
<option>Behold, my Servant shall deal prudently</option>
<option>Behold, the fear of the Lord, th[at] is Wisdom</option>
<option>Being of a God, On the</option>
<option>Being Ready for the Son of Man</option>
<option>Belief in Christ</option>
<option>Belief in God, On</option>
<option>Benefit of the Corporation, For the</option>
<option>Best Christians unprofitable servants, The</option>
<option>Betrayal of Christ, On</option>
<option>Betrayest thou the Son o[f] man with a Kiss?</option>
<option>Beware a Death Unprepared</option>
<option>Bible and Salvation (1), On the</option>
<option>Bible and Salvation (2), On the</option>
<option>Binding up of the broken-hearted</option>
<option>Bishop, For the</option>
<option>Blameless living, Of</option>
<option>Blasphemy against the Holy Ghost</option>
<option>Blessed are the Meek, On</option>
<option>Blessed are the Poor in Spirit, On</option>
<option>Blessed be the God & Father of our Lord Jesus Xt</option>
<option>Blessed is the Man that Trusteth in the Lord</option>
<option>Blessedness described in the first psalm, The</option>
<option>Blind Bartimeus</option>
<option>Blood and Body of Christ, The</option>
<option>Boast not of tomorrow</option>
<option>Boasting [Witnessing] in God, On</option>
<option>Bordley Funeral Sermon</option>
<option>Both faith and works necessary to Salvation</option>
<option>Burdens of sin, Of the</option>
<option>Burial of Xt, On the</option>
<option>But thou, when thou prayest, enter into thy Closet</option>
<option>By the Obedience of One shall many be made Righteous</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
