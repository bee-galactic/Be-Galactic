<html>
<head>
<title>shc</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shc";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- C</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Can the Ethiopian change his skin, or the Leopard his spots?</option>
<option>Candid expostulation with those, who trespass against us</option>
<option>Care in hearing the Word</option>
<option>Care of salvation, On the</option>
<option>Case of the penitent thief, The</option>
<option>Catechismum de Domini Cana, In</option>
<option>Cause of Children Advocated, The</option>
<option>Cause of young children advocated, The</option>
<option>Caution against falling from Grace</option>
<option>Ceasing to do evil</option>
<option>Celestial Glory, On</option>
<option>Centurion's petition for his sick servant, The</option>
<option>Certainty of Death, On the</option>
<option>Certainty of future happiness, On the</option>
<option>Ch. 8, V. 10, 11</option>
<option>Character & errand of Ministers</option>
<option>Character of a profitable resolution to amend</option>
<option>Character of Cornelius, The</option>
<option>Character of Judas, On the</option>
<option>Character of St Paul, On the</option>
<option>Charge to the Newly Ordained, A</option>
<option>Charity, --as defined by St Paul</option>
<option>Charity, On</option>
<option>Charity: John the Apostle</option>
<option>Charity: Mark, VIII, 2</option>
<option>Charity: The Neighbor</option>
<option>Charity of Baltimore, The</option>
<option>Charity to one's enemies, On</option>
<option>Children, obey your Parents in the Lord</option>
<option>Children of Light instructed how to walk, The</option>
<option>Christ's Crucifixion, Of</option>
<option>Christ's Invitation to penitent Sinners</option>
<option>Christ's Love for the Church</option>
<option>Christ's Passion, Of</option>
<option>Christ's Preaching to Spirits, On</option>
<option>Christ's propitiation, Of</option>
<option>Christ's reanimated body not imaginary, but real</option>
<option>Christ's Resurrection, Of</option>
<option>Christ a propitiation for the sins of the world</option>
<option>Christ as Mediator</option>
<option>Christ hath redeemed us from the curse of the law</option>
<option>Christ Jesus our Lord</option>
<option>Christ our deliverer and salvation</option>
<option>Christ our head</option>
<option>Christ tempted</option>
<option>Christ the light of the World, On</option>
<option>Christ the salvation of the end of the earth</option>
<option>Christian Charity</option>
<option>Christian Conduct (1), On</option>
<option>Christian Conduct (2), On</option>
<option>Christian Conduct (3), On</option>
<option>Christian Covenant, The</option>
<option>Christian Parent, The</option>
<option>Christian race, Of the</option>
<option>Christian Race, The</option>
<option>Christian Religion, On the</option>
<option>Christian Sacrifice, The</option>
<option>Christian Salvation</option>
<option>Christian Salvation a deliverance from Sin</option>
<option>Christian Unity (1), On</option>
<option>Christian Unity (2), On</option>
<option>Christianity a spring of spiritual joy</option>
<option>Christianity vindicated</option>
<option>Christmas</option>
<option>Christmas, For</option>
<option>Christmas [Two Sermons by John Coleman]</option>
<option>Christmas Day, For</option>
<option>Christmas in what Manner to be Kept</option>
<option>Christmas Religion & Joy compatible, About</option>
<option>Church Musick</option>
<option>Circumcision, On the</option>
<option>City that is on an Hill cannot be hid, A</option>
<option>Colossians 3:2, On</option>
<option>Come unto me all ye that labour</option>
<option>Comforting & edifying one another</option>
<option>Coming of the Holy Ghost, On the</option>
<option>Coming to Judgment</option>
<option>Commandment, On the 3rd</option>
<option>Commandment to Love, On</option>
<option>Commandments of God, The</option>
<option>Commemoration of American Independence</option>
<option>Communion, On</option>
<option>Complaint of Sufferer</option>
<option>Completion of a church, On</option>
<option>Concerning the law of Moses</option>
<option>Concerning the law of Moses, No. 2</option>
<option>Condemning one's neighbor, On</option>
<option>Confessing of Christ before men, &c</option>
<option>Confession of sin, and its blessed Effects</option>
<option>Confirmation</option>
<option>Confirmation, On</option>
<option>Confirmation: II Corinthians I, 21</option>
<option>Confirmation: John, V</option>
<option>Confirmation: Jude, V, 20</option>
<option>Confirmation of faith, On the</option>
<option>Conforming our will to God, On</option>
<option>Conformity to the World, Against</option>
<option>Congregational discord, On</option>
<option>Conscience, On</option>
<option>Conscience void of offence, A</option>
<option>Consideration of our ways</option>
<option>Contemplation of Christ, The</option>
<option>Contempt of the world, On the</option>
<option>Contending for the faith</option>
<option>Contentment, On</option>
<option>Continuing patiently in well-doing</option>
<option>Contrition, On</option>
<option>Convention Sermon</option>
<option>Corinthians 11: 29, On 1</option>
<option>Corr 1, 21, 1[First]</option>
<option>Corrupt Clergy, A</option>
<option>Corruption of Heart, On</option>
<option>Counsel of God & Future Glory</option>
<option>Counsels of the Heart, On</option>
<option>Covering sin</option>
<option>Creation</option>
<option>Creed, On the</option>
<option>Creed, On the 10th Article of the</option>
<option>Creed, On the second article of the</option>
<option>Crime and Curse of Plundering, The</option>
<option>Cross, On the</option>
<option>Crowning with thorns, On the</option>
<option>Crucifixion of The Flesh</option>
<option>Cup of Blessing, The</option>


<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
