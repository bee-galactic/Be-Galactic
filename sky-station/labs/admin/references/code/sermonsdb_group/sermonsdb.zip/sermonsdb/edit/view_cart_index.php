<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

view_cart_index.php

*/
//-- error reporting
 #error_reporting(E_ALL);

//-- declare functions


//--- end of functions
include "include_standard.php";
print $html_header;
print $html_header_closer;

include "./include_upper.php";
?>
<script language="javascript">
//write_serid_list();
//document.write("location.href:<BR>"+location.href+"<hr style=\"background-color:#a00000; height:10; width:720\">");
</script>

<div>
<table border="0" cellpadding="0" cellspacing="0" width="740" xbgcolor="ffffaa"><tr><td>
<div class="info">
<div class="infotag">
 Cart Summary Index for the Sermons Database<br>&nbsp;&nbsp;&nbsp;&nbsp;(sorted by author's last name, title, and date)
</div>
</div>
</td></tr></table>
</div>


<?php

include "./include_checkbox_functions.php";
#include "./include_pagelink_SEARCH.php";
include "./include_pagelink_AUTHOR.php";


$serid_str         = $_GET['serid_list'];
#print "\$serid_string=$serid_str<hr>";
#$serid_str = str_replace(",0","0",$serid_str);
#print "\$serid_string=$serid_str<hr>";
$cart_list	   = $_GET['serid_list'];

if (!$serid_str) $serid_str="0";
if (!$cart_list) $cart_list="0";


$top_str         = $_GET['top'];


//===================================================
// inits for paging
$lim=20;
#$lim=5;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;


if (!isset($serid_list)) $serid_list=0;


$lnk=$PHP_SELF;
$lnk.="?serid_list=$serid_str";
$lnk.="&r=1";

//
// $rec is the current pos in results, the beginning of the list of $lim results
// determine rec to retrieve a new block of results

############nh is undefined.  090828 chd


if ($inc)
  {
	$rec=$rec+$inc;
  if (($nh)&&($rec>=$nh)) $rec=$nh;
	}
if ($dec)
  {
	$rec=$rec-$dec;
  if ($rec <0) $rec=0;
	}


//==================================================



if (1)
{

$iquery = "SELECT ser_test.pid, ser_test.nameauthor, ser_test.shorttitle, ser_test.indexdate, ser_test.accession ";
#$iquery.= " FROM ser2_test2 as ser_test ";
$iquery.= " FROM ser3_edit3 as ser_test ";
$iquery.= " WHERE ser_test.test LIKE \"%keep%\" ";
$iquery.= " AND ser_test.pid IN (";
$iquery.=  $serid_str;
$iquery.= ") ";
$iquery.= " order by replace(replace(ser_test.nameauthor,\"[\",\"\"),'$doublequote',\"\"), replace(ser_test.shorttitle,\"[\",\"\") ";
print "</div>\n";

$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";

#print "<font color=\"#a00000\">$iquery2</font>";


$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());


# print "<table border=\"1\" class=\"list\" summary=\"\" width=\"100%\" cellpadding=\"2\">\n";
 $bg="bg2";
if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";
//=========================
	PageLinkTop();
//=========================

/*width formerly 920*/
 print "<table border=\"1\" class=\"list\" summary=\"\" xwidth=\"820\" width=\"100%\" cellpadding=\"2\" xbgcolor=\"aaffff\">\n";
 #$bg="bg2";

 print "<form name=\"pageformA\" action=\"view_cart_index.php\">";

 print "<input type=\"hidden\" name=\"this_page_pid_list\" value=\"0\">\n";
 print "<input type=\"hidden\" name=\"other_page_pid_list\" value=\"0\">\n";
 print "<input type=\"hidden\" name=\"serid_str\" value=\"$serid_str\">\n";
 print "<input type=\"hidden\" name=\"top\" value=\"$top_str\">\n";

 #print "<input type=\"text\" name=\"this_page_pid_list\" value=\"0\"> document.pageformA.this_page_pid_list.value\n";
 ####need to comment out line below to have the checkbox functions work 
 #print "<br><input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\"> document.pageformA.serid_list.value\n";

 print "<tr>";

 print "<td colspan=\"7\" >";

print "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">";
print "<tr><td align=\"left\">";

 print "<input type=\"button\" name=\"save_this_page_pids\" value=\"Check All This Page\" onclick=\"check_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"remove_this_page_pids\" value=\"Uncheck All This Page\" onclick=\"uncheck_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"clearpageformA\" value=\"Clear All\" onclick=\"clear_all();\" class=\"bluebutton200\">&nbsp;";


print "</td></tr></table>";
 print "</td></tr>\n";
 
 print "<tr>\n";
 print "<td width=\"5%\"  class=\"value14so\">Select</td>\n";
 print "<td xwidth=\"5%\"  class=\"value14so\">&nbsp;Acc. #</td>\n";
 print "<td xwidth=\"15%\" class=\"value14so\">&nbsp;Author</td>\n";
 print "<td xwidth=\"30%\" class=\"value14so\">&nbsp;Short Title</td>\n";
 print "<td xwidth=\"10%\" class=\"value14so\">&nbsp;Index Date</td>\n";
 print "</tr>\n";

 $this_form_name="pageformA";
 


while (list($pid,$na,$sht,$ida,$acc) = mysql_fetch_row($iresult))
  {

	$bg ="";
	print "<tr >";

	/*new chbx*/
        print "<td valign=\"top\" class=\"value14so\">&nbsp;";
 
        print "&nbsp;<input type=\"checkbox\" name=\"chbx";
        print $pid;
        print "\"  ";
        print " onclick='reset_chbx_search(\"";
        print $this_form_name;
        print "\",this,\"";
        print $pid;
        print "\",\"";
        print $acc;
        print "\");' ";
        print "style=\"height:25px;width:25px;\">";


        print "<script language=\"javascript\">set_chbx_search(\"";
        print $this_form_name;
        print "\",\"";
        print $pid;
        print "\");";
        print "</script>";


        print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
        print "<a  href=\"view_one_acc.php?serid=";
        print $pid;
        print "&accid=";
        print $acc;
        print "\" target=\"_blank\">";
        print $acc;
        /*print "($pid)";*/ //*commented out by BDS - 2009-04-09
        print "</a>";

	/*new chbx*/


        print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	print $na;
        print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	print $sht; #title:$srt #shortttile $sht
        print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	print $ida; #dates:$ida #indexdate: $ida
	print "</td>";
	print "</tr>";
	

  }//end while


 print "</table>";
//=========================
	PageLinkBottom();
//=========================


 }// end if (mysql_num_rows($iresult)) 
else {//no items to print
print "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">";
 if($serid_str != "0"){
 	print "<table><tr><td colspan=\"6\"><font face=\"verdana\" size=\"3\"><p>&nbsp;</p>There are no items to print on this page.<br>Have you deleted an item?<br> Please click the Cart Summary button above to continue.</font></td></tr></table>";
 }else{
 	print "<tr><td colspan=\"6\"><font face=\"verdana\" size=\"3\"><p>&nbsp;</p>There are no items in the cart.</font></td></tr></table>";
 }
}//end else

 print("</form>");

} //end if stitle 
print "</div>\n";
#print $footer;
print "\$ser2_test2_alias: ";
print $ser2_test2_alias;
print "<hr>";
print "'$ser2_test2_alias '";
?>
<script language=javascript src="elements.js"></script>
<script>
//document.write("<br>document.pageformA.this_page_pid_list.value="+document.pageformA.this_page_pid_list.value+"<br>");
//document.write("<br>document.formW.serid_list.value="+document.formW.serid_list.value+"<br>");
//document.write("document.formW.this_page_pid_list.value="+document.formW.this_page_pid_list.value+"<HR><HR>");
//show_elements defined in include_standard.php
show_elements=0;
if (show_elements==1) {
        elements();
}
</script>
</body>
</html>
