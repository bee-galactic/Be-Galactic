<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

view_short_print.php

This is the compressed print format (annotated bibliography format),
with headers and footers removed.

The HTML header is in this file because this file pops up into a new window
when the PrintCart button is clicked.

*/

include "include_standard.php";

?>

<html><head><title>Sermons Database</title>
<link rel="stylesheet" type="text/css" href="ser.css" />
<?php
$preview = $_GET['preview'];
?>


</head>
<?php
if ($preview==0){
	print "<body onload=\"window.print()\">\n";
}else{
	print "<body >\n";
}
#print "\$preview=$preview<br>";
?>
<table summary="" border="00" cellspacing="10" cellpadding="10" width="640">
<tr><td align="left">
<?php
print $masthead_header;
?>
</td></tr></table>

<table summary="" border="0" cellspacing="10" cellpadding="10" name="outer">
<tr><td valign="top">


<?php

$doublequote = '"';


//serid_list is the only variable passed
//id_type was previously passed when we displayed both acc and pid
//in view_cart_print.php id type is ALWAYS id ( the pid ) not acc.
//if serid_list=="0", print empty cart message

$serid_list= $_GET['serid_list'];
if(!serid_list) $serid_list="0";

  /*
  print "<table summary=\"\" border=\"01\" cellspacing=\"05\" cellpadding=\"10\" bgcolor=\"aaffff\"><tr><td>";
  print "above table------------------------------------------------------------<br>";
  print "line 1  acc#  nameauthor (state, denom, dates)<br> ";
  print "line 2  srt title place/datepreached nopages Repository<br>"; 
  print "line 3  Biblical Ref full <br>";
  print "line 4  Commentary<br>";
  print "line 5  Keywords<br>";
  print "</td></tr></table>\n";
  */

if ($serid_list == "0") {
  print "<table summary=\"\" border=\"01\" cellspacing=\"10\" cellpadding=\"10\"><tr><td>";
  print "<font face=\"verdana\" size=\"3\">There are no items in the cart.</font>";
  print "</td></tr></table>\n";
  print "</td></tr></table>\n";##this ends the table started in ser-header_vone.php
} else {


$WHERE_CLAUSE = " WHERE ser_test.pid IN ($serid_list) ";

$id_type = "id";


// inits for paging - because continuous feed for printing, removed rest of paging code
$lim=20;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;


$iquery = "SELECT ser_test.pid, ser_test.sermon_id, ser_test.sermon_test_id, ser_test.nameauthor, ser_test.state, ";
$iquery.= "ser_test.denom, ser_test.dates, ser_test.ser_title, ser_test.cover_entry_title, ser_test.book_title, ser_test.totalpgs, ";
$iquery.= "ser_test.placepub, ser_test.publisher, ser_test.date2, ser_test.ser_pgno, ";
$iquery.= "ser_test.placedate, ser_test.indexdate, ser_test.nopgs, ser_test.bibref, ser_test.indexbibref, ";
$iquery.= "ser_test.comment, ser_test.libloc, ser_test.loc_repository, ser_test.libloc_code,ser_test.crossref, ser_test.shorttitle, ser_test.keywords , ser_test.test, ser_test.accession, ser_test.update_date";
#$iquery.= " FROM ser2_test2 as ser_test ";
$iquery.= " FROM ser3_edit3 as ser_test ";
$iquery.= $WHERE_CLAUSE;
print "</div>\n";

$iquery.= " order by replace(replace(ser_test.nameauthor,\"[\",\"\"),'$doublequote',\"\"),replace(ser_test.shorttitle,\"[\",\"\") "; 


$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";
$iquery2="$iquery";
#print "$iquery2 <hr />";

$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());


if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";


$page_counter=0;

#there is an outer table started in ser-header_vone.php 
#   that ends outside while loop at bottom of this page
#   or in case of $serid_list=="0", ends above the start of while loop

#there is an inner table (one row, one col) inside the while loop for print
#<br class="pagebreak"> appears above each inner table after the first one

 while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$cetitle,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_repository,$loc_code,$xref,$sht,$kyw,$test,$acc,$update_date) = mysql_fetch_row($iresult))
  {
	
	if ($page_counter == 0 ) {
		$page_counter = 1;
	}else{
		$page_counter += 1;
		#print "<p class=\"pagebreakP\">\n";
		#print "<p STYLE=\"page-break-after: always\">&nbsp;</p>\n";
		#print "<p>&nbsp;</p>\n";
	}
	#print "<p>&nbsp;</p>\n";

/*--------------set table width------------------------------*/

  print "<table bgcolor=\"ffffff\" border=\"0\" width=\"620\" cellpadding=\"0\" cellspacing=\"0\" xclass=\"list\" >";
  print "<tr><td>";
  print "<table xbgcolor=\"ffffcc\" border=\"00\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">";
  print "<tr>";
  #LINE 1
  print "<td class=\"form2small\">$acc. $update_date <b>$na.</b> ($st $dn $da) <br>";
  #LINE 2
        $loc_print = ereg_replace($loc_code,"",$loc);
        $loc_print = ereg_replace(";", "", $loc_print);
  print "\"$srt\"  [$ida]  $npgs<br>" ;
  print "<br>";
  print "<i>Repository</i>: $loc_repository $loc_print<br>" ;
  #print "loc_print: $loc_print<br>";
  #print "loc_repository: $loc_repository<br>";
  #print "loc_code: $loc_code<br>";
  #print "loc: $loc<br>";
  #LINE 3
  if ($ibr) { print "<i>Bib. Ref.</i>: $br<br>"; }
  #LINE 4
  print "<i>Commentary</i>: $cmt<br>";
  #LINE 5
  if ($kyw) {print "<i>Keywords</i>: $kyw<br>";}
  print "</td></tr>";
  print "</table>";
  print "&nbsp;";
  print "</td></tr><tr><td>";


  print '</td></tr></table>'; #this ends the table started in this file
 

  }//end while

 }// end if (mysql_num_rows($iresult))    
} //end else 
 print "</td></tr></table>\n";##this ends the table named "outer"

/*
print "\$ser2_test2_alias: ";
print $ser2_test2_alias;
print "<hr>";
print "'$ser2_test2_alias '";
*/

?>

