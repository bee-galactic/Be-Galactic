<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

edit_update.php

*/
//-- declare functions



//--- end of functions
include "include_standard.php";
print $html_header;
print $html_header_closer;
include "./include_upper.php";


print "<table summary=\"\" border=\"00\" cellspacing=\"0\" cellpadding=\"2\" xwidth=\"720\"  width=\"740\">";
print "<tr><td align=\"left\">";

print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print " Update One Entry for the Sermons Database  ";
print "</div>\n";
print "</div>\n";
print "</td></tr></table>";

?>

<script language="javascript">
//write_serid_list();
//document.write("<BR>"+location.href+"<hr style=\"background-color:#a00000; height:10; width:720\">");
</script>
<?php
$serid_str         = $_GET['serid_list'];
//print "\$serid_string=$serid_str<hr>";

//build uquery values
#all values are enclosed in single quotes in the update query
#so escape the single quotes here

##identify database table [include_database_table_name.php]
#$ser2_test2_alias defined in include_database_table_name.php
#$ser2_test2_alias = "ser2_test2";
#$ser2_test2_alias = "ser3_edit3";
## $serid = $_GET['serid'];

$serid_str         = $_POST[serid];
#edit_sid_test commented out in edit_search.php
#$edit_sid_test_str =  str_replace("'","\'",$_POST['edit_sid_test']);
$edit_na_str       =  str_replace("'","\'",$_POST['edit_na']);
$edit_st_str	   =  str_replace("'","\'",$_POST['edit_st']);
$edit_dn_str	   =  str_replace("'","\'",$_POST['edit_dn']);
$edit_da_str	   =  str_replace("'","\'",$_POST['edit_da']);
$edit_cetitle_str  =  str_replace("'","\'",$_POST['edit_cetitle']);
$edit_srt_str	   =  str_replace("'","\'",$_POST['edit_srt']);
$edit_sbt_str	   =  str_replace("'","\'",$_POST['edit_sbt']);
$edit_tpgs_str	   =  str_replace("'","\'",$_POST['edit_tpgs']);
$edit_ppub_str	   =  str_replace("'","\'",$_POST['edit_ppub']);
$edit_pub_str	   =  str_replace("'","\'",$_POST['edit_pub']);
$edit_da2_str	   =  str_replace("'","\'",$_POST['edit_da2']);
$edit_pno_str	   =  str_replace("'","\'",$_POST['edit_pno']);
$edit_pda_str	   =  str_replace("'","\'",$_POST['edit_pda']);
$edit_ida_str	   =  str_replace("'","\'",$_POST['edit_ida']);
$edit_npgs_str	   =  str_replace("'","\'",$_POST['edit_npgs']);
$edit_br_str	   =  str_replace("'","\'",$_POST['edit_br']);
$edit_ibr_str	   =  str_replace("'","\'",$_POST['edit_ibr']);
$edit_cmt_str	   =  str_replace("'","\'",$_POST['edit_cmt']);
$edit_loc_str	   =  str_replace("'","\'",$_POST['edit_loc']);
$edit_loc_repository_str  =  str_replace("'","\'",$_POST['edit_loc_repository']);
$edit_loc_code_str =  str_replace("'","\'",$_POST['edit_loc_code']);
$edit_xref_str	   =  str_replace("'","\'",$_POST['edit_xref']);
$edit_sht_str	   =  str_replace("'","\'",$_POST['edit_sht']);
$edit_pfc_str	   =  str_replace("'","\'",$_POST['edit_pfc']);
$edit_kyw_str	   =  str_replace("'","\'",$_POST['edit_kyw']);
$edit_anote_str	   =  str_replace("'","\'",$_POST['edit_anote']);
$edit_pmb_str	   =  str_replace("'","\'",$_POST['edit_pmb']);
$edit_ci_str	   =  str_replace("'","\'",$_POST['edit_ci']);
$edit_acc_str	   =  str_replace("'","\'",$_POST['edit_acc']);
$edit_update_date_str =  str_replace("'","\'",$_POST['edit_update_date']);
$edit_test_str	   =  str_replace("'","\'",$_POST['edit_test']);


// inits for paging
$lim=5;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;

if (!isset($serid)) $serid=0;
if (!isset($snameauthor)) $snameauthor=""; 
if (!isset($cetitle)) $cetitle="";
if (!isset($stitle)) $stitle="";
if (!isset($sloc)) $sloc="";
if (!isset($sloc_code)) $sloc_code="";

$lnk=$PHP_SELF;
$lnk.="?r=1";
if ($serid) $lnk.="&serid=$serid";
if ($snameauthor) $lnk.="&snameauthor=$snameauthor";
if ($cetitle)  $lnk.="&cetitle=$cetitle";
if ($stitle)  $lnk.="&stitle=$stitle";
if ($sloc)  $lnk.="&sloc=$sloc";
//
// $rec is the current pos in results, the beginning of the list of $lim results
// determine rec to retrieve a new block of results
if ($inc)
  {
	$rec=$rec+$inc;
  if (($nh)&&($rec>=$nh)) $rec=$nh;
	}
if ($dec)
  {
	$rec=$rec-$dec;
  if ($rec <0) $rec=0;
	}

//
/*
print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print " Update Results for the Sermons Database (Sermon # $serid)";
print "</div>\n";
print "</div>\n";
*/

#print "<hr>";
#print "<p /><p />";

$uquery  = " UPDATE $ser2_test2_alias as ser_test  
	####set ser_test.sermon_test_id = '$edit_sid_test_str'  
	set ser_test.nameauthor  = '$edit_na_str'  
	  , ser_test.state       = '$edit_st_str'
	  , ser_test.denom       = '$edit_dn_str'
	  , ser_test.dates       = '$edit_da_str'
	  , ser_test.ser_title   = '$edit_srt_str'
	  , ser_test.cover_entry_title   = '$edit_cetitle_str'
	  , ser_test.book_title  = '$edit_sbt_str'
	  , ser_test.totalpgs    = '$edit_tpgs_str'
	  , ser_test.placepub    = '$edit_ppub_str'
	  , ser_test.publisher   = '$edit_pub_str'
	  , ser_test.date2       = '$edit_da2_str'
	  , ser_test.ser_pgno    = '$edit_pno_str'
	  , ser_test.placedate   = '$edit_pda_str'
	  , ser_test.indexdate   = '$edit_ida_str'
	  , ser_test.nopgs       = '$edit_npgs_str'
	  , ser_test.bibref      = '$edit_br_str'
	  , ser_test.indexbibref = '$edit_ibr_str'
	  , ser_test.comment     = '$edit_cmt_str'
	  , ser_test.libloc      = '$edit_loc_str'
	  , ser_test.loc_repository = '$edit_loc_repository_str'
	  , ser_test.libloc_code = '$edit_loc_code_str'
	  , ser_test.crossref    = '$edit_xref_str'
	  , ser_test.shorttitle  = '$edit_sht_str'
	  , ser_test.printface   = '$edit_pfc_str'
	  , ser_test.keywords    = '$edit_kyw_str'
	  , ser_test.authors_note = '$edit_anote_str'
	  , ser_test.pmb         = '$edit_pmb_str'
	  , ser_test.c_i         = '$edit_ci_str'
	  , ser_test.accession   = '$edit_acc_str'
	  , ser_test.update_date = '$edit_update_date_str'
	  , ser_test.test        = '$edit_test_str'
	where ser_test.pid = $serid_str";


$uresult = mysql_query($uquery, $link) or die ("Error in query: $uquery. " . mysql_error());





#print $uquery;
#print $uresult;
#print "<hr>";

if (($snameauthor) || ($cetitle) || ($stitle)||($serid)||($sloc))
{

$iquery = "SELECT ser_test.pid, ser_test.sermon_id,ser_test.sermon_test_id, ser_test.nameauthor, ser_test.state, ";
$iquery.= " ser_test.denom, ser_test.dates, ser_test.ser_title, ser_test.cover_entry_title, ser_test.book_title, ser_test.totalpgs, ";
$iquery.= " ser_test.placepub, ser_test.publisher, ser_test.date2, ser_test.ser_pgno, ser_test.placedate, ";
$iquery.= " ser_test.indexdate, ser_test.nopgs, ser_test.bibref, ser_test.indexbibref, ser_test.comment, ";
$iquery.= " ser_test.libloc, ser_test.loc_repository, ser_test.libloc_code, ser_test.crossref, ser_test.shorttitle, ser_test.printface, ";
$iquery.= " ser_test.keywords, ser_test.pmb, ser_test.c_i, ser_test.accession, ser_test.update_date, ser_test.test, ser_test.authors_note ";
$iquery.= " FROM $ser2_test2_alias as ser_test ";

if ($serid>1) 
  {
	$iquery.= "WHERE ser_test.pid=$serid ";
	}
else
  {
	#$iquery.= "WHERE ser_test.pid ";
	$iquery.= "WHERE 1=1 ";
	if ($snameauthor) $iquery.= "AND ser_test.nameauthor LIKE '%$snameauthor%' ";
  	if ($stitle) $iquery.= " AND ser_test.ser_title LIKE '%$stitle%' ";
  	if ($sloc) $iquery.= " AND ser_test.libloc LIKE '%$sloc%' ";
  	if ($sloc2) $iquery.= " AND ser_test.libloc LIKE '$sloc2%' ";
  }

print "</div>\n";


$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";
#print "$iquery2 <hr />";

$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());

// $pid,$sid,$sid_test,$na,$st,$dn,$da,$cetitle,$srt,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$xref,$sht
// $pid,$sid,$na,$st,$dn,$da,$cetitle,$srt,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$xref,$pfc,$sht,$kyw, $pmb,$ci,$acc, $test, $anote


if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";
 #PageLink();
 print "<div class=\"instruct\">&nbsp;</div>";
 print "<table border=\"1\" class=\"list\" summary=\"\" width=\"620\" cellpadding=\"4\" cellspacing=\"0\">\n";
 $bg="bg2";
 /*----------------------------------------------------------
 print '<tr class="bg_blue"><td>UPDATE QUERY: <br>';
 print $uquery;
 print '</td></tr>';
 print '<tr class="bg_blue"><td>SELECT QUERY: <br>';
 print $iquery;
 print '</td></tr>';
 -----------------------------------------------------------*/

 /*
 print "<tr>";
 print "<td >&nbsp;</td>\n";
 print "</tr>\n";
 */

 print "<tr>";
 print "<td class=\"label\">&nbsp;</td>\n";
 print "</tr>\n";
 //while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_code,$xref,$sht,$kyw) = mysql_fetch_row($iresult))

 while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$cetitle,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_repository, $loc_code,$xref,$sht,$pfc,$kyw,$pmb,$ci,$acc,$update_date,$test,$anote) = mysql_fetch_row($iresult))
  {
	if ($bg=="bg1") $bg="bg2";
	elseif ($bg=="bg2") $bg="bg1";

        /*------------------------------------------
	print "<tr class=\"$bg\">\n";
	print "<td>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">debug (usually hidden) pid: </div>\n";
	print "<div class=\"cont\">$pid</div>\n";
	print "</td></tr>";
	--------------------------------------------*/
	print "<tr class=\"$bg\">\n";
	print "<td width=\"760\" >\n";
      /*--------------------------------------------
	print "<div class=\"item\">";
	print "<div class=\"label\">Sermon ID #: </div>\n";
	print "<div class=\"cont\">$pid </div>[edit_update.php]\n";
	$sid_test2 = $sid_test;
  print "</div>\n";
	---------------------------------------------*/
	print "<div class=\"item\">";
	print "<div class=\"label\">Accession Number:</div>\n";
        print "<div class=\"cont\">$acc</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Update Date:</div>\n";
        print "<div class=\"cont\">$update_date</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Author:</div>\n";
	#$na=htmlentities($na); # remove this to make <i>...</i> work
	$na_2 = $na;
	$st_2 = $st;
	$dn_2 = $dn;
	$da_2 = $da;
	print "<div class=\"cont\">$na</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">State/Denom/Dates:</div>\n";
	print "<div class=\"cont\"> $st $dn $da</div>\n";
  print "</div>\n";
  if ($cetitle != "none") {
	print "<br />";
	print "<div class=\"item\">";
	print "<div class=\"label\">Cover Entry Title:</div>\n";
	#$srt=htmlentities($srt); #--------remove this to make <i>...</i> work
	$cetitle_2 = $cetitle;
	print "<div class=\"cont\">$cetitle</div>\n";
  print "</div>\n";
	}
	print "<br />";
	print "<div class=\"item\">";
	print "<div class=\"label\">Title:</div>\n";
	#$srt=htmlentities($srt); #--------remove this to make <i>...</i> work
	$srt_2 = $srt;
	print "<div class=\"cont\">$srt</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Place/Date Preached:</div>\n";
	$pda=htmlentities($pda);
	$pda_2=$pda;
  	print "<div class=\"cont\">$pda</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Date:</div>\n";
	$ida=htmlentities($ida);
	$ida_2=$ida;
  	print "<div class=\"cont\">$ida</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">nopgs:</div>\n";
	$npgs=htmlentities($npgs);
	$npgs_2=$npgs;
  	print "<div class=\"cont\">$npgs</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Biblical Ref.:</div>\n";
	#$br=htmlentities($br); # remove this to make <i>...</i> work
	$br_2 = $br;
  	print "<div class=\"cont\">$br</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Biblical Ref.:</div>\n";
	#$ibr=htmlentities($ibr); # remove this to make <i>...</i> work
	$ibr_2=$ibr;
  	print "<div class=\"cont\">$ibr</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Commentary:</div>\n";
	#$cmt=htmlentities($cmt); #remove this line to make <i>...</i> work
	$cmt_2=$cmt;
  	print "<div class=\"cont\">$cmt</div>\n";

 print "</div>\n";
        print "<div class=\"item\">";
        print "<div class=\"label\">Repository (Code):</div>\n";
        $loc_repository=htmlentities($loc_repository);
        $loc_repository_2=$loc_repository;
        $loc_code=htmlentities($loc_code);
        $loc_code_2=$loc_code;
  print "<div class=\"cont\">$loc_repository ($loc_code)</div>\n";

  $s2 = ereg_replace(";","",$loc);

  if ($s2 != $loc_code) {
  print "</div>\n";
        print "<div class=\"item\">";
        print "<div class=\"label\">Repository Details:</div>\n";
        $loc=htmlentities($loc);
        $loc_2=$loc;
  print "<div class=\"cont\">$loc</div>\n";
  }

/*
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Location:</div>\n";
	$loc=htmlentities($loc);
	$loc_2=$loc;
  	print "<div class=\"cont\">$loc</div>\n";

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Location Code:</div>\n";
	$loc_code=htmlentities($loc_code);
	$loc_code_2=$loc_code;
  	print "<div class=\"cont\">$loc_code</div>\n";
*/
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Short Title:</div>\n";
	#$sht=htmlentities($sht); #remove this line to make <i>...</i> work
	$sht_2=$sht;
  	print "<div class=\"cont\">$sht</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Keywords:</div>\n";
  	print "<div class=\"cont\">$kyw</div>\n";
	$kyw_2=$kyw;
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\"><font color=\"a00000\">Author's Note:</font></div>\n";
  	print "<div class=\"cont\"><font color=\"a00000\">$anote</font></div>\n";
	$anote_2=$anote;
  print "</div>\n";

  if ($test=='delete') {
        print "<table border=\"1\" cellpadding=\"4\" width=\"100%\" ><tr><td>";
	print "<div class=\"item\">";
	print "<div class=\"label\">******** This sermon record (ID # $pid) has been marked for deletion. ********</div>\n";
        print "</div>\n";
        print "</div>\n";
	print "</td></tr></table>";
	}

	//-----------------
	print "</td>\n";
	print "</tr>\n";
 print "<tr>";
 print "<td class=\"label\">&nbsp;</td>\n";
 print "</tr>\n";
# print "</table>\n";
 print "<tr><td>\n";

 #######################################EDIT##################################################################
 #print '<table width="100%" border="0"><tr><td>';
 #print '<table border="00" width="620" cellpadding="4" cellspacing="0"> ';

 print "<form method=\"get\" action=\"./edit_search.php?top=private\" name=\"edit_form\">\n";
 print '<input type="hidden" name="serid" value="';
 print $pid;
 print '">';
 print '<input type="hidden" name="pid_val" value="';
 print $pid;
 print '">';

 print '<tr xclass="bg_blue"><td align="left" colspan="2"><font face="arial" size="2" >';
 print '<input type="submit" value="Return to EDIT ONE ROW FOR Accession # ';
 print $acc;
 #print ' - action=edit_update.php"';
 print '" style="width:600; font:bold; color:#003366; background-color:#ddeeff;" name="">';
 print "<input type=\"hidden\" name=\"serid_list\" value=\"0,$pid\" >";
 print "<input type=\"hidden\" name=\"top\" value=\"private\" >";
 print '</font></td></tr>';


 print '</form>';
 #print '</table>';
 print '</td></tr></table>';


  }//end while
 print "</table>";

 #PageLink();
 print "<div class=\"instruct\">&nbsp;</div>";
 }// end if	mysql
} //end if stitle 
print "</div>\n";
print $footer;
?>
<script language=javascript src="elements.js"></script>
<script>
//show_elements defined in include_standard.php
show_elements=0;
if (show_elements==1) {
        elements();
}
</script>
