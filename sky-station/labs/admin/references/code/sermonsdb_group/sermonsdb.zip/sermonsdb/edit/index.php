<?php
header("location: sermons_public.htm");
exit();
?>
