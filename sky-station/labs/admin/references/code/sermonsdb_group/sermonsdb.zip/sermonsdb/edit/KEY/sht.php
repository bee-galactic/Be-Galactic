<html>
<head>
<title>sht</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="sht";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- T</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Take heed therefore how ye hear</option>
<option>Take heed to yourselves</option>
<option>Taking possession of the Episc. see of Baltre Decr 1790</option>
<option>Tares in the Church, Of the</option>
<option>Temple of God on Earth, The</option>
<option>Temptation and Wisdom, On</option>
<option>Temptations, offered by Satan to Jesus</option>
<option>Temptations, On</option>
<option>Temptations offered to men</option>
<option>Tenderness and Mercy of God, The</option>
<option>Tenth Commandment, On the</option>
<option>Terms and Qualifications of successful prayers, The</option>
<option>Testify the Gospel of the Grace of God</option>
<option>Textbook of Sermons Heard by Richard Dozier</option>
<option>Thanksgiving 1797, For the</option>
<option>Thanksgiving for national blessings</option>
<option>Thanksgiving on Feb. 19, 1795, For the</option>
<option>Thanksgiving Sermon, A</option>
<option>Thanksgiving Sermon, ... the President's Proclamation</option>
<option>Theft, On</option>
<option>Theological Responses</option>
<option>There is a reward for the righteous</option>
<option>There is no good in them, but for a Man to rejoice</option>
<option>There is no peace saith my God to ye Wicked</option>
<option>There Remaineth therefore a rest to the People of God</option>
<option>There shall come in the last days scoffers</option>
<option>Therefore be ye also ready</option>
<option>Thine is the kingdom</option>
<option>Things, in which we ought not, and that, in which we may glory</option>
<option>Things in which we ought not, and that in which we may glory</option>
<option>Third Article of the, On the</option>
<option>Third commandment, On the</option>
<option>This do in remembrance of me</option>
<option>Those, to whom there is no condemnation</option>
<option>Those who honor God</option>
<option>Three(?) Addresses to the Continental Army</option>
<option>Three Sermons by George Goundril</option>
<option>Through a Glass Darkly</option>
<option>Through him we both have an Access ... unto the Father</option>
<option>Thy Kingdom come</option>
<option>Thy kingdom come</option>
<option>Thy will be done</option>
<option>Thy will be done on earth as it is in heaven</option>
<option>To Whom is the Cup in the Sacrament a Cup of Blessing?</option>
<option>Together in Unity</option>
<option>Torments of Hell, On the</option>
<option>Transfiguration, On the</option>
<option>transitoriness of life, On the</option>
<option>Tribulation of the world</option>
<option>True and righteous believers</option>
<option>True church, On the one</option>
<option>True faith in Christ, On</option>
<option>True Honour of Man, On the</option>
<option>True religion, On</option>
<option>Truly God is good</option>
<option>Trust in God, On our</option>
<option>Trusting in the Lord, On</option>
<option>Truth</option>
<option>Truth of religion, On the</option>
<option>Truth of Revelation, The</option>
<option>Truth of the Old Testament</option>
<option>Truth of the Scriptures of the New Testament, The</option>
<option>Turning from sin to newness of life</option>
<option>Two Sermons</option>
<option>Two Sermons (1770) on Job 34 by Charles Clay</option>
<option>Two Sermons (1775) by Charles Clay</option>
<option>Two Sermons [by John Coleman]</option>
<option>Two Sermons [by Robert Preade (Read?)]</option>
<option>Two sermons and a charge to two newly ordained ministers</option>
<option>Two Sermons by Edward Gantt</option>
<option>Two Sermons by George Goundril</option>
<option>Two Sermons by John Coleman</option>
<option>Two Sermons by John Coleman (Acc. # 770)</option>
<option>Two Sermons by John Coleman (Acc. 790)</option>
<option>Two Sermons on the Death of Elder Lewis Lunsford</option>
<option>Two sermons undivided from Isai 44 Ch 3d vs</option>
<option>Two sermons undivided from Jer 3d Ch 19</option>
<option>Two sermons undivided from Lev 10 Ch 3d vs</option>



<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
