<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

view_one.php
The HTML header is in this file because this file pops up into a new window
when the PrintCart button is clicked.

*/
//-- declare functions

//--- end of functions
include "include_standard.php";

// ----------------------------- Begin HTML output ---------

print $html_header;
print $html_header_closer;

#print "print check 000<hr>";
?>
<table summary="" border="0" cellspacing="0" cellpadding="0">
<tr><td valign="top">
<?php

//serid and accid are the only variables passed
$serid = $_POST[serid];
$accid = $_POST[accid];

if (!$serid) { $serid= $_GET[serid]; }
if (!$accid) { $accid= $_GET[accid]; }

// inits for paging - because only one record, removed rest of paging code
$lim=1;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;


if ($serid)
{

$iquery = "SELECT ser_test.pid, ser_test.sermon_id, ser_test.sermon_test_id, ser_test.nameauthor, ser_test.state, ";
$iquery.= "ser_test.denom, ser_test.dates, ser_test.ser_title, ser_test.cover_entry_title,ser_test.book_title, ser_test.totalpgs, ";
$iquery.= "ser_test.placepub, ser_test.publisher, ser_test.date2, ser_test.ser_pgno, ";
$iquery.= "ser_test.placedate, ser_test.indexdate, ser_test.nopgs, ser_test.bibref, ser_test.indexbibref, ";
$iquery.= "ser_test.comment, ser_test.libloc, ser_test.loc_repository, ser_test.libloc_code,ser_test.crossref, ser_test.shorttitle, ser_test.keywords , ser_test.test, ser_test.accession, ser_test.update_date";
#$iquery.= " FROM ser2_test2 as ser_test ";
$iquery.= " FROM ser3_edit3 as ser_test ";
$iquery.= " WHERE ser_test.pid=$serid ";

print "</div>\n";


$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";
#print "$iquery2 <hr />";

$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());


if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";

 print "<table border=\"0\" class=\"list\" summary=\"\" width=\"700\" cellpadding=\"4\">\n";

 $bg="";


 while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$cetitle,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_repository,$loc_code,$xref,$sht,$kyw,$test,$acc,$update_date) = mysql_fetch_row($iresult))
  {

  print "<tr><td>";

print $masthead_header;
  print "</td></tr>";

	print "<tr class=\"$bg\">\n";
	print "<td>\n";

	print "<div class=\"item\">";
	print "<div class=\"label\">Accession #:</div>\n";
	print "<div class=\"cont\">$acc $update_date</div>\n";
  print "</div>\n";

	print "<div class=\"item\">";
	print "<div class=\"label\">Author:</div>\n";
	$na=htmlentities($na); # remove this to make <i>...</i> work
	$na_2 = $na;
	$st_2 = $st;
	$dn_2 = $dn;
	$da_2 = $da;
	print "<div class=\"cont\">$na</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">State/Denom/Dates:</div>\n";
	print "<div class=\"cont\"> $st $dn $da</div>\n";
  print "</div>\n";
 if ($cetitle != "none") {
        print "<br />";
        print "<div class=\"item\">";
        print "<div class=\"label\">Cover Entry Title:</div>\n";
        #$srt=htmlentities($srt); #--------remove this to make <i>...</i> work
        $cetitle_2 = $cetitle;
        print "<div class=\"cont\">$cetitle</div>\n";
  print "</div>\n";
        }
	print "<div class=\"item\">";
	print "<div class=\"label\">Title:</div>\n";
	#$srt=htmlentities($srt); # remove this to make <i>...</i> work
	$srt_2 = $srt;
	print "<div class=\"cont\">$srt</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Place/Date Preached:</div>\n";
	$pda=htmlentities($pda);
	$pda_2=$pda;
  	print "<div class=\"cont\">$pda</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Date:</div>\n";
	$ida=htmlentities($ida);
	$ida_2=$ida;
  	print "<div class=\"cont\">$ida</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Number Pages:</div>\n";
	$npgs=htmlentities($npgs);
	$npgs_2=$npgs;
  	print "<div class=\"cont\">$npgs</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Biblical Ref.: </div>\n";
	#$br=htmlentities($br);
	$br_2 = $br;
  #print "<div class=\"cont\">$br</div>\n";
	print '<table border="00" cellpadding="0"><tr><td valign="top">';
	print "<font face=\"Verdana, Arial, Helvetica\" size=\"2\">$br</font>";
	print '</td></tr></table>';
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Biblical Ref.:</div>\n";
	#$ibr=htmlentities($ibr); # remove this to make <i>...</i> work
	$ibr_2=$ibr;
  print "<div class=\"cont\">$ibr</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Commentary:</div>\n";
        #print "<div class=\"cont\">$cmt</div>\n";
	#$cmt=htmlentities($cmt); #remove this line to make <i>...</i> work
	$cmt_2=$cmt;
	print '<table border="00" cellpadding="0"><tr><td valign="top">';
	print "<font face=\"Verdana, Arial, Helvetica\" size=\"2\">$cmt</font>";
	print '</td></tr></table>';
	
  #print "<div class=\"cont\">$cmt</div>\n";

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Repository (Code):</div>\n";
        $loc_repository=htmlentities($loc_repository);
        $loc_repository_2=$loc_repository;
        $loc_code=htmlentities($loc_code);
        $loc_code_2=$loc_code;
  print "<div class=\"cont\">$loc_repository ($loc_code)</div>\n";

 $s2 = ereg_replace(";","",$loc);

  if ($s2 != $loc_code) {
  print "</div>\n";
        print "<div class=\"item\">";
        print "<div class=\"label\">Repository Details:</div>\n";
        $loc=htmlentities($loc);
        $loc_2=$loc;
  print "<div class=\"cont\">$loc</div>\n";
  }


  print "<div class=\"cont\">$xref</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Short Title:</div>\n";
	#$sht=htmlentities($sht); #remove this line to make <i>...</i> work
	$sht_2=$sht;
  print "<div class=\"cont\">$sht</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">keywords:</div>\n";
  print "<div class=\"cont\">$kyw</div>\n";
	$kyw_2=$kyw;
  print "</div>\n";
  if ($test=='delete') {
        print "<table border=\"1\" cellpadding=\"4\" width=\"100%\" bgcolor=\"ffffff\"><tr><td>";
	print "<div class=\"item\">";
	print "<div class=\"label\">******** This sermon record ($pid) has been marked for deletion. ********</div>\n";
        print "</div>\n";
	print "</td></tr></table>";
	}
	//-----------------
	print "</td>\n";
	print "</tr>\n";


  }//end while
 print "</table>";

 }// end if	mysql
} //end if stitle 
print "</div>\n";
  print "<div>\n";
  #standard footer below
  #to use print $footer; must include include_standard.php
  print $footer;
  print "</div>\n";
?>

