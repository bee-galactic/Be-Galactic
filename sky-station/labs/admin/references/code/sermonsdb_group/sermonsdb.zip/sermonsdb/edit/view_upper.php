<?php
#$chd_debug_php=false;
#ser8/view_upper.php
?>
<html>
<head>
<title>view_upper</title>
<link rel="stylesheet" type="text/css" href="ser.css" />
</head>
<body bgcolor="adeeff" vlink="003366" alink="003366" link="003366">
<script language="javascript">
document.write(location.href);
</script>

</body>
</html>
