<html>
<head>
<title>kwp</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwp";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- P</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>pagan beliefs concerning death</option>
<option>pagan gods</option>
<option>pagan philosophy, shortcomings of</option>
<option>pagan sacrifice</option>
<option>pagans, beliefs of</option>
<option>pagans, comfort of</option>
<option>Paine, Thomas</option>
<option>Palestine</option>
<option>Paley</option>
<option>Palm Sunday</option>
<option>Papists</option>
<option>Papists, error of</option>
<option>parable of the disobedient servants</option>
<option>parable of the fig tree</option>
<option>parable of the foolish virgins</option>
<option>parable of the Good Samaritan</option>
<option>parable of the householder</option>
<option>parable of the marriage of the King's son</option>
<option>parable of the mustard-seed</option>
<option>parable of the Pharisee & the Publican</option>
<option>parable of the prodigal son</option>
<option>parable of the rich man</option>
<option>parable of the Rich man and Lazarus</option>
<option>parable of the sower</option>
<option>parable of the talents</option>
<option>parable of the tares</option>
<option>parable of the tares and wheat</option>
<option>parable of the unjust steward</option>
<option>parable of the unprofitable servant</option>
<option>parable of the vine and its branches</option>
<option>parable of the wicked servant</option>
<option>parable of the wise and foolish virgins</option>
<option>parable of the wise virgins</option>
<option>parables, Christ's use of</option>
<option>paradise, meaning of the word</option>
<option>pardoning</option>
<option>parental authority</option>
<option>parental duties</option>
<option>parents</option>
<option>parents, disobedience to</option>
<option>parents, duties of</option>
<option>parents, duty to children</option>
<option>parents, responsibilities of</option>
<option>parents, responsibilities toward children</option>
<option>parents, training of children</option>
<option>passion</option>
<option>passion, conflict with reason</option>
<option>passion, conquers reason</option>
<option>Passion of Christ</option>
<option>Passion Sunday</option>
<option>passions, governing of</option>
<option>passions, mortification of</option>
<option>Passover</option>
<option>pastor, removal of</option>
<option>pastoral duties</option>
<option>pastors, duties of</option>
<option>pastors, obedience to</option>
<option>patience</option>
<option>patience, degree of</option>
<option>patience, divine</option>
<option>patience, duty of</option>
<option>patience, God's</option>
<option>patience of God</option>
<option>patience under afflictions</option>
<option>patriarchs, prophecies of</option>
<option>patriotism</option>
<option>Paul</option>
<option>Paul, accused by Tertullus</option>
<option>Paul, background of</option>
<option>Paul, conformity to Jewish law</option>
<option>Paul, conversion of</option>
<option>Paul, fear of losing God's favor</option>
<option>Paul, instructions concerning the dead</option>
<option>Paul, persecutions endured by</option>
<option>Paul, teachings of</option>
<option>Paul. teachings of</option>
<option>Paxton, John</option>
<option>peace</option>
<option>peace, blessings of</option>
<option>peace, covenant of</option>
<option>peace, none for the wicked</option>
<option>peace, way of</option>
<option>peace of mind</option>
<option>Pellentz, Rev. James</option>
<option>Pelopidas the Theban</option>
<option>penance</option>
<option>penance, advantages of</option>
<option>penance, sacrament of</option>
<option>penitence</option>
<option>penitence, true</option>
<option>penitent sinners</option>
<option>penitent thief</option>
<option>Pennsylvania Academy</option>
<option>Pentecost</option>
<option>Pentecost, evidence for</option>
<option>perfectibility of man</option>
<option>Perrigo, John, funeral of</option>
<option>persecution</option>
<option>perseverance</option>
<option>Persian Empire, destruction of</option>
<option>pestilence</option>
<option>Peter</option>
<option>Peter, defense of Christ by</option>
<option>Peter, denial of Christ</option>
<option>Peter, repentance of</option>
<option>Pharaoh, defeat of</option>
<option>Pharisees</option>
<option>Pharisees, hypocritcal actions of</option>
<option>Pharisees, pride of</option>
<option>Pharisees, scribes of</option>
<option>Philadelphia, public charities in</option>
<option>philanthropy</option>
<option>Philistines</option>
<option>Phillips, Rev. Vincent</option>
<option>philosophers, ancient</option>
<option>philosophers, Greek</option>
<option>philosophers, mistakes of ancient</option>
<option>philosophers, Roman</option>
<option>philosophy, ancient</option>
<option>philosophy, inadequacy of</option>
<option>Philpot, Miss Ann, funeral of</option>
<option>Phinehas, son of Eli</option>
<option>Physical postures for Worship, denial of importance</option>
<option>piety</option>
<option>piety, importance of</option>
<option>Pilate, Pontius</option>
<option>pity</option>
<option>Pius VI, Pope, death of</option>
<option>planets</option>
<option>Plato</option>
<option>Platonism</option>
<option>pleasing men, benefits of</option>
<option>pleasing men, limitations of</option>
<option>pleasure</option>
<option>pleasure, carnal</option>
<option>pleasure, immoderate pursuit of</option>
<option>pleasure, innocent</option>
<option>pleasure, sensual</option>
<option>pleasure, sinful</option>
<option>plundering</option>
<option>political sermon</option>
<option>polygamy</option>
<option>polytheism</option>
<option>poor</option>
<option>poor, duties of</option>
<option>poor, necessity of</option>
<option>poor, obligation to help the</option>
<option>poor, reason for</option>
<option>Pope</option>
<option>pornography</option>
<option>Porter, Mrs. R., funeral of</option>
<option>possessions, transitory nature of</option>
<option>possessions, worldly</option>
<option>poverty</option>
<option>poverty, blessings of</option>
<option>poverty, causes of</option>
<option>poverty, virtues of</option>
<option>Powel, Mrs.</option>
<option>power</option>
<option>power, right use of</option>
<option>power of God</option>
<option>Praise, duty of</option>
<option>prayer</option>
<option>prayer, daily</option>
<option>prayer, definition of</option>
<option>prayer, duty and benefit of</option>
<option>prayer, efficacy of</option>
<option>prayer, evening</option>
<option>prayer, family</option>
<option>prayer, forms of</option>
<option>prayer, importance of</option>
<option>prayer, ineffectual</option>
<option>prayer, language of</option>
<option>prayer, necessity of</option>
<option>prayer, neglect of</option>
<option>prayer, private</option>
<option>prayer, proper</option>
<option>prayer, proper preparation for</option>
<option>prayer, proper sentiments to accompany</option>
<option>prayer, public</option>
<option>prayer, secret</option>
<option>prayer, successful</option>
<option>Prayer of 1789 (Episc.)</option>
<option>preacher, office of</option>
<option>preachers, monetary support of</option>
<option>preaching</option>
<option>preaching, efficacy of</option>
<option>preaching, value of</option>
<option>preaching style</option>
<option>predestination</option>
<option>predestination, a mistaken doctrine</option>
<option>predestination, condemnation of</option>
<option>predestination, contradicted by reason and scripture</option>
<option>premarital intercourse prohibited</option>
<option>preparation for communion</option>
<option>preparation for death</option>
<option>Presbyterian doctrine</option>
<option>presumptuous sin, avoidance of</option>
<option>presumptuous sin, cause of</option>
<option>presumptuous sin, danger of</option>
<option>pride</option>
<option>pride, absence of in heaven</option>
<option>pride, adverse effect of</option>
<option>pride, evils of</option>
<option>pride, human</option>
<option>pride, moral</option>
<option>pride, prevents faith</option>
<option>pride, sin of</option>
<option>pride, spiritual</option>
<option>priest, consecration of a</option>
<option>priesthood</option>
<option>priests</option>
<option>priests, doing honor to</option>
<option>primitive church, practices of</option>
<option>Princeton</option>
<option>procrastination</option>
<option>procrastination, effects of</option>
<option>prodigal son, parable of</option>
<option>profanation of the name of God</option>
<option>profanity</option>
<option>property, power of</option>
<option>property, rights of</option>
<option>prophecies</option>
<option>prophecies, fulfillment of</option>
<option>prophecies concerning Christ</option>
<option>prophecies concerning the Messiah</option>
<option>prophecies of Christ</option>
<option>prophecies of Isaiah</option>
<option>prophecies of Messiah</option>
<option>prophecy</option>
<option>prophecy, argument from</option>
<option>prophecy, Christ's fulfillment of</option>
<option>prophecy, gift of</option>
<option>prophecy of Haggai</option>
<option>prophecy of Jacob</option>
<option>prophecy of the coming of Christ</option>
<option>prophet, promise of a</option>
<option>prophetic powers of Christ</option>
<option>prophets</option>
<option>prophets, behavior of</option>
<option>prophets, false</option>
<option>prophets, revelation by</option>
<option>prosperity</option>
<option>prosperity, dangers of</option>
<option>prosperity, temptations of</option>
<option>protection, God's</option>
<option>Protestant Episcopal Church, bishops of</option>
<option>Protestantism</option>
<option>providence</option>
<option>providence, dispensations of</option>
<option>providence, distrust of</option>
<option>providence, divine</option>
<option>providence, faith in</option>
<option>providence, reliance on</option>
<option>providence, resignation to</option>
<option>providence, role of</option>
<option>Provincial Congress, S. C.</option>
<option>Pryce, William</option>
<option>Psalms</option>
<option>psychology, religious views of</option>
<option>public good, promoting the</option>
<option>public morality</option>
<option>public servants, duties of</option>
<option>public worship</option>
<option>public worship, importance of</option>
<option>public worship, neglect of</option>
<option>Publican, repentant</option>
<option>Publicans</option>
<option>Pulses, Jacob</option>
<option>punishment</option>
<option>punishment, eternal</option>
<option>purgatory</option>
<option>purification</option>
<option>purity</option>
<option>purity of Heaven</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
