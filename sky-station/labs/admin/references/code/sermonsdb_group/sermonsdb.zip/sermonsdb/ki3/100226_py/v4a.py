#file v4a.py copied from v3a.py 100213

#python v4a.py a1.txt b1.txt c1.txt d1.txt ---feb 13 2010

#note: a2.txt has the header and trailer added
#      a0.txt is text file exported from kw_081104 table
#header:	kpid	kwd	acc	acc_txt	acc_int
#trailer:	end	end	end	end	end


#kw_a0acc.txt
#header:	kwd	acc_txt
#trailer:	end	end


#p 447 LP3E
# chr(65)  returns 'A'
# ord('A') returns 65

import sys
print  sys.argv
A=open(sys.argv[1],'r') #a1.txt
B=open(sys.argv[2],'w') #b1.txt
C=open(sys.argv[3],'w') #c1.txt
D=open(sys.argv[4],'w') #d1.txt


KW=[] #each row has one col, sorted by alphabetical order of kw's+acc's, written to b1.txt
KW2=[] 	#each row has two cols, 
       	#col 1 is keywords, sorted alphabetically by row
	#col 2 is single acc_txt, rows sorted by alpha order
	#printed as c2.txt
KW3=[]  #each row has two cols
	#col 1 is keywords, sorted alphabetically by row
	#col 2 has comma separated list of acc for each kw
	#printed as d2.txt
 
spacer  = '\t' #has unintended consequences
N=0
g=A.readline() #read header row from A a1.txt
dbegin='keyword (or phrase)	accession number(s)\n'
B.write(g) #header for B b3.txt
C.write(g) #header for C c3.txt
D.write(dbegin) #header for D d3.txt
print g
h=g.split('\t')
#h[0]=kpid
#h[1]=acc_txt
#h[1]=kwd
#h[2]=acc
#h[3]=acc_txt
#h[4]=acc_int
#all of these are strings, h is a list
header_line=g
#need boundary values for loop to close gracefully
#begin	header
#middle data
#end	trailer
KW.append(header_line)
while h[0] != 'end':
	#while N<12:
	g=A.readline()
	gg=g.replace('\n','')
	h=gg.split('\t')
	i=h[0] # list of keywords, separated by ';'
	#need to clean out trailing '.' at end of lines
	LENi = len(i)
	if i[len(i)-2]=='.':
		i=i[:len(i)-2]+';'
		#
		#
	i=i.replace('; ',';')#space after ';' for readability on web page
	kw=i.split(';')
	LENkw=len(kw)
	#####accForSort = acc_int   + kpid     +acc
	####accForSort  = h[3]+'www'+h[0]+'zzz'+h[2]
	####LENkw=len(kw)-1 #remove last chunk after last ';' which includes newline
	#accForSort = acc_txt
	accForSort  = h[1]+'zzznodata'
	LENkw=len(kw)-1 #remove last chunk after last ';' which includes newline
	z=0
	while z<LENkw:
		dd= kw[z]+'\t'+accForSort+'\n'
		ee= accForSort+'\t'+kw[z]+'\n'
		cc= kw[z].lower()+' xxx '+kw[z]+' yyy '+accForSort+'\n'
		KW.append(cc)
		#C.write(cc) # end up with non alphabetized file
		#print dd
		z=z+1
		#
		#
	N=N+1
	#
	#
#sort rows by alphabet on keywords
KW.sort()
print 'len(KW)=',len(KW)
z=0
while z<len(KW):
	bb=KW[z]
	B.write(bb)
	#C.write(bb) #this writes alphabetized version
	z=z+1
	#
	#
C.write('\n=========end alpha version==========\n\n')
#take one row at a time, sort col 2 by numeric order (acc_int)
z=1 #skip header
LENKW=len(KW)-1 #skip trailer
while z<LENKW:
	row=KW[z]
	#need to chop off lower case prefix
	x_index = row.find('xxx ')+4
	row=row[x_index:]
	#C.write(row) #successful chop
	KW2=row.split(' yyy ')
	col1=KW2[0] #keyword
	if len(KW2)>1:
		col2=KW2[1] #acc list
	else:
		col2='nodatazzznodata'
		#
		#
        #chop off acc_int+'www'+kpid-#never added so  not chop
	#z_index=col2.find('zzz')+3
	#col2=col2[z_index:]
	accList=col2.split('zzz') 
	accList.sort()
	col2_sorted=accList[0]
	y=1
	while y<len(accList):
		col2_sorted=col2_sorted+', '+accList[y]
		y=y+1
		#
		#
	#row=col1+'\t'+col2_sorted
	row=col1+spacer+col2_sorted
	row=row.replace(", nodata","")
	row=row.replace("a0000","")
	row=row.replace("a000","")
	row=row.replace("a00","")
	row=row.replace("a0","")
	C.write(row) #c1.txt, one kw, one acc per row but sorted correctly
	KW3.append(row)
	z=z+1
	#
	#
KW3.append('end	end')
LENKW3=len(KW3)
z=0
tempKWD = 'start'
tempACC = '0, 5555'
tempACCcount =0
longlist = 0

print 'len(KW3)=',len(KW3)

while z<LENKW3:
	#do something
	d=KW3[z]
	cols=d.split('\t')
	if len(cols)==2:
		cols1=cols[1]
		cols1=cols1.replace('\n','')
		cols[1]=cols1
		if cols[0]!=tempKWD:
			#store prev values	
			tempACCcount=0
			if longlist==1:
				#prevROW = spacer +'\t'+tempACC +'\n'
				prevROW = spacer +tempACC +'\n'
			else:
				#prevROW = tempKWD+'\t'+tempACC +'\n'
				prevROW = tempKWD+spacer+tempACC +'\n'
				#
				#
			D.write(prevROW)#d1.txt, one kw, list of acc's
			#start new values
			longlist=0
			tempKWD=cols[0]
			tempACC=cols[1]
		else: #add new acc to tempACC list
			tempACCcount=tempACCcount+1
			if tempACCcount%12==0:
				longlist=1
				#write current list with orig tempKWD
				#init new list of tempACC
				if tempACCcount < 14:
					#thisROW= tempKWD+'\t'+tempACC+',\n'
					thisROW= tempKWD+spacer+tempACC+',\n'
				else:
					#thisROW= spacer+'\t'+tempACC+',\n'
					thisROW= spacer+tempACC+',\n'
					#
					#
				D.write(thisROW)
				tempACC=cols[1]
			else:
				tempACC=tempACC+', '+cols[1]
				#
				#
			#
			#
		#
		#
	z=z+1
	#
	#

dend='keyword (or phrase)	accession number(s)\n'
B.write(dend) #trailer for b3.txt
C.write(dend) #trailer for c3.txt
D.write(dend) #trailer for d3.txt
A.close()
B.close()
C.close()
D.close()
print N,' rows processed'
print 'the end', sys.argv

#python v3a.py a3.txt b3.txt c3.txt d3.txt
#python v3a.py a3.txt b3.txt c3.txt d3a.txt
#python v3a.py a3.txt b3.txt c3.txt d3b.txt
