<?php
#search_explain.php
?>
<html>
<head><title>search_explain</title>
<link rel="stylesheet" type="text/css" href="ser.css" />
<?php
include "include_standard2.php";
print $html_header;
print $html_header_closer;
?>
</head>
<body>
<div class=\"instruct\">
<table summary="" xbgcolor="a99999" bgcolor="ffffff" border="00" cellspacing="0" cellpadding="2" xwidth="740" width="720" name="first_upper">
<tr><td >
<font face="verdana" size="2" color="#000000">&nbsp;University of Tennessee  Digital Library</font>
<div>
<div class="info">
<div class="infotag">
Southern Manuscript Sermons before 1800:  A Bibliographic Database<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;edited by Michael A. Lofaro</div>
</div>
</div>
</td></tr>
<tr><td>
<table summary="" border="00" cellspacing="0" cellpadding="2" width="720" xwidth="640">
<tr><td align="left">
<div>
<div class="info">
<div class="infotag">
How to search the Sermons Database
</div>
</div>
</div>
</td></tr>
<tr><td align="left" class="form2">
<br>&nbsp;<br>
On the Search Page you will see Search Term Input Boxes and Search Term Selection Menus.
<p>
Choose search terms from selection menus or enter search terms by typing into the 

input boxes. 
<p>
For example, click on the "A" in the Keyword search. 
<p>
This  brings up a menu for all Keywords starting with "A". 
<p>
In the menu, click on "Adam" to enter "Adam" in the Keywords input box. 
<p>
Click on the Full Results button. 
<p>
The entries returned will contain "Adam", and 

"Adam's curse", and "President John Adams" in the results. 

<p>
Likewise selecting "U" and then "unity" will return all keyword phrases
containing "unity", "Unity", and "community".
<p>
Results are displayed below the menus and input boxes.
</td></tr></table>
</td></tr></table>

</div>

</body>
</html>
