<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging


edit_search.php   

THIS IS VERSION CONTAINS comment_long display
AND authors_note field (080818)
add update_date 090807

*/

##identify database table [include_database_table_name.php]
#$ser2_test2_alias defined in include_database_table_name.php
#$ser2_test2_alias = "ser2_test2";
#$ser2_test2_alias = "ser3_edit3";


$serid = $_GET['serid'];
if ($serid==""){
	$serid = "0";
	}


$serid_str         = $_GET['serid_list'];
iF ($serid_str==""){
	$serid_str = "0";
	}

$markov_CSD = $_GET['smarkov_CSD'];#have to do this at top!

$display_choice = $_GET['display_choice']; #LINE 15
if (!$display_choice) {
        $display_choice=0;
        }

//-- declare functions

//--- end of functions

include "./include_standard.php";
print $html_header;
print $html_header_closer;
include "./include_upper.php";

?>
<script language="javascript">
//write_serid_list();
//document.write(location.href+"<hr style=\"background-color:#a00000; height:10; width:720\">");

/* using document.forms[12].mark to set document.forms[12].edit_test
print '<select name="mark" size="2" onchange="reset_delete(this);"><option value="keep" ';
print  $select_keep ;
print ' >keep this record</option><option value="delete" ';
print  $select_del;
print ' >mark this record for deletion</option></select>&nbsp;';
print ' <input type="text" value="';
print $test;
print '" name="edit_test" size="50" READONLY>';
*/

/* chd 100313 -- use dynamic sbox.form.name instead of forms[13] */
/* because the idx of forms array can change as side effect of other changes */
/* which is why this function kept breaking!!!!! */
function reset_delete(sbox){
//alert("sbox.value="+sbox.value +"\nsbox.form.name="+sbox.form.name);
var full_element_decl=new String();
    full_element_decl="document."+sbox.form.name+".edit_test.value=sbox.value;";
//alert("full_element_decl=\N"+full_element_decl);
//document.forms[13].edit_test.value=sbox.value;//old way hard code forms[13]
eval(full_element_decl);
}


///print " onclick=\"submit_edit_update($pid);\" ";

function submit_edit_update(PID){
//alert("get_edit_form("+PID+")");
var formname=new String("edit_form_for_pid_");
    formname=formname+PID;
var elemname=new String("serid_for_pid_");
    elemname=elemname+PID;

var this_serid=new String();
    //this_serid=eval("document."+formname+"."+elemname+".value"); 
    this_serid=PID;
//alert("this_serid="+this_serid);
    eval("document."+formname+".serid.value="+this_serid);
    eval("document."+formname+".action=\"./edit_search.php\";"); 
    eval("document."+formname+".submit();"); 
}

</script>

<?php
print "<table summary=\"\" border=\"00\" cellspacing=\"0\" cellpadding=\"2\" width=\"740\">";
print "<tr><td align=\"left\">";

print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print " Search and Edit from the Sermons Database ";
print "</div>\n";
print "</div>\n";
print "</td></tr></table>";

include "./include_pagelink_SEARCH.php";
include "./include_checkbox_functions.php";
#include "./include_search_functions.php";
include "./include_edit_functions.php";

if (!$_GET['serid_list']){
	$serid_str = "0";
}else{
	$serid_str = $_GET['serid_list'];
}
$top="private";
#print "\$serid=$serid<br>\$serid_string=$serid_str<br>\$top=$top<hr>";

// inits for paging
$lim=5;
if ($display_choice==1) $lim=20;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;

if (!isset($serid)) $serid=0;
if (!isset($top)) $top="private";
if (!isset($serid_list)) $serid_list=$serid;
if (!isset($smarkov_key)) $smarkov_key="nau";
if (!isset($sacc)) $sacc="0";
if (!isset($supdate_date)) $supdate_date="";
if (!isset($snameauthor)) $snameauthor=""; 
if (!isset($cetitle)) $cetitle="";
if (!isset($state)) $state="";
if (!isset($denom)) $denom="";
if (!isset($CSDval)) $CSDval="";
if (!isset($markov_CSD)) $markov_CSD="Cover Entry Title";
if (!isset($stitle)) $stitle="";
if (!isset($sloc)) $sloc="";
if (!isset($slibloc_code)) $slibloc_code="";
if (!isset($sibr)) $sibr="";
if (!isset($sida)) $sida="";
if (!isset($skey)) $skey="";
if (!isset($sht)) $sht="";
if (!isset($scmt)) $scmt="";
if (!isset($sbr)) $sbr="";
if (!isset($nopgs)) $nopgs="";
if (!isset($stest)) $stest="";

###need to add chbx vars

$lnk=$PHP_SELF;
$lnk.="?r=1";
if ($display_choice)$lnk.="&display_choice=$display_choice";
if ($serid) $lnk.="&serid=$serid";
if ($top) $lnk.="&top=$top";
if ($serid_list) $lnk.="&serid_list=$serid_list";
if ($smarkov_key) $lnk.="&smarkov_key=$smarkov_key";
if ($sacc) $lnk.="&sacc=$sacc";
if ($supdate_date) $lnk.="&supdate_date=$supdate_date";
if ($snameauthor) $lnk.="&snameauthor=$snameauthor";
if ($cetitle) $lnk.="&cetitle=$cetitle";
if ($state) $lnk.="&state=$state";
if ($denom) $lnk.="&denom=$denom";
if ($CSDval) $lnk.="&CSDval=$CSDval";
if ($markov_CSD) $lnk.="&smarkov_CSD=$markov_CSD";
if ($stitle)  $lnk.="&stitle=$stitle";
if ($sloc)  $lnk.="&sloc=$sloc";
if ($slibloc_code)  $lnk.="&slibloc_code=$slibloc_code";
if ($sibr)  $lnk.="&sibr=$sibr";
if ($sida)  $lnk.="&sida=$sida";
if ($skey)  $lnk.="&skey=$skey";
if ($sht)  $lnk.="&sht=$sht";
if ($scmt)  $lnk.="&scmt=$scmt";
if ($sbr)  $lnk.="&sbr=$sbr";
if ($nopgs)  $lnk.="&nopgs=$nopgs";
if ($stest)  $lnk.="&stest=$stest";

###need to add chbx vars

//
// $rec is the current pos in results, the beginning of the list of $lim results
// determine rec to retrieve a new block of results
#################nh is undefined 090828 chd


if ($inc)
  {
	$rec=$rec+$inc;
  if (($nh)&&($rec>=$nh)) $rec=$nh;
	}
if ($dec)
  {
	$rec=$rec-$dec;
  if ($rec <0) $rec=0;
	}

//end php functions
#print "xxx \$serid=$serid<hr>";
#print "$PHP_SELF";

if ($smarkov_key==""){
	$smarkov_key="nau";
	}


?>

<script language="javascript">
//var bbbbbb=" ///this is line 1065
var markov_key=new String("nau");

///LINE 199

function submit_search_form(N){
var n=N;
document.search_form.display_choice.value=n;
//alert ("submit_search_form N="+n);

document.search_form.submit();
}

function submit_search_form_add_new(N){
var n=N;
var new_acc = new String(document.search_form.sacc.value);
document.search_form.display_choice.value=n;
//alert ("submit_search_form_add_new N="+n);
if (new_acc=="") {new_acc="(BLANK)";}
alert("Accession Number="+new_acc);
if (new_acc == "0" || new_acc=="(BLANK)"){
	alert("You must enter a valid Accession Number, \nnot "+new_acc+".");
	return;
	}
if (!confirm("This will add a new record to the Sermons Database.\n\n"
	+"The new record will automatically be assigned \n\n"
	+"Accession Number: "+new_acc+". \n\n"
	+"Do you wish to continue?")) return;

document.search_form.submit();
}
</script>


<?php
/*
print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print " Search and Edit from the Sermons Database ";
print "</div>\n";
print "</div>\n";
*/
#print $se_header;
#print "<div class=\"form\" name=\"enclose_search_form\">\n";

#########################################SEARCH FORM################################################################

print "<form method=\"get\" action=\"./edit_search.php\" name=\"search_form\">\n";
#print "This links to db table: $ser2_test2_alias";
#print "edit_search.php";
#print "Limit by a partial string in one or more of the fields below.<br /><font size=\"2\">Note that the apostrophe (') is replaced by the percent sign (%)to build the search query.</font><br /><br />\n";

print "<font face=\"verdana\" size=\"2\">Choose search terms from selection menus or enter search terms by typing into the input boxes. <a href=\"./search_explain.php\" target=\"_blank\">More.</a></font><br />\n";
#print "<font size=\"2\">Enter search terms by selecting from menus on the right or by typing into the input boxes below.</font><br />\n";
#print "<font size=\"2\">For example, entering \"apostle\" into Keywords will return entries with Keywords containing<br />\"apostle\", \"apostles\", and \"Apostles' Creed\".</font><br /><br />\n";
print '<table border="01" cellpadding="08" cellspacing="0" width="560" xbgcolor="ddddff">';
print '<tr><td rowspan="1" valign="top" width="454">';
print '<table border="1" cellpadding="2" cellspacing="0" bgcolor="ddeeff" xbgcolor="ffddff" xwidth="340" name="search_form_table">';

print "<input type=\"hidden\" name=\"serid\"        value=\"$serid\" />\n";
print "<input type=\"hidden\" name=\"top\"   value=\"private\"  /> \n";
print "<input type=\"hidden\" name=\"serid_list\"   value=\"$serid_str\"  /> \n";
print "<input type=\"hidden\" name=\"smarkov_key\"  value=\"$smarkov_key\" />\n";
print "<input type=\"hidden\" name=\"display_choice\" value=\"$display_choice\">";
/*
print '<tr><td align="right" class="form2">ID #</td><td align="left" class="form2">';
print "<input type=\"text\" READONLY name=\"serid\" size=\"6\" maxlength=\"6\" value=\"$serid\" /> (no edit)\n";
print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\"  /> \n";
print '</td></tr>';
*/

print '<tr><td align="right" class="form2">Accession # </td><td align="left" class="form2">';
print "<input type=\"text\" name=\"sacc\" size=\"6\" maxlength=\"6\" value=\"$sacc\"  />\n";
print "&nbsp;<select name=\"stest\" size=\"1\" maxlength=\"6\" value=\"$stest\" >\n";
print '<option value="keep" selected>KEEP</option>';
print '<option value="delete">DELETE</option>';
print '<option value="">BOTH</option>';
print '</select>';
print '</td></tr>';

print '<tr><td align="right" class="form2">Update Date: </td><td align="left">';

print "<input type=\"text\" name=\"supdate_date\" size=\"21\" maxlength=\"40\" value=\"$supdate_date\" onblur=\"char_check(this)\"/>\n";
print '</td></tr>';

print '<tr><td align="right" class="form2">Author</td><td align="left">';
print "<input type=\"text\" name=\"snameauthor\" size=\"21\" maxlength=\"40\" value=\"$snameauthor\" onblur=\"char_check(this)\"/>\n";
print '</td></tr>';


#hidden cetitle
print "<input type=\"hidden\" name=\"cetitle\" size=\"21\" maxlength=\"60\" value=\"$cetitle\" onblur=\"char_check(this)\" />\n";

#hidden state
print "<input type=\"hidden\" name=\"state\" size=\"21\" maxlength=\"60\" value=\"$state\" onblur=\"char_check(this)\" />\n";

#hidden denom
print "<input type=\"hidden\" name=\"denom\" size=\"21\" maxlength=\"60\" value=\"$denom\" onblur=\"char_check(this)\" />\n";

#display cetitle or (state and/or denom)
#smarkov_CSD hidden var for the LABEL $markov_CSD
print "<input type=\"hidden\" name=\"smarkov_CSD\" value=\"$markov_CSD\" />\n";
print '<tr><td align="right" class="form2"><div name="CSD" id="CSD">';
print $markov_CSD;
print '</div></td><td align="left">';
print "<input type=\"text\" name=\"CSDval\" size=\"21\" maxlength=\"60\" value=\"$CSDval\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';



print '<tr><td align="right" class="form2">Sermon Title </td><td align="left">';
print "<input type=\"text\" name=\"stitle\" size=\"21\" maxlength=\"40\" value=\"$stitle\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';

print '<tr><td align="right" class="form2">Repository</td><td align="left">';
print "<input type=\"text\" name=\"slibloc_code\" size=\"21\" value=\"$slibloc_code\"  />\n";
print "<input type=\"hidden\" name=\"sloc\" size=\"21\" maxlength=\"40\" value=\"$sloc\" READONLY />\n";
print '</td></tr>';


print '<tr><td align="right" class="form2">Book of Bible</td><td align="left">';
print "<input type=\"text\" name=\"sibr\" size=\"21\" maxlength=\"40\" value=\"$sibr\" onblur=\"char_check(this)\"  />\n";
print '</td></tr>';


print '<tr><td align="right" class="form2">Index Date</td><td align="left">';
print "<input type=\"text\" name=\"sida\" size=\"21\" maxlength=\"80\" value=\"$sida\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';


print '<tr><td align="right" class="form2">Commentary </td><td align="left">';
print "<input type=\"text\" name=\"scmt\" size=\"21\" maxlength=\"40\" value=\"$scmt\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';

print '<tr><td align="right" class="form2">Keyword/<br>Short Title</td><td align="left">';
print "<input type=\"text\" name=\"skey\" size=\"21\" maxlength=\"60\" value=\"$skey\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';

print '<tr><td align="right" valign="center" class="form2">Reveal Results</td><td align="left">';
print "<input type=\"button\" onclick=\"submit_search_form(0)\" name=\"fullres\" value=\"Full\" class=\"pinkbutton40\" />";
print "<input type=\"button\" onclick=\"submit_search_form(1)\" name=\"oneline\" value=\"Line\" class=\"pinkbutton40\" />";
print "<input type=\"button\" name=\"add\" value=\"Add New\""; 
print " class=\"pinkbutton80\" ";
print " onclick=\"submit_search_form_add_new(2)\"  />";
print '</td></tr>';

print '<tr><td align="right" class="form2">Clear Form </td><td align="left">';
print "<input type=\"button\" name=\"myclear\" value=\"Clear / New Search\" onclick=\"my_edit_clear()\" class=\"pinkbutton160\" />\n";
print '</td></tr>';
print "</table>";
print "</form>";
print '</td>';

###xxx print '</div>';
###IFRAME IFRAME IFRAME#####

print '<td valign="top">';
#print '<hr style="width:480; height:10; background:a00000;">';
print '<div class="form2" name="enclose_iframe">';###hr width 480 -- iframe_table width=480 <br>iframe width 476';
###print '<script>document.write("<br>document.search_form.smarkov_key.value="+document.search_form.smarkov_key.value);</script>';
print '</div name="enclose_iframe">';
print '<table name="iframe_table" border="1" cellpadding="2" cellspacing="0" width="426" xwidth="480" bgcolor="000080"><tr><td align="center" valign="top" >';
include "KEY/alpha3.php";
##print '##########iframe_table start';
#print '<iframe name="B" id="B_id" width="476" height="600" src="KEY/NLC.php" ></iframe>';
$markov_src="KEY/$smarkov_key.php";

#print "markov_src=$markov_src<br>";
#print "<iframe name=\"B\" id=\"B_id\" width=\"476\" height=\"500\" src=\"$markov_src\"></iframe>";

#print "<iframe name=\"B\" id=\"B_id\" width=\"426\" height=\"380\" src=\"$markov_src\" ></iframe>";
print "<iframe name=\"B\" id=\"B_id\" width=\"426\" height=\"282\" src=\"$markov_src\"></iframe>";
################iframe_table end

print '</td></tr></table name="iframe_table">';

print '</td></tr></table><!--END SEARCH FRAME-->';
#######################################END SEARCH FORM#################################################################
###LINE 288 


if ( ($supdate_date) ||  ($snameauthor) || ($cetitle) || ($state) || ($denom) || ($stitle)||($serid)||($sloc) || ($slibloc_code) ||($sacc) || ($sibr) 
|| ($sida)|| ($skey) || ($sht) || ($scmt) || ($sbr) ||($nopgs) )
{
$iquery = "SELECT ser_test.pid, ser_test.sermon_id,ser_test.sermon_test_id, ser_test.nameauthor, ser_test.state, ";
$iquery.= " ser_test.denom, ser_test.dates, ser_test.ser_title, ser_test.cover_entry_title,  ser_test.book_title, ser_test.totalpgs, ";
$iquery.= " ser_test.placepub, ser_test.publisher, ser_test.date2, ser_test.ser_pgno, ser_test.placedate, ";
$iquery.= " ser_test.indexdate, ser_test.nopgs, ser_test.bibref, ser_test.indexbibref, ser_test.comment, ";
$iquery.= " ser_test.libloc, ser_test.loc_repository, ser_test.libloc_code, ser_test.crossref, ser_test.shorttitle, ser_test.printface, ";
$iquery.= " ser_test.keywords, ser_test.pmb, ser_test.c_i, ser_test.accession, ser_test.update_date, ser_test.test ";
$iquery.= " , ser_test.comment_long, ser_test.authors_note ";
$iquery.= " FROM $ser2_test2_alias as ser_test ";
if ($serid>0 ) 
  {
	$iquery.= "WHERE ser_test.pid=$serid ";
        if ($stest)        $iquery.= " AND ser_test.test LIKE '%$stest%' ";
  }
else if ($sacc) 
  {
	#$iquery.= "WHERE ser_test.accession LIKE '$sacc%' ";
	$iquery.= "WHERE ser_test.accession = '$sacc' ";
        if ($stest)        $iquery.= " AND ser_test.test LIKE '%$stest%' ";

  }
else
  {
	#$iquery.= "WHERE ser_test.pid ";
	$iquery.= "WHERE 1 ";
	if ($supdate_date)  $iquery.= " AND ser_test.update_date LIKE '%$supdate_date%' ";
	if ($snameauthor)  $iquery.= " AND ser_test.nameauthor LIKE '%$snameauthor%' ";
	if ($cetitle)	   $iquery.= " AND ser_test.cover_entry_title LIKE '%$cetitle%' ";
	if ($state)	   $iquery.= " AND ser_test.state LIKE '%$state%' ";
	if ($denom)	   $iquery.= " AND ser_test.denom LIKE '%$denom%' ";
  	if ($stitle)       $iquery.= " AND ser_test.ser_title LIKE '%$stitle%' ";
  	#if ($sloc)         $iquery.= " AND ser_test.libloc LIKE '%$sloc%' ";
	if ($slibloc_code) $iquery.= " AND ser_test.libloc_code  = '$slibloc_code'";
        if ($sibr)         $iquery.= " AND ser_test.indexbibref LIKE '%$sibr%' ";
        $sida2 = $sida;
        $sida2 = ereg_replace(" OR ","%' OR ser_test.indexdate LIKE '%",$sida2);
        if ($sida)         $iquery.= " AND ( ser_test.indexdate LIKE '%$sida2%' ) ";


        if ($skey)         $iquery.= " AND (ser_test.shorttitle LIKE '%$skey%' OR ser_test.keywords LIKE '%$skey%' ) ";
	#####if ($sht)	   $iquery.= " AND (ser_test.shorttitle LIKE '%$sht%') ";


        if ($scmt)         $iquery.= " AND ser_test.comment LIKE '%$scmt%' ";
        if ($sbr)          $iquery.= " AND ser_test.comment LIKE '%$sbr%' ";
        if ($nopgs)        $iquery.= " AND ser_test.comment LIKE '%$nopgs%' ";
        if ($stest)        $iquery.= " AND ser_test.test LIKE '%$stest%' ";

  }

###$iquery.= " AND (ser_test.test LIKE '%keep%') ";
$iquery.= " order by replace(replace(ser_test.nameauthor,\"[\",\"\"),'$doublequote',\"\"), replace(ser_test.shorttitle,\"[\",\"\") ";
$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";

print '<input type="hidden" name="test_iquery" value="';
print $iquery;
print '" >';
print '<input type="hidden" name="test_iquery2" value="';
print $iquery2;
print '" >';

print "</form>\n";
#print "</div name=\"enclose_search_form\">\n";
#####print $iquery;

if ($display_choice<2){##full results[display_choice=0] or line results[1]

$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());
}else {#add new row[display_choice==2]
#$aquery = "INSERT INTO $ser2_test2_alias set accession='999999', test='keep'";
$aquery = "INSERT INTO $ser2_test2_alias set accession='$sacc', test='keep'";
$aresult=mysql_query($aquery, $link) or die ("Error in query: $aquery. " . mysql_error());
print "$aquery";
$numhits = mysql_num_rows($aresult);
}


// $pid,$sid,$na,$st,$dn,$da,$srt,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$xref,$pfc,$sht,$kyw, $pmb,$ci,$acc,$update_date, $test

###prints above A total of X results...
########## print $iquery;

if ($numhits > 1 ) 
{
	print "<div class=\"form\">\n";
	print "A total of $numhits results were returned for the search criteria above.";
	print "</div>";
}else if ($numhits == 1)  {
	print "<div class=\"form\">\n";
	print "Only $numhits result was returned for the search criteria above.";
	print "</div>";
}


#print "$iquery2 <hr />";
####LINE 371 



if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";
//============================
        PageLinkTop();
//============================

 print "<br><table border=\"$display_choice\" class=\"list\" summary=\"\" cellspacing=\"0\" width=\"740\" cellpadding=\"4\">\n";
 #print "<table border=\"1\" class=\"list\" summary=\"\" width=\"620\" xwidth=\"760\" cellpadding=\"4\">\n";
 $bg="bg2";
 if ($display_choice==0) {##full results
 print "<tr >";
 print "<td class=\"label\">&nbsp;</td>\n";
 print "</tr>\n";
 }else{##line results

 $this_form_name="pageformA";
 print "<form name=\"";
 print $this_form_name;
 print "\" >\n";
 print "<input type=\"hidden\" name=\"this_page_pid_list\" value=\"0\">\n";
 print "<input type=\"hidden\" name=\"other_page_pid_list\" value=\"0\">\n";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"top\" value=\"private\" >";
 print "<tr><td colspan=\"6\" >";
 print "<input type=\"button\" name=\"save_this_page_pids\" value=\"Check All This Page\" onclick=\"check_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"remove_this_page_pids\" value=\"Uncheck All This Page\" onclick=\"uncheck_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"clearpageformA\" value=\"Clear All\" onclick=\"clear_all();\" class=\"bluebutton200\">&nbsp;";
 //print "<input type=\"button\" name=\"showpageformA\" value=\"Show All\" onclick=\"show_all();\" class=\"bluebutton200\">&nbsp;";
 print "</td></tr>\n";

 print "<tr >";
 print "<td class=\"value14so\">Select</td>";
 print "<td class=\"value14so\">Acc #</td>";
 print "<td class=\"value14so\">Author</td>";
 print "<td class=\"value14so\">Short Title</td>";
 print "<td class=\"value14so\">Index Date</td>";
 print "<td class=\"value14so\">keep?</td>\n";
 print "</tr>\n";
 }


 while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$cetitle,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_repository,$loc_code,$xref,$sht,$pfc,$kyw,$pmb,$ci,$acc,$update_date,$test, $cmt_long,$anote) = mysql_fetch_row($iresult))
  {
	  if($display_choice==0) {#start display_choice=0 display full results LINE 391

		  if ($bg=="bg1") $bg="bg2";
		  elseif ($bg=="bg2") $bg="bg1";
		  print "<tr class=\"$bg\">\n";
		  print "<td width=\"620\">\n";
		/*-----------------------------------------------
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Sermon ID #: </div>\n";
		  print "<div class=\"cont\">$sid</div>\n";
		  print "</div>\n";
		  -----------------------------------------------*/
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Accession Number:</div>\n";
		  print "<div class=\"cont\">$acc</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Update Date:</div>\n";
		  print "<div class=\"cont\">$update_date</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Author:</div>\n";
#$na=htmlentities($na); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$na</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">State/Denom/Dates:</div>\n";
		  print "<div class=\"cont\"> $st $dn $da</div>\n";
		  print "</div>\n";
		  print "<br />";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Cover Entry Title:</div>\n";
#$srt=htmlentities($cetitle); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$cetitle</div>\n";
		  print "</div>\n";
		  print "<br />";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Title:</div>\n";
#$srt=htmlentities($srt); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$srt</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Place/Date Preached:</div>\n";
		  $pda=htmlentities($pda);
		  print "<div class=\"cont\">$pda</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Index Date:</div>\n";
		  $ida=htmlentities($ida);
		  print "<div class=\"cont\">$ida</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Number Pages:</div>\n";
		  $npgs=htmlentities($npgs);
		  print "<div class=\"cont\">$npgs</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Biblical Ref.:</div>\n";
#$br=htmlentities($br); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$br</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Index Biblical Ref.:</div>\n";
		  $ibr=htmlentities($ibr); # remove this to make <i>...</i> work
			  print "<div class=\"cont\">$ibr</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Commentary:</div>\n";
#$cmt=htmlentities($cmt); #remove this line to make <i>...</i> work
		  print "<div class=\"cont\">$cmt</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\"><font color=\"a00000\">Commentary:</font></div>\n";
#$cmt=htmlentities($cmt); #remove this line to make <i>...</i> work
		  print "<div class=\"cont\"><font color=\"a00000\">$cmt_long</font></div>\n";

		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Repository (Code):</div>\n";
		  $loc_repository=htmlentities($loc_repository);
		  $loc_repository_2=$loc_repository;
		  $loc_code=htmlentities($loc_code);
		  $loc_code_2=$loc_code;
		  print "<div class=\"cont\">$loc_repository ($loc_code)</div>\n";

		  $s2 = ereg_replace(";","",$loc);

		  if ($s2 != $loc_code) {
			  print "</div>\n";
			  print "<div class=\"item\">";
			  print "<div class=\"label\">Repository Details:</div>\n";
			  $loc=htmlentities($loc);
			  $loc_2=$loc;
			  print "<div class=\"cont\">$loc</div>\n";
		  }



		  print "</div>\n";

		  print "<div class=\"item\">";
		  print "<div class=\"label\">Short Title:</div>\n";
#$sht=htmlentities($sht); #remove this line to make <i>...</i> work
		  print "<div class=\"cont\">$sht</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Keywords:</div>\n";
		  print "<div class=\"cont\">$kyw</div>\n";
		  print "</div>\n";

		  if ($anote != "") {
			  print "<div class=\"item\">";
			  print "<div class=\"label\"><font color=\"a00000\">Author's Note:</font></div>\n";
			  print "<div class=\"cont\"><font color=\"a00000\">$anote</font></div>\n";
			  print "</div>\n";
		  }


		  if ($test=='delete') {
			  print "<table border=\"1\" cellpadding=\"4\" width=\"100%\" ><tr><td>";
			  print "<div class=\"item\">";
			  print "<div class=\"label\">******** This sermon record (ID # $pid) has been marked for deletion. ********</div>\n";
			  print "</div>\n";
			  print "</div>\n";
			  print "</td></tr></table>";
		  }

		  print "<p />";

		  if ($serid > 0 ) {
#############################START EDIT (part of display_choice=0#######################
			  
			  #$serid_str= $_GET['serid_list'];

			  print "<tr>";
			  print "<td class=\"label\">&nbsp;</td>\n";
			  print "</tr>\n";

			  print '<table border="01" width="740" cellpadding="4" cellspacing="0"> ';

			  print '<tr class="bg_blue"><td align="left" colspan="3"><font face="verdana" size="2"><b>';
			  print '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Edit one row for Accession # ';
			  print $acc;
			  print '&nbsp;&nbsp;&nbsp; ( You may edit one sermon at a time with this webpage. )';
			  print '&nbsp;&nbsp;</b></font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'COLUMN&nbsp;&nbsp;</b></font></td><td><font face="verdana" size="2"><b>VALUE&nbsp;</b></font></td></tr>';
 print "<form name=\"edit_form_$pid\" action=\"./edit_update.php?top=private\" method=\"post\">";
			  #print '<form name="edit_form" action="./edit_update.php" method="get">';
			  print '<input type="hidden" name="top" value=\"private\"">';
			  print '<input type="hidden" name="serid" value="';
			  print $pid;
			  print '">';
			  print '<input type="hidden" name="pid_val" value="';
			  print $pid;
			  print '">';
			  print '<input type="hidden" name="serid_list" value="';
			  print $serid_str;
			  print '">';

			  /*---------------------------
			    edit_sid_test must be commented out in edit_update
			    print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			    print 'Sermon Test ID #: &nbsp;&nbsp;</td><td><input type="text" value="';
			    print $sid_test;
			    print '" name="edit_sid_test" size="80">';
			    print '</font></td></tr>';
			    ------------------------------*/

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Author: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $na;
			  print '" name="edit_na" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Accession: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $acc;
			  print '" name="edit_acc" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Update Date: &nbsp;&nbsp;</td>';
			  print '<td class="form2">Standard text: [Entry added August 2009] or [Entry updated August 2009]';
			  print '</font></td></tr>';
			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Update Date: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $update_date;
			  print '" name="edit_update_date" size="80">';
			  print '</font></td></tr>';


			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'State: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $st;
			  print '" name="edit_st" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Denomination: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $dn;
			  print '" name="edit_dn" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Dates: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $da;
			  print '" name="edit_da" size="80">';
			  print '</font></td></tr>';


			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Cover Entry Title: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $cetitle;
			  print '" name="edit_cetitle" size="80">';
			  print '</font></td></tr>';


			  print '<tr class="bg_blue"><td align="right" valign="top" width="25%"><font face="verdana" size="2"><b>';
			  print 'Title: &nbsp;&nbsp;</td><td><textarea rows="3" cols="60" name="edit_srt">';
			  print $srt;
			  print '</textarea>';
			  print '</font></td></tr>';


			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Book Title: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $sbt;
			  print '" name="edit_sbt" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Total Pages: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $tpgs;
			  print '" name="edit_tpgs" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Place Pub: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $ppub;
			  print '" name="edit_ppub" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Publisher: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $pub;
			  print '" name="edit_pub" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Date 2: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $da2;
			  print '" name="edit_da2" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Ser pgno: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $pno;
			  print '" name="edit_pno" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Place/Date Preached: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $pda;
			  print '" name="edit_pda" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Index Date: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $ida;
			  print '" name="edit_ida" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Number Pages: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $npgs;
			  print '" name="edit_npgs" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" valign="top" width="25%"><font face="verdana" size="2"><b>';
			  print 'Biblical Reference: &nbsp;&nbsp;</td><td><textarea rows="4" cols="60" name="edit_br">';
			  print $br;
			  print '</textarea>';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Index Biblical Reference: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $ibr;
			  print '" name="edit_ibr" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" valign="top" width="25%"><font face="verdana" size="2"><b>';
			  print 'Commentary: &nbsp;&nbsp;</td><td><textarea rows="12" cols="60" name="edit_cmt">';
			  print $cmt;
			  print '</textarea>';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td valign="top" align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Repository Help: &nbsp;&nbsp;</td><td class="form2">';
?>
<script language="javascript">
/*find which forms[n] is named edit_form_pid (see n=13)*/
document.write("document.forms[0].name="+document.forms[0].name+"<br>");
document.write("document.forms[1].name="+document.forms[1].name+"<br>");
document.write("document.forms[2].name="+document.forms[2].name+"<br>");
document.write("document.forms[3].name="+document.forms[3].name+"<br>");
document.write("document.forms[4].name="+document.forms[4].name+"<br>");
document.write("document.forms[5].name="+document.forms[5].name+"<br>");
document.write("document.forms[6].name="+document.forms[6].name+"<br>");
document.write("document.forms[7].name="+document.forms[7].name+"<br>");
document.write("document.forms[8].name="+document.forms[8].name+"<br>");
document.write("document.forms[9].name="+document.forms[9].name+"<br>");
document.write("document.forms[10].name="+document.forms[10].name+"<br>");
document.write("document.forms[11].name="+document.forms[11].name+"<br>");
/**/
document.write("document.forms[12].name="+document.forms[12].name+"<br>");
document.write("document.forms[13].name="+document.forms[13].name+"<br>");
document.write("Click on Repository to help fill out Repository Details, Code, and Location below.<br>")
</script>
<?php
			  print '<font xface="verdana" size="2">';
print "<select name=\"slibloc_code_select\" size=\"5\" onchange=\"write_data_triplet($pid)\">";
?>

<option  value="" selected>none selected</option>
<option  value="Bodleian">[Bodleian]...Bodleian Library, Univ. of Oxford, Oxford, Great Britain</option>
<option  value="CSmH">[CSmH]......Henry H. Huntington Library, San Marino, CA</option>
<option  value="DGU">[DGU]........Georgetown University, Washington, DC </option>
<option  value="DLC">[DLC].........Library of Congress, Washington, DC </option>
<option  value="GU">[GU]...........University of Georgia, Athens, GA </option>
<option  value="MdDA">[MdDA].......F. Garner Ranney Archives, Episcopal Diocese of Maryland, Baltimore, MD</option>
<option  value="MdHi">[MdHi]........Maryland Historical Society, Baltimore, MD</option>
<option  value="MdWC">[MdWC].....Washington College, Chestertown, MD </option>
<option  value="MH-H">[MH-H].......Houghton Library, Harvard University, Cambridge, MA</option>
<option  value="MHi">[MHi]..........Massachusetts Historical Society, Boston, MA </option>
<option  value="MNtcA">[MNtcA]......Andover Newton Theolog. School Libr., Newton Centre, MA</option>
<option  value="MWA">[MWA]........American Antiquarian Society, Worcester, MA </option>
<option  value="Nc">[Nc]............Dept. of Archives and History, NC State Libr., Raleigh, NC</option>
<option  value="NcD">[NcD]..........Duke University, Durham, NC</option>
<option  value="NcU">[NcU]..........University of N. Carolina at Chapel Hill, Chapel Hill, NC</option>
<option  value="NjP">[NjP]..........Princeton University, Princeton, NJ</option>
<option  value="NjR">[NjR]..........Rutgers, The State University of New Jersey, New Brunswick, NJ</option>
<option  value="NoCode">[NoCode].....Stored in a repository with no library code.</option>
<option  value="ScHi">[ScHi].........South Carolina Historical Society, Charleston, SC</option>
<option  value="ScU">[ScU]..........University of South Carolina, Columbia, SC</option>
<option  value="Vi">[Vi].............Virginia State Library, Richmond, VA</option>
<option  value="ViHi">[ViHi]..........Virginia Historical Society, Richmond, VA</option>
<option  value="ViRU">[ViRU].........Virginia Baptist Historical Society, University of Richmond, Richmond, VA</option>
<option  value="ViRU">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;University of Richmond, Richmond, VA</option>
<option  value="ViRUT">[ViRUT]........Union Theological Seminary, Richmond, VA </option>
<option  value="ViU">[ViU]............University of Virginia, Charlottesville, VA</option>
<option  value="ViWC">[ViWC].........Colonial Williamsburg, Inc., Williamsburg, VA</option>
</select><br />
<div name="DET" id="DET"></div>
<?php
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Repository Details:<br>libloc<br>formerly Location: &nbsp;&nbsp;<!--br>{edit_loc}--></td><td>';
			  print '<textarea name="edit_loc" rows="2" cols="64">';
			  print $loc;
			  print '</textarea>';
			  print '</font></td></tr>';


			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Repository Code<br>libloc_code<br>formerly Location Code:<!-- &nbsp;&nbsp;{edit_loc_code}--></td><td><div name="div_code" id="div_code"></div><input type="text" value="';
			  print $loc_code;
			  print '" name="edit_loc_code" size="12">';
			  print '<font face="verdana" size="2"><b>&nbsp;&nbsp;';
			  print 'Please use a code from <a href="http://www.loc.gov/marc/organizations" target="_blank">MARC Code List for Organizations</a>';
			  print '</font></td></tr>';


			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Repository Location:<br>loc_repository NEW: &nbsp;&nbsp;<!--{edit_loc_repository}--></td><td><input type="text" value="';
			  print $loc_repository;
			  print '" name="edit_loc_repository" size="80">';
			  print '</font></td></tr>';



			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Cross Ref.: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $xref;
			  print '" name="edit_xref" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Short Title: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $sht;
			  print '" name="edit_sht" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Printface: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $pfc;
			  print '" name="edit_pfc" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Keywords: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $kyw;
			  print '" name="edit_kyw" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Author\'s note: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $anote;
			  print '" name="edit_anote" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'PMB: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $pmb;
			  print '" name="edit_pmb" size="80">';
			  print '</font></td></tr>';

			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'c_i: &nbsp;&nbsp;</td><td><input type="text" value="';
			  print $ci;
			  print '" name="edit_ci" size="80">';
			  print '<input type="hidden" name="top" value="private">';
			  print '</font></td></tr>';

			  $select_keep = "selected";
			  $select_del  = "";
			  if ( $test == "delete" ) {
				  $select_keep = "";
				  $select_del  = "selected";
			  }
			  print '<tr class="bg_blue"><td align="right" width="25%"><font face="verdana" size="2"><b>';
			  print 'Mark For Deletion: &nbsp;&nbsp;</td><td valign="top">';
			  print '<select name="mark" size="2" onchange="reset_delete(this);"><option value="keep" ';
			  print  $select_keep ;
			  print ' >keep this record</option><option value="delete" ';
			  print  $select_del;
			  print ' >mark this record for deletion</option></select>&nbsp;';
			  print ' <input type="text" value="';
			  print $test;
			  print '" name="edit_test" size="10" READONLY>';
			  print '</font></td></tr>';
			  #UPDATE BUTTON ACCESSION
			  print '<tr class="bg_blue"><td align="center" colspan="2"><font face="arial" size="2" >';
			  print '<input type="submit"  value="Update Accession # ';
			  print $acc;
#print ' - action=edit_update.php"';
			  print '" style="width:600; font:bold; color:#003366; background-color:#ffddff;" name="">';
			  print '</font></td></tr>';


			  print '</form>';
			  print '</table>';


###############################END EDIT (part of display_choice=0#######################

		  }else {
#print "<form method=\"post\" action=\"./edit_one.php?\" >";
			  print "<form name=\"\" method=\"get\" action=\"./edit_search.php\" >\n";
			  #print "<input type=\"hidden\" name=\"serid\" value=\"\" >";
			  #print "<input type=\"hidden\" name=\"serid_for_pid_$pid\" value=\"";
			  print "<input type=\"hidden\" name=\"serid\" value=\"";
			  print $pid;
			  print '">';
			  print "<input type=\"hidden\" name=\"top\" value=\"private\">";
			  #EDIT BUTTON FULL ENTRY LIST ser6_nf
			  print '<div class="label">Edit Sermon ID # ';
			  print $pid;
			  #print '&nbsp;&nbsp;&nbsp;&nbsp;<input type="button"'; 
			  #print " onclick=\"submit_edit_update($pid);\" ";
			  print '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit"'; 
			  print ' value="Edit Sermon Accession # ';
			  print $acc;
			  print '" name=""';
			  print ' style="width:600px; font-weight:bold; color:#003366; background-color:#ddeeff; " ></div>';
			  print '</div>';
			  print "</form>";
			  print "<tr>";
			  print "<td class=\"label\">&nbsp;</td>\n";
			  print "</tr>\n";
		  }

		  print "</div>\n";
		  //-----------------
		  print "</td>\n";
		  print "</tr>\n";
#end display_choice=0
}else if($display_choice==1) {#display_choice=1 //line results  LINE 801
	#print "display_choice=$display_choice pid=$pid";
	print "<tr>";
	print "<td valign=\"top\" class=\"value14so\">&nbsp;";

#############add checkbox $display_choice=1 line display
        ######<form name="pageformA" starts where the table starts above

        print "&nbsp;<input type=\"checkbox\" name=\"chbx";
        print $pid;
        print "\" ";
        print " onclick='reset_chbx_search(\"";
        print $this_form_name;
        print "\",this,\"";
        print $pid;
        print "\",\"";
        print $acc;
        print "\");' ";
        #print "style=\"height:25px;width:25px;\">";
        print "style=\"height:20px;width:20px;\">";

        print "<script language=\"javascript\">";
        print "set_chbx_search(\"";
        print $this_form_name;
        print "\",\"";
        print $pid;
        print "\");";
        print "</script>";

        /*
        print "set_chbx_search(\"";
        print $this_form_name;
        print "\",\"";
        print $pid;
        print "\");";
	*/
        

#############add checkbox $display_choice=1 line display
 
	print "</td>";

	print "<td valign=\"top\" class=\"value14so\">&nbsp;";
        print "<a  href=\"view_one_acc.php?serid=";
        print $pid;
        #print "&accid=";
        #print $acc;
        print "\" target=\"_blank\">";
        print $acc;
        print "</a>";
	#print "($pid)";

	print "<td valign=\"top\" class=\"value14so\">&nbsp;";
        print $na;
	print "<td valign=\"top\" class=\"value14so\">&nbsp;";
        #print $srt;
        print $sht; #title:$srt #shortttile $sht
	print "<td valign=\"top\" class=\"value14so\">&nbsp;";
        print "$ida"; #dates:$da #indexdate: $ida
	print "<td valign=\"top\" class=\"value14so\">&nbsp;";
        print "$test"; #keep or delete
        print "</td>";
        print "</tr>\n";
	}#end display_choice=1 line display

  } //end while
 if($display_choice==1){
	print "</form>"; 
	}#end display_choice=1 line display

 print "</table>";

//============================
        PageLinkBottom();
//============================


 }// end if	mysql
else 
{
	print "<div class=\"form\">\n";
	print "No results returned for the search criteria above.";
	print "</div>";
}
} //end  if (($snameauthor) || ($stitle)||($serid)||($sloc) || ($slibloc_code) )
print "</div>\n";
print $footer;
?>
<script language=javascript src="elements.js"></script>
<script>
//show_elements defined in include_standard.php
show_elements=0;
if (show_elements==1) {
        elements();
}
</script>
