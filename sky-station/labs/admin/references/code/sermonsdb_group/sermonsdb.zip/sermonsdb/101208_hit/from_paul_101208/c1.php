<?php
/*
  There are 2 sections in this page that have php code, the first, c1.php, accesses
 the database and updates the counter.
 The second, c2.php, pulls the total number of hits from the counter for a display hits.
*/
$dir = basename(dirname(__FILE__));
$myscript=$_SERVER['PHP_SELF'];
$fn = basename($myscript);
if ($fn=="c1.php") exit();
//init
$link=$h=0;
$err=$dberr="";
//if ($filename) Clean($filename);
//if ($)  Clean($);
require "dblink.php";
$link=DBLink('localhost','filetrack','hcuser','vl3f578');
require "doquery.php";
include "counthit.php";
CountHit($link,$dir,$fn,1);
?>

