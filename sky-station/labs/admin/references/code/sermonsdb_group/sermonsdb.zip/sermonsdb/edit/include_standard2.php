<?php
#include_standard2.php
#no db or authentication

$top = $_GET['top']; #this is the switch for top_htm public vs private
/*html_header <head> not closed*/

$html_header = "<html><head><title>Sermons Database</title>";
$html_header.= "<link rel=\"stylesheet\" type=\"text/css\" href=\"ser.css\" />";

/*html_header_closer*/
$html_header_closer = "</head><body>";

/*title for all pages*/
$SM_TITLE = "Southern Manuscript Sermons before 1800:  A Bibliographic Database<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;edited by Michael A. Lofaro";

/*header for all pages*/
$header = "<font face=\"verdana\" size=\"2\" color=\"#000000\">&nbsp;University of Tennessee  Digital Library</font>\n";

$header.= "<div>\n";
$header.= "<div class=\"info\">\n";
$header.= "<div class=\"infotag\">\n";
$header.= $SM_TITLE;
$header.= "</div>\n";
$header.= "</div>\n";
$header.= "</div>\n";

$masthead_header=$header;


#print "include_standard2: \$top=$top<hr>";


/* footer  for all pages*/
$footer ="<p><hr />"; 
$footer.="<font face=\"verdana\" size=\"2\" color=\"#000000\">&nbsp;University of Tennessee Digital Library</font>\n";

/**/
include "STD/vars.php";
#include "ldapchk.php";
require "STD/db-inc.php";
#require "adminchk.php";
include "STD/config.php";
/**/

?>
<script language="javascript">
var show_elements = 1;//when 1, print elements, when 0 do not print elements

</script>
