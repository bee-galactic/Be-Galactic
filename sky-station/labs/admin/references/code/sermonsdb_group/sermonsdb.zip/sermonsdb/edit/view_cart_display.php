<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

view_cart_display.php copied from view_some.php

*/

include "./include_standard.php";
include "./include_upper.php";
print $html_header;
print $html_header_closer;
?>
<script language="javascript">
//write_serid_list(); //100304 chd
//document.write("location.href:<BR>"+location.href+"<hr style=\"background-color:#a00000; height:10; width:720\">");
</script>

<div>
<table border="0" cellpadding="0" cellspacing="0" width="740"><tr><td>
<div class="info">
<div class="infotag">
Cart Display for the Sermons Database
</div>
</div>
</td></tr></table>
</div>
<script language="javascript">
//write_serid_list();
//document.write("location.href:<BR>"+location.href+"<hr style=\"background-color:#a00000; height:10; width:720\">");
</script>
<?php

#include "./include_pagelink_SEARCH.php";
include "./include_pagelink_AUTHOR.php";

//serid_list is the only variable passed
//if serid_list=="0", print empty cart message

//id_type was previously passed when we displayed both acc and pid
//in view_cart_display.php id type is ALWAYS id ( the pid ) not acc.

#$serid_list= $_GET['serid_list'];
$serid_str= $_GET['serid_list'];

if ($serid_str == "0") {
  print "<table summary=\"\" width =\"700\" border=\"00\" cellspacing=\"10\" cellpadding=\"10\"><tr><td>";
  print "</td><tr><tr><td>";
  print "<font face=\"verdana\" size=\"3\">There are no items in the cart.</font>";
  print "</td></tr></table>\n";
  print "</td></tr></table>\n";##this ends the table started in ser-header_vone.php
} else {



$WHERE_CLAUSE = " WHERE ser_test.pid IN ($serid_str) ";

$id_type = "id";

// inits for paging - because continuous feed for display, removed rest of paging code

$lim=5;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;

if (!isset($serid)) $serid=0;
if (!isset($sacc)) $sacc="";
if (!isset($snameauthor))  $snameauthor=""; 
if (!isset($cetitle))      $cetitle="";
if (!isset($stitle)) 	   $stitle="";
if (!isset($sloc)) 	   $sloc="";
if (!isset($slibloc_code)) $slibloc_code="";
if (!isset($sibr)) 	   $sibr="";
if (!isset($sida)) 	   $sida="";
if (!isset($skey)) 	   $skey="";
if (!isset($scmt)) 	   $scmt="";
if (!isset($sbr)) 	   $sbr="";


$lnk=$PHP_SELF;
$lnk.="?serid_list=$serid_str";
$lnk.="&r=1";
if ($serid) $lnk.="&serid=$serid";
if ($sacc) $lnk.="&sacc=$sacc";
if ($snameauthor) $lnk.="&snameauthor=$snameauthor";
if ($cetitle) $lnk.="&cetitle=$cetitle";
if ($stitle)  $lnk.="&stitle=$stitle";
if ($sloc)  $lnk.="&sloc=$sloc";
if ($slibloc_code)  $lnk.="&slibloc_code=$slibloc_code";
if ($sibr)  $lnk.="&sibr=$sibr";
if ($sida)  $lnk.="&sida=$sida";
if ($skey)  $lnk.="&skey=$skey";
if ($scmt)  $lnk.="&scmt=$scmt";
if ($sbr)  $lnk.="&sbr=$sbr";
//
// $rec is the current pos in results, the beginning of the list of $lim results
// determine rec to retrieve a new block of results
#################nh is undefined 090828 chd


if ($inc)
  {
	$rec=$rec+$inc;
  if (($nh)&&($rec>=$nh)) $rec=$nh;
	}
if ($dec)
  {
	$rec=$rec-$dec;
  if ($rec <0) $rec=0;
	}




$iquery = "SELECT ser_test.pid, ser_test.sermon_id, ser_test.sermon_test_id, ser_test.nameauthor, ser_test.state, ";
$iquery.= "ser_test.denom, ser_test.dates, ser_test.ser_title, ser_test.cover_entry_title, ser_test.book_title, ser_test.totalpgs, ";
$iquery.= "ser_test.placepub, ser_test.publisher, ser_test.date2, ser_test.ser_pgno, ";
$iquery.= "ser_test.placedate, ser_test.indexdate, ser_test.nopgs, ser_test.bibref, ser_test.indexbibref, ";
$iquery.= "ser_test.comment, ser_test.libloc, ser_test.loc_repository, ser_test.libloc_code,ser_test.crossref, ser_test.shorttitle, ser_test.keywords , ser_test.test, ser_test.accession, ser_test.update_date";
#$iquery.= " FROM ser2_test2 as ser_test ";
$iquery.= " FROM ser3_edit3 as ser_test ";
$iquery.= $WHERE_CLAUSE;
#print "</div>\n";

$iquery.= " order by replace(replace(ser_test.nameauthor,\"[\",\"\"),'$doublequote',\"\"),replace(ser_test.shorttitle,\"[\",\"\") "; 

$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";
#print "$iquery2 <hr />";

$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());

##print "\$serid_str=$serid_str";

if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";
#print $iquery2;
#print "<p>&nbsp;";
  print "<table summary=\"\" border=\"0\" width=\"700\" cellpadding=\"10\" class=\"list\" >";
  print "<tr><td>";
  print "</td><tr></table>";

print "<div class=\"form\">\n";
print "<font size=\"2\">To delete entries, please select Cart Summary.</font><br />\n";
print "</div>";

//=========================
	PageLinkTop();
//=========================

#there is an outer table started in ser-header_vone.php
#   that ends outside while loop at bottom of this page
#   or in case of $serid_list=="0", ends above the start of while loop

#there is an inner table (one row, one col) inside the while loop for display 


 while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$cetitle,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_repository,$loc_code,$xref,$sht,$kyw,$test,$acc,$update_date) = mysql_fetch_row($iresult))
  {
  print "<table border=\"0\" width=\"700\" cellpadding=\"10\" class=\"list\" >";
  print "<tr><td>";



#code form print_prcd_ser-header.php
#print "<font size=\"2\" face=\"verdana\" color=\"#000000\">&nbsp;University of Tennessee Digital Library</font>\n";
print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print " Accession # $acc from the Sermons Database";
print "</div>\n";
print "</div>\n";


  /*--------------------------------------------------------
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Accession Number:</div>\n";
        print "<div class=\"cont\">$acc</div>\n";
  -----------------------------------------------------------*/
  if ($update_date != "") {
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Update Date:</div>\n";
        print "<div class=\"cont\">$update_date</div>\n";
	}

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Author:</div>\n";
	$na=htmlentities($na); # remove this to make <i>...</i> work
	$na_2 = $na;
	$st_2 = $st;
	$dn_2 = $dn;
	$da_2 = $da;
	print "<div class=\"cont\">$na</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">State/Denom/Dates:</div>\n";
	print "<div class=\"cont\"> $st $dn $da</div>\n";
  print "</div>\n";
  if ($cetitle != "none") {
        print "<br />";
        print "<div class=\"item\">";
        print "<div class=\"label\">Cover Entry Title:</div>\n";
        #$srt=htmlentities($srt); #--------remove this to make <i>...</i> work
        $cetitle_2 = $cetitle;
        print "<div class=\"cont\">$cetitle</div>\n";
  print "</div>\n";
        }
	print "<div class=\"item\">";
	print "<div class=\"label\">Title:</div>\n";
	#$srt=htmlentities($srt); # remove this to make <i>...</i> work
	$srt_2 = $srt;
	print "<div class=\"cont\">$srt</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Place/Date Preached:</div>\n";
	$pda=htmlentities($pda);
	$pda_2=$pda;
  	print "<div class=\"cont\">$pda</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Date:</div>\n";
	$ida=htmlentities($ida);
	$ida_2=$ida;
  	print "<div class=\"cont\">$ida</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Number Pages:</div>\n";
	$npgs=htmlentities($npgs);
	$npgs_2=$npgs;
  	print "<div class=\"cont\">$npgs</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Biblical Ref.:</div>\n";
	#$br=htmlentities($br);
	$br_2 = $br;
  print "<div class=\"cont\">$br</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Biblical Ref.:</div>\n";
	#$ibr=htmlentities($ibr); # remove this to make <i>...</i> work
	$ibr_2=$ibr;
  print "<div class=\"cont\">$ibr</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Commentary:</div>\n";
	#$cmt=htmlentities($cmt); #remove this line to make <i>...</i> work
	$cmt_2=$cmt;
	#print '<table border="01" cellpadding="4" width="50%"><tr><td>';
	#print $cmt;
	#print '</td></tr></table>';
	
  print "<div class=\"cont\">$cmt</div>\n";

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Repository (Code):</div>\n";
	$loc_repository=htmlentities($loc_repository);
	$loc_repository_2=$loc_repository;
	$loc_code=htmlentities($loc_code);
	$loc_code_2=$loc_code;
  print "<div class=\"cont\">$loc_repository ($loc_code)</div>\n";

  $s2 = ereg_replace(";","",$loc);
 
  if ($s2 != $loc_code) {
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Repository Details:</div>\n";
	$loc=htmlentities($loc);
	$loc_2=$loc;
  print "<div class=\"cont\">$loc</div>\n";
  }

/*
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Cross Ref.:</div>\n";
	$xref=htmlentities($xref);
	$xref_2=$xref;
  print "<div class=\"cont\">$xref</div>\n";
*/

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Short Title:</div>\n";
	#$sht=htmlentities($sht); #remove this line to make <i>...</i> work
	$sht_2=$sht;
  print "<div class=\"cont\">$sht</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Keywords:</div>\n";
  print "<div class=\"cont\">$kyw</div>\n";
	$kyw_2=$kyw;
  print "</div>\n";
	
  print "<div>\n";
  #print $footer;
  print "</div>\n";

  print '</td></tr></table>';


  }//end while

//=========================
	PageLinkBottom();
//=========================

 }// end if (mysql_num_rows($iresult)) 
} //end else

print "</td></tr></table>\n";##this ends the table started in ser-header_vone.php

print "\$ser2_test2_alias: ";
print $ser2_test2_alias;
print "<hr>";
print "'$ser2_test2_alias '";


?>

<script language=javascript src="elements.js"></script>
<script>
//show_elements defined in include_standard.php
var show_elements=0;
if (show_elements==1) {
        elements();
}
</script>
</body>
</html>
