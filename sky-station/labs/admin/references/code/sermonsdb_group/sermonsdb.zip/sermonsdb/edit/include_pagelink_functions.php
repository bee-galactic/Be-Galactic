<?php
#include "./ser-header_frames.php";
#include "./ser-header_links.php";
$doublequote='"';
/*---------------------------------------------------------------
These functions are for 
	view_author_title_index.php

function go_to_page (called by PageLinkTop and PageLinkBottom)
	When you click prev or next button, go_to_page is called.
function go_to_page2 (PageLinkBottom for batch)
function PageLinkTop2() (for batch)
function PageLinkBottom2()(for batch)
function PageLinkTop()
function PageLinkBottom()

-----------------------------------------------------------------*/

?>

<script language="javascript">

function go_to_page(type,display_page_number,limitt,numhitts,max_page_number,incc,decc) {

//alert("go_to_page: \ntype="+type+"\ndisplay_page_number="+display_page_number+"\nlimit="+limitt+"\nincc="+incc+"\ndecc="+decc);
var limit = new Number(limitt);
var curr_page = new String(document.form_go_button.this_DPN.value);
//var curr_page = new String(display_page_number);
var target_page = new Number(curr_page);
var top_page = new Number();
    top_page = 1600/limit; //bad cricket hard coding
    top_page = max_page_number;
if (type=="jump") {
    	target_page = Number(document.form_go_button.this_page.value);
}else if (type=="next") {
    	target_page++;
    	if (target_page > top_page) target_page=top_page;
}else if (type=="prev") {
    	target_page--;
    	if (target_page < 1) target_page=1;
}else if (type=="stay") {
	target_page = target_page;
}

var inc=limitt;
var record_num = limitt * target_page;
alert("go_to_page: location.href="+location.href+"\ntype="+type+"\ncurr_page="+curr_page+"\ntarget_page="+target_page+"\nrecord_num="+record_num+"\ninc="+incc+"\ndec="+decc+"\nlimit="+limitt );
alert("go_to_page: current page="+location.href);
//if(!confirm("NON-SEARCH go_to_page: \ncurr_page="+curr_page+"\ntarget_page="+target_page+"\nrecord_num="+record_num+"\ninc_OR_dec="+limitt+"\nlimit="+limitt+"\nnumhits=undefined" ))return;
var LINK=new String(location.href);
var lnk=new String(location.href);
//alert ("location.href="+LINK);

if (type=="stay") {
	lnk=lnk;
}else if (LINK.indexOf("this_page_pid_list")>-1) {
	//first page load treated differently
	lnk = lnk.substring(0,lnk.indexOf("&this_page_pid_list"));
	lnk = lnk.replace("%2c",",");
	lnk = lnk + "&rec=";
}else{
	lnk = lnk.substr(0, lnk.indexOf("&rec=")+5 ); //trim off location.href, keep "&rec="
}

//alert ("location.href="+LINK+"\nlnk="+lnk);

//alert ("go_to_page: 1 lnk="+lnk);
//alert ("document.pageformA.serid_list.value="+document.pageformA.serid_list.value);

var srh = new String();
var recnum = new Number();
    recnum = record_num;
    //if (recnum > 1599) recnum = 1599; //bad cricket hard coding!
    if (recnum > numhitts) recnum=numhitts;
    alert("record_num="+record_num+"\nrecnum="+recnum+"\nnumhitts="+numhitts);

var r2 = recnum -1;

var r4 = r2%limitt;

var r3 = (r2-r4)/limitt -1;//////////change is bad
//var r3 = (r2-r4)/limitt;

/*HERE*/
var r5 = r3*limitt;

alert ("r2=recnum-1\nr2="+r2+"="+recnum+"-1"
      +"\n\nr4=r2%limitt\nr4="+r4+"="+r2+"%"+limitt
      +"\n\nr3=(r2-r4)/limitt -1\nr3="+r3+"=("+r2+"-"+r4+")/"+limitt+"-1"
      +"\n\nr5=r3*limitt\nr5="+r5+"="+r3+"*"+limitt);
var sr5 = new String(r5);

var low_num = limitt + 1;

if (recnum<low_num) {
	//srh="20&dec="+limitt;
	srh=limitt+"&dec="+limitt;
}else {
	srh=sr5+"&inc="+limitt;
}

srh = srh +"&serid_list="+document.formW.serid_list.value;

alert ("recnum="+recnum+"\nr2="+r2 +"\nr4="+r4+"\nr3="+r3+"\nr5="+r5 +"\nsr5="+sr5+"\nsrh="+srh); 

//alert ("srh="+srh);
lnk = lnk+srh;
alert("go_to_page: target page: lnk="+lnk);

location.replace(lnk);

} //end function go_to_page() 


function go_to_page2(type,display_page_number,limitt,numhitts,max_page_number,incc,decc) {

//alert("go_to_page: \ntype="+type+"\ndisplay_page_number="+display_page_number+"\nlimit="+limitt+"\nincc="+incc+"\ndecc="+decc);
var limit = new Number(limitt);
var curr_page = new String(document.form_go_button.this_DPN.value);
//var curr_page = new String(display_page_number);
var target_page = new Number(curr_page);
var top_page = new Number();
    top_page = 1600/limit; //bad cricket hard coding
    top_page = max_page_number;
if (type=="jump") {
    	target_page = Number(document.form_go_button.this_page.value);
}else if (type=="next") {
    	target_page++;
    	if (target_page > top_page) target_page=top_page;
}else if (type=="prev") {
    	target_page--;
    	if (target_page < 1) target_page=1;
}else if (type=="stay") {
	target_page = target_page;
}

var inc=limitt;
var record_num = limitt * target_page;
//alert("go_to_page: location.href="+location.href+"\ntype="+type+"\ncurr_page="+curr_page+"\ntarget_page="+target_page+"\nrecord_num="+record_num+"\ninc="+incc+"\ndec="+decc+"\nlimit="+limitt );
//alert("go_to_page: current page="+location.href);
//if(!confirm("NON-SEARCH go_to_page: \ncurr_page="+curr_page+"\ntarget_page="+target_page+"\nrecord_num="+record_num+"\ninc_OR_dec="+limitt+"\nlimit="+limitt+"\nnumhits=undefined" ))return;
var LINK=new String(location.href);
var lnk=new String(location.href);
//alert ("location.href="+LINK);

if (type=="stay") {
	lnk=lnk;
}else if (LINK.indexOf("this_page_pid_list")>-1) {
	//first page load treated differently
	lnk = lnk.substring(0,lnk.indexOf("&this_page_pid_list"));
	lnk = lnk.replace("%2c",",");
	lnk = lnk + "&rec=";
}else{
	lnk = lnk.substr(0, lnk.indexOf("&rec=")+5 ); //trim off location.href, keep "&rec="
}

//alert ("location.href="+LINK+"\nlnk="+lnk);

//alert ("go_to_page: 1 lnk="+lnk);
//alert ("document.pageformA.serid_list.value="+document.pageformA.serid_list.value);

var srh = new String();
var recnum = new Number();
    recnum = record_num;
    //if (recnum > 1599) recnum = 1599; //bad cricket hard coding!
    if (recnum > numhitts) recnum=numhitts;
    //alert("record_num="+record_num+"\nrecnum="+recnum+"\nnumhitts="+numhitts);

var r2 = recnum -1;

var r4 = r2%limitt;

var r3 = (r2-r4)/limitt -1;//////////change is bad
//var r3 = (r2-r4)/limitt;

/*HERE*/
var r5 = r3*limitt;

/*
alert ("r2=recnum-1\nr2="+r2+"="+recnum+"-1"
      +"\n\nr4=r2%limitt\nr4="+r4+"="+r2+"%"+limitt
      +"\n\nr3=(r2-r4)/limitt -1\nr3="+r3+"=("+r2+"-"+r4+")/"+limitt+"-1"
      +"\n\nr5=r3*limitt\nr5="+r5+"="+r3+"*"+limitt);
*/
var sr5 = new String(r5);

var low_num = limitt + 1;

if (recnum<low_num) {
	//srh="20&dec="+limitt;
	srh=limitt+"&dec="+limitt;
}else {
	srh=sr5+"&inc="+limitt;
}

srh = srh +"&serid_list="+document.formW.serid_list.value;

//alert ("recnum="+recnum+"\nr2="+r2 +"\nr4="+r4+"\nr3="+r3+"\nr5="+r5 +"\nsr5="+sr5+"\nsrh="+srh); 

//alert ("srh="+srh);
lnk = lnk+srh;
//alert("go_to_page: target page: lnk="+lnk);

location.replace(lnk);

} //end function go_to_page2() 



</script>
<?php

function PageLinkBottom()
{

//print "PageLinkBottom() uses function go_to_page via form_go_button<br>";

 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $DisplayRecord=$rec+1;

 print "<div class=\"instruct2\">";

 print "<form name=\"form_bottom_buttons\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"hidden\" name=\"this_page\" value=\"\" >";

 print "<br>";
 if ($numhits>$lim)
  {
  print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($rec!=0) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_back\" ";
	print " onclick=\"go_to_page2('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"<< Back\" class=\"bluebutton100\" >";
	}	
       else 
  	{
  	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
  	}
   }

  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
	$chnk=$rec+$lim;
	if ($chnk > $numhits) $chnk=$numhits;
	print "$chnk of $numhits) ";

  if($rec<$numhits-$lim) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_next\" ";
	print " onclick=\"go_to_page2('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"Next >>\" class=\"bluebutton100\" >";
        }
	else 
	{
	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
 print "</form>";
 print "</div>";
}//end function PageLinkBottom();

function PageLinkTop()
{
//print "PageLinkTop() uses function go_to_page via form_go_button<br>";
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 //----  prev-next links
 if ($inc == 0 && $dec==0) {
        $DisplayPageNumber=1;
 }else if ($inc > 0) {
        $DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
        $DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $DisplayRecord=$rec+1;

 print "<div class=\"instruct2\">";


 //this form has to have the name form_go_button to match name on view_author_title_index
 //need because function go_to_page refers to some of these form elements
 print "<form name=\"form_go_button\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"hidden\" name=\"this_page\" value=\"\" >";

 if ($numhits>$lim)
  {
  print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        if ($rec!=0)
          {
        print "&nbsp;<input type=\"button\" name=\"link_back\" ";
        print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
        print " value=\"<< Back\" class=\"bluebutton100\" >";
        }
 } else {
   print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}

  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
        $chnk=$rec+$lim;
        if ($chnk > $numhits) $chnk=$numhits;
        print "$chnk of $numhits) ";

  if($rec<$numhits-$lim)
          {
        print "&nbsp;<input type=\"button\" name=\"link_next\" ";
        print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
        print " value=\"Next >>\" class=\"bluebutton100\" >";
    	}
        else 
	{
	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
     
 print "</form>";
 print "</div>";
}//end function PageLinkTop();



#only used by view_author_title_index.php
function PageLinkGo()
{
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;

 $page_total = (int)(($numhits/$lim)+1);

 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
 }


 $inumhits=$numhits%$lim;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 $DisplayRecord=$rec+1;
 print "<div class=\"instruct2\">";
 print "\$inc=$inc -- \$dec=$dec -- \$rec=$rec -- \$lim=$lim";
 print "<br>if(\$inc>0) \$DisplayPageNumber=(\$rec+\$inc)/\$inc)";
 print "<br>if(\$dec>0) \$DisplayPageNumber=(\$rec+\$dec)/\$dec)";
 print "<br>\$numhits=$numhits"; #1698
 print "<br>\$inumhits=$inumhits"; #18
 print "<br>\$DisplayPageNumber=$DisplayPageNumber";
 print "<br>\$DisplayRecord=$DisplayRecord";
 print "<br>\$MaxPageNumber=$MaxPageNumber";
 print "<br>\$iMaxPageNumber=$iMaxPageNumber";
 print "<br>\$page_total=$page_total";


 print "<div class=\"instruct2\">";
 print "\$inc=$inc -- \$dec=$dec -- \$rec=$rec ";
 print "<br>if(\$inc>0) \$DisplayPageNumber=(\$rec+\$inc)/\$inc)";
 print "<br>if(\$dec>0) \$DisplayPageNumber=(\$rec+\$dec)/\$dec)";
 print "<br>\$numhits=$numhits";
 print "<form name=\"form_go_button\">";
 if ($numhits>$lim)
  {
  //print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($rec!=0) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_back2\" ";
	print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"<< Back\" class=\"bluebutton100\" >";
	}	
  else {print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";}
  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
	$chnk=$rec+$lim;
	if ($chnk > $numhits) $chnk=$numhits;
	print "$chnk of $numhits) ";

  if($rec<($numhits-$lim)) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_next2\" ";
	print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"Next >>\" class=\"bluebutton100\" >";
	print "&nbsp;&nbsp;\n";
    }
	else print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
 #print "</form>";

 	print "Find Page (1-$page_total):";
 #print "<form name=\"form_go_button\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"text\" size=\"2\" value=\"\" name=\"this_page\">&nbsp;<input type=\"button\" name=\"page_link_button\" ";
 print " onclick=\"go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";

 print " value=\"Go\" class=\"bluebutton40\" >";
 print "</form>\n";
 print "</div>";
}//end function PageLinkGo();



/*for view_batch_select only--does reset_formW() on button clicks*/

function PageLinkGo2()
{
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;

//N="100" for batch print


 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $inumhits=$numhits%$lim;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 $DisplayRecord=$rec+1;
 print "<div class=\"instruct2\">";
 print "\$inc=$inc -- \$dec=$dec -- \$rec=$rec -- \$lim=$lim";
 print "<br>if(\$inc>0) \$DisplayPageNumber=(\$rec+\$inc)/\$inc)";
 print "<br>if(\$dec>0) \$DisplayPageNumber=(\$rec+\$dec)/\$dec)";
 print "<br>\$numhits=$numhits"; #1698
 print "<br>\$inumhits=$inumhits"; #98
 print "<br>\$MaxPageNumber=$MaxPageNumber";
 print "<br>\$iMaxPageNumber=$iMaxPageNumber";


 if ($lim ==100){
	#print "<br>When you click any button on this page, all checkboxes are cleared <br>to prevent printing of more than 100 records at a time.";

	}

 print "<form name=\"form_go_button\">";
 if ($numhits>$lim)
  {
  //print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($rec!=0) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_back2\" ";
	if ($lim == 100){
	print " onclick=\"reset_formW();go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec);\" ";
	}else{
	print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
	}
 	print " value=\"<< Back\" class=\"bluebutton100\" >";
	}	
  else print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
	$chnk=$rec+$lim;
	if ($chnk > $numhits) $chnk=$numhits;
	print "$chnk of $numhits) ";

  if($rec<$numhits-$lim) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_next2\" ";
	if ($lim == 100){
	print " onclick=\"reset_formW();go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
	}else{
	print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
	}
 	print " value=\"Next >>\" class=\"bluebutton100\" >";
	print "&nbsp;&nbsp;\n";
    }
	else print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
 #print "</form>";

 print "Find Page (1-$MaxPageNumber):";
 #print "<form name=\"form_go_button\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"text\" size=\"2\" value=\"\" name=\"this_page\">&nbsp;<input type=\"button\" name=\"page_link_button\" ";
 if ($lim==100){
 print " onclick=\"reset_formW();go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 }else{
 print " onclick=\"go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 }

 print " value=\"Go\" class=\"bluebutton40\" >";
 print "</form>\n";
 print "</div>";
}//end function PageLinkGo2();


/*for view_batch_select only--does reset_formW() on button clicks*/

function PageLinkBottom2()
{
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 //----  prev-next links
 if ($inc == 0 && $dec==0) {
        $DisplayPageNumber=1;
 }else if ($inc > 0) {
        $DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
        $DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $DisplayRecord=$rec+1;

 print "<div class=\"instruct2\">";

 print "<form name=\"form_bottom_buttons\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"hidden\" name=\"this_page\" value=\"\" >";

 print "<br>";
 if ($numhits>$lim)
  {
  print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        if ($rec!=0)
          {
        print "&nbsp;<input type=\"button\" name=\"link_back\" ";
        print " onclick=\"reset_formW();go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
        print " value=\"<< Back\" class=\"bluebutton100\" >";
        }
       else
        {
        print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
        }
   }

  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
        $chnk=$rec+$lim;
        if ($chnk > $numhits) $chnk=$numhits;
        print "$chnk of $numhits) ";

  if($rec<$numhits-$lim)
          {
        print "&nbsp;<input type=\"button\" name=\"link_next\" ";
        print " onclick=\"reset_formW();go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
        print " value=\"Next >>\" class=\"bluebutton100\" >";
        }
        else
        {
        print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
        }
 print "</form>";
 print "</div>";
}//end function PageLinkBottom2();







//--- end of php functions


?>


