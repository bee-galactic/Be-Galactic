<?php
#include_top.php
$top = $_GET['top'];
?>
