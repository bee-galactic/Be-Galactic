<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

view_author_title_index.php

*/

//-- declare functions

//--- end of functions

include "include_standard.php";
include "./include_upper.php";
print $html_header;
?>



<script language="javascript">
function submit_formBp() { //view_batch_print
//formBp is located in include_upper.php
//document.formBp.serid_list.value="0";
document.formBp.batch_print_list.value=document.pageformA.batch_print_list.value;
//alert( "document.formBp.batch_print_list.value="
 //     +document.formBp.batch_print_list.value);
document.formW.batch_print_list.value=document.pageformA.batch_print_list.value;
document.formBp.batch_print_list.value=document.formW.serid_list.value;
document.formW.serid_list.value="0";
//alert("document.formBp.batch_print_list.value="+document.formBp.batch_print_list.value
//+"\ndocument.formW.serid_list.value="+document.formW.serid_list.value);
document.formBp.submit();
}
</script>


<?php
print $html_header_closer;
#print $masthead_header;
?>
<script language="javascript">
//write_serid_list();
//document.write(location.href+"<hr style=\"background-color:#a00000; height:10; width:720\">");
</script>
<?php
print "<div>\n";
print "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"720\" xwidth=\"920\"><tr><td>";
print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print "Batch Select for the Sermons Database <br>&nbsp;&nbsp;&nbsp;&nbsp;(sorted by author's last name, title, and date)";
print "</div>\n";
print "</div>\n";
print "</td></tr></table>";
print "</div>\n";


include "./include_checkbox_functions.php";
#include "./include_pagelink_BATCH.php";
include "./include_pagelink_AUTHOR.php";

$serid_str         = $_GET['serid_list'];
#print "\$serid_string=$serid_str<hr>";
if ($serid_str==""){
	$serid_str="0";
	}


//===================================================
// inits for paging
$lim="100";#$lim=20;
#$lim=5;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;


if (!isset($serid_list)) $serid_list=0;

$lnk=$PHP_SELF;
$lnk.="?serid_list=$serid_str";
$lnk.="&r=1";

//
// $rec is the current pos in results, the beginning of the list of $lim results
// determine rec to retrieve a new block of results

#$nh=1600;#the value of $nh below throwing undefined error. 
#$nh=$numhits, so this code needs to go below $numhits
#this is same error as in view_author_title_index


if ($inc)
  {
	$rec=$rec+$inc;
  //if (($nh)&&($rec>=$nh)) $rec=$nh;
	}
if ($dec)
  {
	$rec=$rec-$dec;
  if ($rec <0) $rec=0;
	}


//==================================================

$doublequote='"';

if (1==1)
{
$iquery = "SELECT ser_test.pid, ser_test.nameauthor, ser_test.shorttitle, ser_test.indexdate, ser_test.accession ";
#$iquery.= " FROM ser2_test2 as ser_test ";
$iquery.= " FROM ser3_edit3 as ser_test ";
$iquery.= " WHERE ser_test.test LIKE \"%keep%\" ";
$iquery.= " order by replace(replace(ser_test.nameauthor,\"[\",\"\"),'$doublequote',\"\"), replace(ser_test.shorttitle,\"[\",\"\") ";
print "</div>\n";

$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);
########$nh=$numhits;####090828 chd
if ($rec>$numhits){$rec=$numhits;}
$iquery2="$iquery"." LIMIT $rec,$lim ";




//print $iquery2;


$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());

if (mysql_num_rows($iresult)) 
 {
 #print "$iquery2 <hr />";
//=========================
 	#print "PageLinkGo2() function --- view_batch_select.php<br>";
	PageLinkGo2();//PageLinkTop rewrite
//=========================

 #print "<hr style=\"background-color:#a00000; height:10; width:720\">";
 print "<table border=\"1\" class=\"list\" summary=\"\" width=\"720\" xwidth=\"920\" cellpadding=\"2\">\n";
 $bg="bg2";
 
 print "<form name=\"pageformA\" >";

 print "<input type=\"hidden\" name=\"this_page_pid_list\" value=\"0\"> \n";
 print "<input type=\"hidden\" name=\"other_page_pid_list\" value=\"0\"> \n";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\">\n";
 print "<input type=\"hidden\" name=\"batch_print_list\" value=\"$serid_str\">\n";

 print "<tr><td colspan=\"5\" >";
 print "<input type=\"button\" name=\"save_this_page_pids\" value=\"Check All This Page\" onclick=\"check_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"remove_this_page_pids\" value=\"Uncheck All This Page\" onclick=\"uncheck_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"batch_print\" value=\"Batch Print\" onclick=\"submit_formBp();uncheck_all('A');\" class=\"bluebutton100\">&nbsp;";
 print "</td></tr>\n";

 print "<tr>\n";
 print "<td width=\"5%\" class=\"value14so\">Select</td>\n";
 print "<td width=\"7%\" class=\"value14so\">&nbsp;Acc.&nbsp;#</td>\n";
print "<td xwidth=\"25%\" class=\"value14so\">&nbsp;Author</td>\n";
print "<td class=\"value14so\">&nbsp;Short Title</td>\n";
print "<td width=\"12%\" class=\"value14so\">&nbsp;Index Date</td>\n";
 print "</tr>\n";

 $this_form_name="pageformA";

while (list($pid,$na,$sht,$ida,$acc) = mysql_fetch_row($iresult))
  {

	$bg ="";
	print "<tr >";
	print "<td valign=\"top\"  class=\"value14so\">&nbsp;";

        print "&nbsp;<input type=\"checkbox\" name=\"chbx";
        print $pid;
        print "\" ";
        print " onclick='reset_chbx_search(\"";
        print $this_form_name;
        print "\",this,\"";
        print $pid;
        print "\",\"";
        print $acc;
        print "\");' ";
        print "style=\"height:20px;width:20px;\">";


        print "<script language=\"javascript\">set_chbx_search(\"";
        print $this_form_name;
        print "\",\"";
        print $pid;
        print "\");";
	print "</script>";


        print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	print "<a  href=\"view_one_acc.php?serid=";
        print $pid;
	print "&accid=";
	print $acc;
        print "\" target=\"_blank\">";
        print $acc;
        #print "($pid)";
        print "</a>";

	if($ser_debug){
	print "<font color=\"a00000\">&nbsp;($pid)</font>";#debug
	}

	print "</td><td valign=\"top\"  class=\"value14so\">&nbsp;";
	print $na;
	print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	#print $srt;
	print $sht; #title:$srt #shortttile $sht
	print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	#print $da;
	print "$ida"; #dates:$da #indexdate: $ida
	print "</td>";
	print "</tr>\n";
  }//end while


 print("</form>");

 print "</table>\n";

//=========================
	PageLinkBottom();
 	#print "PageLinkBottom() function --- view_batch_select.php<br>";
//=========================

 }// end if	mysql

} //end if (1==1) 

#print "</div>\n";
#print $footer;
print "\$ser2_test2_alias: ";
print $ser2_test2_alias;
print "<hr>";
print "'$ser2_test2_alias '";
?>

<script language=javascript src="elements.js"></script>
<script>
//show_elements defined in include_upper.php
show_elements=0;
if (show_elements==1) {
	elements();
}
</script>
</body>
</html>
