<html>
<head>
<title>kwt</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwt";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- T</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>revised 100325 transfiguration</option>
<option>tabernacle</option>
<option>Tabernacle, Feast of</option>
<option>talents, parable of</option>
<option>tares, parable of</option>
<option>tares and wheat, parable of</option>
<option>Tate, Elisabeth</option>
<option>Taylor, Bishop Jeremy</option>
<option>teaching, importance of</option>
<option>temperance</option>
<option>temptation</option>
<option>temptation, avoidance of</option>
<option>temptation, nature of</option>
<option>temptation, resistance of</option>
<option>temptation, supernatural aid to resist</option>
<option>temptation, types of</option>
<option>temptation, yielding to</option>
<option>temptation of Christ</option>
<option>temptations</option>
<option>temptations, avoidance of</option>
<option>temptations of early Christians</option>
<option>Ten Commandments</option>
<option>Ten Commandments, obedience of</option>
<option>Tennans, Mr.</option>
<option>Tennent, Charles</option>
<option>tepidity</option>
<option>Tertullian</option>
<option>Tertullus, accuses Paul</option>
<option>thanksgiving</option>
<option>Thanksgiving Day</option>
<option>thanksgiving sermon</option>
<option>theft, as result of poverty</option>
<option>theft, kinds of</option>
<option>thief, good</option>
<option>thief, penitent</option>
<option>thorns, crowning with</option>
<option>Thorpe, And</option>
<option>thoughts, government of the</option>
<option>thoughts, unclean</option>
<option>Tillotson</option>
<option>Tillotson, Archbishop John</option>
<option>time</option>
<option>time, good use of</option>
<option>time, redeeming the</option>
<option>time, use of</option>
<option>time, wasted</option>
<option>Timothy, books of</option>
<option>Timothy, circumcision of</option>
<option>Tindal</option>
<option>Tinsley, Mrs</option>
<option>Titus</option>
<option>Tom Hickerthrift [sic. Hickathrift], tale of</option>
<option>Tom Thumb, tale of</option>
<option>Tompkins, Mrs.</option>
<option>tongues, gift of</option>
<option>torments</option>
<option>tradition, validity of oral</option>
<option>tranquility</option>
<option>transformation of man</option>
<option>transfiguration</option>
<option>transgressions defined</option>
<option>transmigration</option>
<option>transubstantiation</option>
<option>treasure, heavenly</option>
<option>trials, limited by God</option>
<option>trials, necessity of</option>
<option>tribulation</option>
<option>tribulations, preparation for</option>
<option>Trinity, doctrine of</option>
<option>Trinity, Holy</option>
<option>Trinity Sunday</option>
<option>triune God, doctrine of</option>
<option>Trotten, Mr. funeral of</option>
<option>true devotion, nature of</option>
<option>trust</option>
<option>truth</option>
<option>truth, Christian</option>
<option>truth, divine</option>
<option>truth in religion</option>
<option>truthfulness</option>
<option>Turkish mosque</option>
<option>Turks</option>
<option>Turner, Rebeckah</option>
<option>two masters, no man can serve</option>
<option>two sons, parable of</option>
<option>typology</option>
<option>tyrants, domestic</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
