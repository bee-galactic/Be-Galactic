<html>
<head>
<title>shg</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shg";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- G</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>General Judgm[en]t</option>
<option>Genuine Love of God, On</option>
<option>Give us this day our daily bread</option>
<option>Giving Alms, On</option>
<option>Giving scandal, On</option>
<option>Gluttony, On</option>
<option>Go ye therefore & teach all nations</option>
<option>God's Design</option>
<option>God's Forbearance and Judgment</option>
<option>God's help--A Confirmation Sermon</option>
<option>God's mercy, On</option>
<option>God's mercy towards sinners, On</option>
<option>God's patience towards sinners, On</option>
<option>God's Power Over Human Life, On</option>
<option>God's protection, On</option>
<option>God's Revelation of Himself, On</option>
<option>God's Reveleation, Sermon on</option>
<option>God is a Spirit</option>
<option>God ... will not suffer you to be tempted above that ye are able</option>
<option>God is Love</option>
<option>God is not a man that he should lie</option>
<option>God ought to be served rather than Baal</option>
<option>God the only source of comfort, support, & protection</option>
<option>Godliness</option>
<option>Godliness maketh Happy</option>
<option>Godliness profitable unto all things</option>
<option>Godly & worldly sorrow, with their effects</option>
<option>Good Conscience, On</option>
<option>Good Friday, For</option>
<option>Good Friday, On</option>
<option>Good Government, On</option>
<option>Good Life, The Necessity of</option>
<option>Good name, A</option>
<option>Good Samaritan, The</option>
<option>Good Use of Time, On ye</option>
<option>Good works, On</option>
<option>Goodness & mercy of God manifested to all</option>
<option>Goodness & Security of God in the sufferings of Christ, The</option>
<option>Goodness and Bounty of God, The</option>
<option>Goodness of God</option>
<option>Goodness of God, On the</option>
<option>Gospel, On the</option>
<option>Gospel-conversation, On a</option>
<option>Gospel light</option>
<option>Gospel No Cause for Shame, The</option>
<option>Gospel only profitable, A</option>
<option>Gospel preached to the dead, The</option>
<option>Gospel redeems Men from the bondage of Sin, The</option>
<option>Gospel the power of God, The</option>
<option>Government of our Passions & Affections, The</option>
<option>Government of the thoughts, On the</option>
<option>Government of the whole man, The</option>
<option>Grace, On</option>
<option>Grace of God, The</option>
<option>Gracious Declarations of Christ in favor of Little Children, On the</option>
<option>Gracious Declarations of Christ in favor of little children, On the</option>
<option>Grand moral Design of the Gospel, The</option>
<option>Gratitude</option>
<option>Gratitude to God, On</option>
<option>Great Commandment, On the</option>
<option>Great commission, On the</option>
<option>Great is the Mystery of Godliness</option>
<option>Greed, On</option>
<option>Grieving the Spirit</option>
<option>Guarding against detraction from good qualities, On</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
