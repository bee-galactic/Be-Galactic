<?php
#IBR.php
?>
<html>
<head>
<title>ibr</title>
<script language="javascript">
//IBR.php
//from  ser-header_vsearch.php 


function my_ibr_select() {
var sText = new String();

for ( i=0; i< document.ibr_form.ibr_select.length; i++ ) {
	if (document.ibr_form.ibr_select[i].selected == true ) {
		sText = document.ibr_form.ibr_select[i].value;
		break;
		}//end if
	}//end for
parent.document.search_form.sibr.value = sText;
parent.document.search_form.smarkov_key.value= "ibr";
}//end function my_ibr_select 
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body>

<div class="form2">

<form name="ibr_form" >
Biblical Reference by Book of the Bible <a href="../chapter_verse_explain.php" target="_blank">Chapter&Verse</a>
<br />

<?php
include "size_set_CILN.php";
print "<select name=\"ibr_select\" size=\"$menu_size\" onchange=\"my_ibr_select()\">";
?>
<option selected>none selected</option>

<option value="Ac."   >   [Ac.] ------------- Acts</option>
<option value="ApCr"  >  [ApCr] ----------- Apostles Creed (ApCr)</option>
<option value="Ca."   >   [Ca.] ------------- Canticles (Songs of Solomon)</option>
<option value="Ch.1"  >  [Ch.1] ----------- 1 Chronicals</option>
<option value="Ch.2"  >  [Ch.2] ----------- 2 Chronicals</option>
<option value="Col."  >  [Col.] ------------ Colossians</option>
<option value="Cor.1" > [Cor.1] ---------- 1 Corinthians</option>
<option value="Cor.2" > [Cor.2] ---------- 2 Corinthians</option>
<option value="Dn."   >   [Dn.] ------------- Daniel</option>
<option value="Dt."   >   [Dt.] -------------- Deuteronomy</option>
<option value="Ec."   >   [Ec.] ------------- Ecclesiastes</option>
<option value="Eph."  >  [Eph.] ----------- Ephesians</option>
<option value="Est."  >  [Est.] ------------ Esther</option>
<option value="Ex."   >   [Ex.] ------------- Exodus</option>
<option value="Ezk."  >  [Ezk.] ----------- Ezechiel</option>
<option value="Ezr."  >  [Ezr.] ------------ Esdrae, Ezra </option>
<option value="Gal."  >  [Gal.] ------------ Galatians</option>
<option value="Gn."   >   [Gn.] ------------- Genesis</option>
<option value="Hab."  >  [Hab.] ----------- Habakkuk</option>
<option value="Hag."  >  [Hag.] ----------- Haggai</option>
<option value="He."   >   [He.] ------------- Hebrews</option>
<option value="Hos."  >  [Hos.] ----------- Hosea</option>
<option value="Is."   >   [Is.] -------------- Isaiah</option>
<option value="Ja."   >   [Ja.] ------------- James</option>
<option value="Jdg."  >  [Jdg.] ----------- Judges (no entries at present)</option>
<option value="Jer."  >  [Jer.] ------------ Jerimiah</option>
<option value="Jl."   >   [Jl.] -------------- Joel</option>
<option value="John"  >  [John] ----------- John</option>
<option value="Jn.1"  >  [Jn.1] ----------- 1 John</option>
<option value="Jn.2"  >  [Jn.2] ----------- 2 John</option>
<option value="Jn.3"  >  [Jn.3] ----------- 3 John (no entries at present)</option>
<option value="Job"   >   [Job] ------------ Job</option>
<option value="Jon."  >  [Jon.] ----------- Jonas</option>
<option value="Jos."  >  [Jos.] ----------- Joshua</option>
<option value="Jude"  >  [Jude] ---------- Jude</option>
<option value="K.1"   >   [K.1] ------------ 1 Kings</option>
<option value="K.2"   >   [K.2] ------------ 2 Kings</option>
<option value="La."   >   [La.] ------------- Lamentations</option>
<option value="Lk."   >   [Lk.] ------------- Luke</option>
<option value="Lv."   >   [Lv.] ------------- Leviticus</option>
<option value="Mac.1" > [Mac.1] -------- 1 Maccabees (no entries at present)</option>
<option value="Mac.2" > [Mac.2] -------- 2 Maccabees</option>
<option value="Mac.3" > [Mac.3] -------- 3 Maccabees (no entries at present)</option>
<option value="Mac.4" > [Mac.4] -------- 4 Maccabees (no entries at present)</option>
<option value="Mal."  >  [Mal.] ----------- Malachi</option>
<option value="Mic."  >  [Mic.] ----------- Micah</option>
<option value="Mk."   >   [Mk.] ------------ Mark</option>
<option value="Mt."   >   [Mt.] ------------- Matthew</option>
<option value="Nah."  >  [Nah.] ----------- Nahum (no entries at present)</option>
<option value="Neh."  >  [Neh.] ----------- Nehemiah</option>
<option value="Nu."   >   [Nu.] ------------- Numbers</option>
<option value="P.1"   >   [P.1] ------------- 1 Peter</option>
<option value="P.2"   >   [P.2] ------------- 2 Peter</option>
<option value="Phil." > [Phil.] ----------- Philippians</option>
<option value="Phlm." > [Phlm.] --------- Philemon (no entries at present)</option>
<option value="Pr."   >   [Pr.] ------------- Proverbs</option>
<option value="Ps"    >   [Ps.] ------------ Psalms</option>
<option value="Rev."  >  [Rev.] ----------- Revelation</option>
<option value="Ro."   >   [Ro.] ------------ Romans</option>
<option value="Ru."   >   [Ru.] ------------ Ruth (no entries at present)</option>
<option value="La."   >   [La.] ------------- Lamentations</option>
<option value="S.1"   >   [S.1] ------------ 1 Samuel</option>
<option value="S.2"   >   [S.2] ------------ 2 Samuel</option>
<option value="Th.1"  >  [Th.1] ----------- 1 Thessalonians</option>
<option value="Th.2"  >  [Th.2] ----------- 2 Thessalonians</option>
<option value="Tim.1" > [Tim.1] --------- 1 Timothy</option>
<option value="Tim.2" > [Tim.2] --------- 2 Timothy</option>
<option value="Tit."  >  [Tit.] ------------- Titus</option>
<option value="Ws."   >   [Ws.] ----------- Wisdom</option>
<option value="Zc."  >  [Zc.] ------------- Zechariah</option>
<option value="Zep."  >  [Zep.] ----------- Zepariah (no entries at present)</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
