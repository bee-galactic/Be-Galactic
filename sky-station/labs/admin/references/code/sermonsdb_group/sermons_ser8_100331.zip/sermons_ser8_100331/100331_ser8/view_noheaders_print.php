<?php

/*
  SER Project
	2008-01-18
  search or limit list
	with paging

view_batch_print.php 
simplified from view_cart_print.php

*/

include "include_standard.php";

?>
<html><head><title>Sermons Database</title>
<link rel="stylesheet" type="text/css" href="ser.css" />
<?php
$preview = $_GET['preview'];
?>
</head>
<?php
if ($preview==0){
	print "<body onload=\"window.print()\">\n";
}else{
	print "<body >\n";
}
#print "\$preview=$preview<br>";
?>
<table summary="" border="00" cellspacing="10" cellpadding="10" width="660">
<tr><td align="left">
<?php
print $masthead_header;
?>
</td></tr></table>

<table summary="" border="0" cellspacing="10" cellpadding="10">
<tr><td valign="top">

<?php

$doublequote = '"';


//serid_list is the only variable passed
//id_type was previously passed when we displayed both acc and pid
//in view_cart_print.php id type is ALWAYS id ( the pid ) not acc.
//if serid_list=="0", print empty cart message

###view_condensed_print is for use of view_batch_print from view_print_options.

#$serid_list= $_GET['serid_list'];
$serid_list= $_GET['serid_list'];
$serid_str= $_GET['serid_list'];
#$batch_print_str= $_GET['batch_print_list'];
$batch_print_str= $_GET['serid_list'];

if ($batch_print_str == "0") {
  print "<table summary=\"\" border=\"01\" cellspacing=\"10\" cellpadding=\"10\"><tr><td>";
  print "<font face=\"verdana\" size=\"3\">There are no items in the cart.</font>";
  print "</td></tr></table>\n";
  print "</td></tr></table>\n";##this ends the table started in ser-header_vone.php
} else {


#$WHERE_CLAUSE = " WHERE ser_test.pid IN ($serid_list) ";
#$WHERE_CLAUSE = " WHERE ser_test.pid IN ($serid_str) ";

$WHERE_CLAUSE = " WHERE ser_test.pid IN ($batch_print_str) ";
$id_type = "id";


// inits for paging - because continuous feed for printing, removed rest of paging code
$lim=1;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;


$iquery = "SELECT ser_test.pid, ser_test.sermon_id, ser_test.sermon_test_id, ser_test.nameauthor, ser_test.state, ";
$iquery.= "ser_test.denom, ser_test.dates, ser_test.ser_title, ser_test.cover_entry_title, ser_test.book_title, ser_test.totalpgs, ";
$iquery.= "ser_test.placepub, ser_test.publisher, ser_test.date2, ser_test.ser_pgno, ";
$iquery.= "ser_test.placedate, ser_test.indexdate, ser_test.nopgs, ser_test.bibref, ser_test.indexbibref, ";
$iquery.= "ser_test.comment, ser_test.libloc, ser_test.loc_repository, ser_test.libloc_code,ser_test.crossref, ser_test.shorttitle, ser_test.keywords , ser_test.test, ser_test.accession, ser_test.update_date";
$iquery.= " FROM ser2_test2 as ser_test ";
$iquery.= $WHERE_CLAUSE;
#print "</div>\n";

$iquery.= " order by replace(replace(ser_test.nameauthor,\"[\",\"\"),'$doublequote',\"\"),replace(ser_test.shorttitle,\"[\",\"\") "; 


$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";
$iquery2="$iquery";
#print "$iquery2 <hr />";

$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());

#print "\$serid_str=$serid_str";

if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";


$page_counter=0;

#this is a simplified version of view_cart_print.php
#the output is compressed from view_cart_print for proof reading
#header replaced by <hr>
#acc (from header) displayed as data
#footer removed
#page break code removed
#table height=800 removed

#there is an outer table started in ser-header_vone.php 
#   that ends outside while loop at bottom of this page
#   or in case of $serid_list=="0", ends above the start of while loop

#there is an inner table (one row, one col) inside the while loop for print
#<br class="pagebreak"> appears above each inner table after the first one
#pagebreak not used on this page

 while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$cetitle,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_repository,$loc_code,$xref,$sht,$kyw,$test,$acc,$update_date) = mysql_fetch_row($iresult))
  {
        	
        /*----------------------------------------------------
	if ($page_counter == 0 ) {
		$page_counter = 1;
	}else{
		$page_counter += 1;
		#print "<p class=\"pagebreakP\">\n";
		#print "<p STYLE=\"page-break-after: always\">&nbsp;</p>\n";
		#print "<p>&nbsp;</p>\n";
	}
	#print "<p>&nbsp;</p>\n";
	-------------------------------------------------------*/
		print "<HR>";

print "<table border=\"00\" width=\"620\" cellpadding=\"10\" class=\"list\" >";
print "<tr>";
print "<td valign=\"top\"  width=\"600\" >";
  /*----------------------------------------*/
  //print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\"> Accession Number:</div>\n";
        print "<div class=\"cont\">$acc $update_date</div>\n";
  /*------------------------------------------*/
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Author:</div>\n";
	$na=htmlentities($na); # remove this to make <i>...</i> work
	$na_2 = $na;
	$st_2 = $st;
	$dn_2 = $dn;
	$da_2 = $da;
	print "<div class=\"cont\">$na </div>\n";

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">State/Denom/Dates:</div>\n";
	print "<div class=\"cont\"> $st $dn $da</div>\n";
  print "</div>\n";
  if ($cetitle != "none") {
        print "<br />";
        print "<div class=\"item\">";
        print "<div class=\"label\">Cover Entry Title:</div>\n";
        #$srt=htmlentities($srt); #--------remove this to make <i>...</i> work
        $cetitle_2 = $cetitle;
        print "<div class=\"cont\">$cetitle</div>\n";
  print "</div>\n";
        }
	print "<div class=\"item\">";
	print "<div class=\"label\">Title:</div>\n";
	#$srt=htmlentities($srt); # remove this to make <i>...</i> work
	$srt_2 = $srt;
	print "<div class=\"cont\">$srt</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Place/Date Preached:</div>\n";
	$pda=htmlentities($pda);
	$pda_2=$pda;
  	print "<div class=\"cont\">$pda</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Date:</div>\n";
	$ida=htmlentities($ida);
	$ida_2=$ida;
  	print "<div class=\"cont\">$ida</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Number Pages:</div>\n";
	$npgs=htmlentities($npgs);
	$npgs_2=$npgs;
  	print "<div class=\"cont\">$npgs</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Biblical Ref.:</div>\n";
	#$br=htmlentities($br);
	$br_2 = $br;
  print "<div class=\"cont\">$br</div>\n";

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Index Biblical Ref.:</div>\n";
	#$ibr=htmlentities($ibr); # remove this to make <i>...</i> work
	$ibr_2=$ibr;
  print "<div class=\"cont\">$ibr</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Commentary:</div>\n";
	#$cmt=htmlentities($cmt); #remove this line to make <i>...</i> work
	$cmt_2=$cmt;
	
  print "<div class=\"cont\">$cmt</div>\n";

  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Repository (Code):</div>\n";
        $loc_repository=htmlentities($loc_repository);
        $loc_repository_2=$loc_repository;
        $loc_code=htmlentities($loc_code);
        $loc_code_2=$loc_code;
  print "<div class=\"cont\">$loc_repository ($loc_code)</div>\n";

  $s2 = ereg_replace(";","",$loc);

  if ($s2 != $loc_code) {
  print "</div>\n";
        print "<div class=\"item\">";
        print "<div class=\"label\">Repository Details:</div>\n";
        $loc=htmlentities($loc);
        $loc_2=$loc;
  print "<div class=\"cont\">$loc</div>\n";
  }
 
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Short Title:</div>\n";
	#$sht=htmlentities($sht); #remove this line to make <i>...</i> work
	$sht_2=$sht;
  	print "<div class=\"cont\">$sht</div>\n";
  print "</div>\n";
	print "<div class=\"item\">";
	print "<div class=\"label\">Keywords:</div>\n";
  	print "<div class=\"cont\">$kyw</div>\n";
	$kyw_2=$kyw;
  print "</div>\n";


  print '</td></tr></table>'; #this ends the table started in this file
 

  }//end while

 }// end if (mysql_num_rows($iresult))    
} //end else 
print "</td></tr></table>\n";##this ends the table started in ser-header_vone.php

#print $footer;

?>

<script language=javascript src="elements.js"></script>
<script>
//show_elements defined in include_upper.php
show_elements=0;
if (show_elements==1) {
	elements();
}
</script>
</body>
</html>
