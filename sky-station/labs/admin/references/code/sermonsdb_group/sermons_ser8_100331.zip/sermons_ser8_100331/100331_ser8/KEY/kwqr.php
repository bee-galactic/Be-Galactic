<html>
<head>
<title>kwqr</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwqr";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- Q-R</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>quality of Last Judge</option>
<option>Quarles, Miss Sithe</option>
<option>Quarterman, Deacon Thomas</option>
<option>Queen, Mrs., funeral of</option>
<option>race, Christian</option>
<option>Ranney, F. Garner</option>
<option>rashness</option>
<option>reading, instruction</option>
<option>reading of scripture</option>
<option>reason</option>
<option>reason, appeal of Christianity to</option>
<option>reason, Christianity based on</option>
<option>reason, conquered by passion</option>
<option>reason, contradicts predestination</option>
<option>reason, human</option>
<option>reason, inadequacy of</option>
<option>reason, overvaluation of</option>
<option>reason, role of</option>
<option>reason, use of</option>
<option>reason, vs. passion</option>
<option>reason, worship of</option>
<option>rebirth</option>
<option>rebirth, Christian</option>
<option>recollection</option>
<option>reconciled to Christ</option>
<option>reconciliation</option>
<option>recruiting sermon</option>
<option>Red Sea, passage through</option>
<option>redeemer, Christ as</option>
<option>redeeming the time</option>
<option>redemption</option>
<option>redemption, consequences of</option>
<option>redemption, covenant of</option>
<option>redemption, undeserved by man</option>
<option>redemption by Christ</option>
<option>redemption of sinners</option>
<option>reformation</option>
<option>Reformation</option>
<option>reformation</option>
<option>reformation, benefits of</option>
<option>reformation, importance of</option>
<option>reformation, necessity of</option>
<option>reformation of David</option>
<option>reformation of sinners</option>
<option>refusal of grace</option>
<option>regeneration</option>
<option>regeneration, doctrine of</option>
<option>regulators</option>
<option>Rehoboam, folly of</option>
<option>rejecting evil</option>
<option>rejoicing, nature of</option>
<option>relics, devotion to</option>
<option>religion</option>
<option>religion, advantages of</option>
<option>religion, an easy burden</option>
<option>religion, ancient</option>
<option>religion, attacked by U.S. press</option>
<option>religion, attacks on</option>
<option>religion, Christian</option>
<option>religion, confession of</option>
<option>religion, consolations of</option>
<option>religion, defense of</option>
<option>religion, definition of</option>
<option>religion, demise of ancient</option>
<option>religion, doctrines of</option>
<option>religion, duties of</option>
<option>religion, early instruction</option>
<option>religion, enthusiasm in</option>
<option>religion, gloomy</option>
<option>religion, heathen</option>
<option>religion, ignorance of</option>
<option>religion, indifference to</option>
<option>religion, joy in</option>
<option>religion, meditation on</option>
<option>religion, mockery of</option>
<option>religion, moderation in</option>
<option>religion, natural</option>
<option>religion, necessity of</option>
<option>religion, neglect of</option>
<option>religion, not supported by U.S</option>
<option>religion, people hardened against</option>
<option>religion, perseverance in</option>
<option>religion, pleasantness of</option>
<option>religion, profession of</option>
<option>religion, revealed</option>
<option>religion, satisfaction of</option>
<option>religion, self-made</option>
<option>religion, sincerity in</option>
<option>religion, spread of</option>
<option>religion, state of</option>
<option>religion, study of</option>
<option>religion, true</option>
<option>religion, truth of</option>
<option>religion, U.S. government's neglect of</option>
<option>religion, vindication of</option>
<option>religion, writers against</option>
<option>religious advantages, improvement of</option>
<option>religious assemblies, need for</option>
<option>religious duties</option>
<option>religious education, necessity of</option>
<option>religious instruction</option>
<option>religious liberty</option>
<option>religious life</option>
<option>religious service, language of</option>
<option>religious wars</option>
<option>remorse</option>
<option>remorse, nature of</option>
<option>repent, delaying to</option>
<option>repentance</option>
<option>repentance, deathbed</option>
<option>repentance, efficacious</option>
<option>repentance, false</option>
<option>repentance, importance of</option>
<option>repentance, inefficacy of deathbed</option>
<option>repentance, necessity of</option>
<option>repentance, necessity of national</option>
<option>repentance, postponement of</option>
<option>repentance, sincere</option>
<option>repentance, true</option>
<option>repentant sinners, consolation of</option>
<option>reputation, value of</option>
<option>resignation</option>
<option>resignation, religious</option>
<option>resignation to God's will</option>
<option>resisting temptation</option>
<option>resolution, holy</option>
<option>respects, human</option>
<option>responsibilities of a pastor</option>
<option>results of last judgment</option>
<option>resurrection</option>
<option>Resurrection</option>
<option>resurrection</option>
<option>Resurrection</option>
<option>resurrection</option>
<option>Resurrection</option>
<option>resurrection</option>
<option>Resurrection</option>
<option>resurrection</option>
<option>resurrection, general</option>
<option>resurrection, proofs of</option>
<option>resurrection, universal</option>
<option>resurrection of Christ</option>
<option>resurrection of man</option>
<option>resurrection of saints</option>
<option>resurrection of the body</option>
<option>resurrection of the dead</option>
<option>retirement from worldly affairs</option>
<option>retreat, religious</option>
<option>revealed religion</option>
<option>revelation</option>
<option>revelation, apostolic</option>
<option>revelation, Christian</option>
<option>revelation, divine</option>
<option>revelation, Mosaic</option>
<option>revelation, necessity of</option>
<option>revelation, prophetic</option>
<option>revelation, truth of</option>
<option>revelation, various modes of</option>
<option>revelation of Christ</option>
<option>revenge, evil of</option>
<option>revenge, folly of</option>
<option>reverence</option>
<option>Revolution, American</option>
<option>Revolution, end of American</option>
<option>Revolutionary War</option>
<option>rewards, Christ's assurance of future</option>
<option>rewards of heaven</option>
<option>rewards of seeking God</option>
<option>Reynolds, Sally, funeral of</option>
<option>Rich, Bernard</option>
<option>rich and poor, equality of</option>
<option>rich man</option>
<option>rich man, parable of</option>
<option>Rich Man and Lazarus, parable of</option>
<option>riches</option>
<option>riches, correct use of</option>
<option>riches, dangers of</option>
<option>riches, desire for</option>
<option>riches, evil effects of</option>
<option>riches, source of</option>
<option>riches, value of</option>
<option>riches, vanity of</option>
<option>Richmond fire (1812)</option>
<option>Ridgely, Charles, funeral of</option>
<option>Ridgely, William</option>
<option>Rigg, Elisha</option>
<option>righteous, death of</option>
<option>righteous, rewards of</option>
<option>righteousness</option>
<option>righteousness, desire of</option>
<option>righteousness, perseverance in</option>
<option>righteousness, rewards for</option>
<option>righteousness, servants of</option>
<option>riotousness</option>
<option>ritual, religious</option>
<option>Robespierre</option>
<option>Robinson, Rachel, funeral of</option>
<option>Roman Civil Wars</option>
<option>Roman philosophers</option>
<option>Roper, Betsy, funeral of</option>
<option>Rousseau</option>
<option>rulers, obligations of</option>
<option>rulers of England</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
