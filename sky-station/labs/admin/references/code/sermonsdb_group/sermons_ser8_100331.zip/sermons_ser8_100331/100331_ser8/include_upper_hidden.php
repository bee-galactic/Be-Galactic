
<?php

#used by view_cart_print.php

$serid_str  = $_GET['serid_list'];
print "\$serid_string=$serid_str<hr>";
if ($serid_str==""){
	$serid_str="0";
	}

print "<!--- PRIMARY LOCATION for document.formW.serid_list.value -->\n";
print "<form name=\"formW\" >\n";
print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\">\n";
print "<input type=\"hidden\" name=\"batch_print_list\" value=\"0\">\n";
print "<input type=\"hidden\" name=\"this_page_pid_list\" value=\"\">\n";
print "<input type=\"hidden\" name=\"other_page_pid_list\" value=\"\">\n";
print "</form>\n";
?>

