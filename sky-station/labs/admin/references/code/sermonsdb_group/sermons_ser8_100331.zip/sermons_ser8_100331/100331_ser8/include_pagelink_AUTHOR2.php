<?php
#include "./ser-header_frames.php";
#include "./ser-header_links.php";
$doublequote='"';
/*---------------------------------------------------------------
These functions are for 
	view_author_title_index.php
	view_batch_select.php
	view_cart_index.php
	view_cart_display.php

function go_to_page (called by PageLinkTop, PageLinkBottom, PageLinkGo)
	When you click prev or next button, go_to_page is called.
function PageLinkGo2 (PageLinkTop for author and batch)
		calls go_to_page()

function PageLinkTop() (for view_cart_index and view_cart_display)
		calls go_to_page()
		but has no go_button
function PageLinkBottom() (for all)
		calls go_to_page()

-----------------------------------------------------------------*/

?>

<script language="javascript">

function go_to_page(type,display_page_number,limitt,numhitts,max_page_number,incc,decc) {

var limit = new Number(limitt);
var curr_page = new String(document.form_go_button.this_DPN.value);
var target_page = new Number(curr_page);
var top_page = new Number(max_page_number);
if (type=="jump") {
    	target_page = Number(document.form_go_button.this_page.value);
	if(target_page>top_page){ 
	  alert("You have entered an out of range page number.\n\nPlease try again.");
	  document.form_go_button.this_page.value="";
	  return;
	  }
		
}else if (type=="next") {
    	target_page++;
    	if (target_page > top_page) target_page=max_page_number;
}else if (type=="prev") {
    	target_page--;
    	if (target_page < 1) target_page=1;
}else if (type=="stay") {
	target_page = target_page;
}

var inc=limitt;
var record_num = limitt * target_page;
var LINK=new String(location.href);
var lnk=new String(location.href);
if(!confirm("1. lnk="+lnk))return;

if (type=="stay") {
	lnk=lnk;
	if(!confirm("2a. stay\n lnk="+lnk))return;
}else if (LINK.indexOf("this_page_pid_list")>-1) {
	//first page load treated differently
	lnk = lnk.substring(0,lnk.indexOf("&this_page_pid_list"));
	lnk = lnk.replace("%2c",",");
	lnk = lnk + "&rec=";
	if(!confirm("2b. this_page_pid_list\n lnk="+lnk))return;
}else if (LINK.indexOf("search")>-1){
	lnk=lnk;

}else{
	lnk = lnk.substr(0,lnk.indexOf("&rec=")+5);//trim off location.href, keep "&rec=";
	if(!confirm("2c. else\n lnk="+lnk))return;
}

if(!confirm("3. lnk="+lnk))return;

var srh = new String();
var recnum = new Number();
    recnum = record_num;
    if (recnum > numhitts) recnum=numhitts;
//////////(Records 201 to 220 of 1699) 
//////////(Records from_recnum to to_recnum of numhitts)
var cpage      =new Number(display_page_number);
var tpage      =new Number(target_page);//jump value
var LIMIT      =new Number(limit);
var from_recnum=new Number(); 
var to_recnum  =new Number();
if(type=='stay'){
	tpage = cpage;
    	from_recnum=((tpage-1)*LIMIT)+1;
    	to_recnum  =(tpage*LIMIT);
	}
if(type=='next'){
	tpage = cpage+1;
    	from_recnum=((tpage-1)*LIMIT)+1;
    	to_recnum  =(tpage*LIMIT);
	}
if(type=='prev'){
	tpage=cpage-1;
	from_recnum=((tpage-1)*LIMIT)+1;
	to_recnum  =(tpage*LIMIT);
	}

var r2 = from_recnum; //beginning recnum

var r4 = to_recnum%limitt; //go for next (limit=20) records

var r3 = target_page;
    r3 = tpage;
if (type=='next'){
	r3=target_page-1;
	r3=tpage-1;
	}
if(type=='prev'){
	r3=target_page-2;
	r3=tpage-2;
	}
if(type=='jump'){
	r3=tpage-2;
	}

document.form_go_button.this_DPN.value=tpage;
/*HERE*/
var r5 = new Number();
if(type== 'jump'){
	r5 = r3*limitt;
        if(r5>numhitts-(2*limitt)) r5=numhitts-(2*limitt)+1;//hi_recnum
	}
if(type=='next'||type=='prev'){
    	r5 = from_recnum-1-(limitt);
	}
var sr5= new String(r5);

var low_num = limitt + 1;

if (recnum<low_num) {
	//srh="20&dec="+limitt;
	srh=limitt+"&dec="+limitt;
}else {
	srh=sr5+"&inc="+limitt;
}

srh = srh +"&serid_list="+document.formW.serid_list.value;

lnk = lnk+srh;
/**/
if (!confirm("go_to_page:"
	+"\ntype="+type
	+"\nnumhitts="+numhitts
	+"\nrecnum="+recnum
	+"\nlimitt="+limitt
	+"\ntarget_page="+target_page
	+"\n\nr2="+r2
	+"\nr3="+r3
	+"\nr4="+r4
	+"\nr5="+r5
	+"\ntpage="+tpage
	+"\nLIMIT="+LIMIT
	+"\nfrom_recnum="+from_recnum
	+"\nto_recnum="+to_recnum
	+"\n\nsr5="+sr5
	+"\n\n target page: lnk="+lnk
	))return;
/**/

location.replace(lnk);

} //end function go_to_page() 



</script>
<?php

function PageLinkBottom()
{

//print "PageLinkBottom() uses function go_to_page via form_go_button<br>";

 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $DisplayRecord=$rec+1;

 print "<div class=\"instruct2\">";

 print "<form name=\"form_bottom_buttons\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"hidden\" name=\"this_page\" value=\"\" >";

 print "<br>";
 if ($numhits>$lim)
  {
  print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($rec!=0) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_back\" ";
	print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"<< Back\" class=\"bluebutton100\" >";
	}	
       else 
  	{
  	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
  	}
   }

  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
	$chnk=$rec+$lim;
	if ($chnk > $numhits) $chnk=$numhits;
	print "$chnk of $numhits) ";

  if($rec<$numhits-$lim) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_next\" ";
	print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"Next >>\" class=\"bluebutton100\" >";
        }
	else 
	{
	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
 print "</form>";
 print "<br>include_pagelink_AUTHOR.php function PageLinkBottom calls go_to_page()";
 print "</div>";
}//end function PageLinkBottom();

function PageLinkTop()
{
//print "PageLinkTop() uses function go_to_page via form_go_button<br>";
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;

 $page_total = (int)(($numhits/$lim)+1);
 $inumhits=$numhits%$lim;

 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 //----  prev-next links
 if ($inc == 0 && $dec==0) {
        $DisplayPageNumber=1;
 }else if ($inc > 0) {
        $DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
        $DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $DisplayRecord=$rec+1;

 print "<div class=\"instruct2\">";

 print "\$inc=$inc -- \$dec=$dec -- \$rec=$rec -- \$lim=$lim";
 print "<br>if(\$inc>0) \$DisplayPageNumber=(\$rec+\$inc)/\$inc)";
 print "<br>if(\$dec>0) \$DisplayPageNumber=(\$rec+\$dec)/\$dec)";
 print "<br>\$numhits=$numhits"; #1698
 print "<br>\$inumhits=$inumhits"; #18
 print "<br>\$DisplayPageNumber=$DisplayPageNumber";
 print "<br>\$DisplayRecord=$DisplayRecord";
 print "<br>\$MaxPageNumber=$MaxPageNumber";
 print "<br>\$iMaxPageNumber=$iMaxPageNumber";
 print "<br>\$page_total=$page_total";


 //this form has to have the name form_go_button to match name on view_author_title_index
 //need because function go_to_page refers to some of these form elements
 print "<form name=\"form_go_button\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"hidden\" name=\"this_page\" value=\"\" >";

 print "<hr><pre>";
 print "<br>function PageLinkTop()";
 print "<br>&lt;form name=\"form_go_button\">";
 print "<br>&lt;input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<br>&lt;input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<br>&lt;input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<br>&lt;input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<br>&lt;input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<br>&lt;input type=\"text\" size=\"2\" value=\"\" name=\"this_page\">";
 print "<br>&lt;/form>";
 print "</pre><hr>";

 if ($numhits>$lim)
  {
  print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        if ($rec!=0)
          {
        print "&nbsp;<input type=\"button\" name=\"link_back\" ";
        print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
        print " value=\"<< Back\" class=\"bluebutton100\" >";
        }
 } else {
   print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}

  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
        $chnk=$rec+$lim;
        if ($chnk > $numhits) $chnk=$numhits;
        print "$chnk of $numhits) ";

  if($rec<$numhits-$lim)
          {
        print "&nbsp;<input type=\"button\" name=\"link_next\" ";
        print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
        print " value=\"Next >>\" class=\"bluebutton100\" >";
    	}
        else 
	{
	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
     
 print "</form>";
 print "<br>include_pagelink_AUTHOR.php function PageLinkTop calls go_to_page()";
 print "</div>";
}//end function PageLinkTop();



#only used by view_author_title_index.php, view_batch_select.php
#has go_button
function PageLinkGo()
{
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;

 $page_total = (int)(($numhits/$lim)+1);

 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
 }


 $inumhits=$numhits%$lim;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 $DisplayRecord=$rec+1;
 print "<div class=\"instruct2\">";
 print "\$inc=$inc -- \$dec=$dec -- \$rec=$rec -- \$lim=$lim";
 print "<br>if(\$inc>0) \$DisplayPageNumber=(\$rec+\$inc)/\$inc)";
 print "<br>if(\$dec>0) \$DisplayPageNumber=(\$rec+\$dec)/\$dec)";
 print "<br>\$numhits=$numhits"; #1698
 print "<br>\$inumhits=$inumhits"; #18
 print "<br>\$DisplayPageNumber=$DisplayPageNumber";
 print "<br>\$DisplayRecord=$DisplayRecord";
 print "<br>\$MaxPageNumber=$MaxPageNumber";
 print "<br>\$iMaxPageNumber=$iMaxPageNumber";
 print "<br>\$page_total=$page_total";


 print "<div class=\"instruct2\">";
 print "\$inc=$inc -- \$dec=$dec -- \$rec=$rec ";
 print "<br>if(\$inc>0) \$DisplayPageNumber=(\$rec+\$inc)/\$inc)";
 print "<br>if(\$dec>0) \$DisplayPageNumber=(\$rec+\$dec)/\$dec)";
 print "<br>\$numhits=$numhits";
 print "<form name=\"form_go_button\">";
 if ($numhits>$lim)
  {
  //print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($rec!=0) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_back2\" ";
	print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"<< Back\" class=\"bluebutton100\" >";
	}	
  else {print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";}
  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
	$chnk=$rec+$lim;
	if ($chnk > $numhits) $chnk=$numhits;
	print "$chnk of $numhits) ";

  if($rec<($numhits-$lim)) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_next2\" ";
	print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 	print " value=\"Next >>\" class=\"bluebutton100\" >";
	print "&nbsp;&nbsp;\n";
    }
	else print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
 #print "</form>";

 	print "Find Page (1-$page_total):";
 #print "<form name=\"form_go_button\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"text\" size=\"2\" value=\"\" name=\"this_page\">&nbsp;<input type=\"button\" name=\"page_link_button\" ";
 print " onclick=\"go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";

 print " value=\"Go\" class=\"bluebutton40\" >";
 print "</form>\n";

 print "<hr><pre>";
 print "<br>function PageLinkGo()";
 print "<br>&lt;form name=\"form_go_button\">";
 print "<br>&lt;input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<br>&lt;input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<br>&lt;input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<br>&lt;input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<br>&lt;input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<br>&lt;input type=\"text\" size=\"2\" value=\"\" name=\"this_page\">";
 print "<br>&lt;input type=\"button\" name=\"page_link_button\" ";
 print " onclick=\"go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 print "</pre><hr>";
 print "<br>include_pagelink_AUTHOR.php function PageLinkGo calls go_to_page()";
 print "</div>";
}//end function PageLinkGo();



/*for view_batch_select only--does reset_formW() on button clicks*/

function PageLinkGo2()
{
 global $numhits,$lim,$rec,$inc,$dec,$lnk,$serid_str;

//N="100" for batch print


 //----  prev-next links
 if ($inc == 0 && $dec==0) {
	$DisplayPageNumber=1;
 }else if ($inc > 0) {
	$DisplayPageNumber = ($rec+$inc)/$inc;
 }else if ($dec >0) {
	$DisplayPageNumber = ($rec+$dec)/$dec;
 }

 $page_total = (int)(($numhits/$lim)+1);

 $inumhits=$numhits%$lim;
 $MaxPageNumber=($numhits/$lim);
 $iMaxPageNumber=(int)$MaxPageNumber;
 if ($iMaxPageNumber<$MaxPageNumber) $MaxPageNumber=$iMaxPageNumber+1; 
 $DisplayRecord=$rec+1;
 print "<div class=\"instruct2\">";
 print "\$inc=$inc -- \$dec=$dec -- \$rec=$rec -- \$lim=$lim";
 print "<br>if(\$inc>0) \$DisplayPageNumber=$DisplayPageNumber=(\$rec+\$inc)/\$inc)";
 print "<br>if(\$dec>0) \$DisplayPageNumber=$DisplayPageNumber=(\$rec+\$dec)/\$dec)";
 print "<br>\$numhits=$numhits"; #1698
 print "<br>\$inumhits=$inumhits"; #98
 print "<br>\$MaxPageNumber=$MaxPageNumber";
 print "<br>\$iMaxPageNumber=$iMaxPageNumber";
 print "<br>\$page_total=$page_total";


 if ($lim ==100){
	#print "<br>When you click any button on this page, all checkboxes are cleared <br>to prevent printing of more than 100 records at a time.";

	}

 print "<form name=\"form_go_button\">";
 if ($numhits>$lim)
  {
  //print "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($rec!=0) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_back2\" ";
	if ($lim == 100){
	print " onclick=\"reset_formW();go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec);\" ";
	}else{
	print " onclick=\"go_to_page('prev',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
	}
 	print " value=\"<< Back\" class=\"bluebutton100\" >";
	}	
  else print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
  print " Page $DisplayPageNumber (Records $DisplayRecord to ";
	$chnk=$rec+$lim;
	if ($chnk > $numhits) $chnk=$numhits;
	print "$chnk of $numhits) ";

  if($rec<$numhits-$lim) 
	  {
	print "&nbsp;<input type=\"button\" name=\"link_next2\" ";
	if ($lim == 100){
	print " onclick=\"reset_formW();go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
	}else{
	print " onclick=\"go_to_page('next',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
	}
 	print " value=\"Next >>\" class=\"bluebutton100\" >";
	print "&nbsp;&nbsp;\n";
    }
	else print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
	}
 #print "</form>";

 print "<br>\$rec=$rec"; 
 print "<br>\$chnk=$chnk"; 
 print "<br>\$DisplayPageNumber=$DisplayPageNumber";
 print "<br>";


 print "Find Page (1-$MaxPageNumber):";
 #print "<form name=\"form_go_button\">";
 print "<input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<input type=\"text\" size=\"2\" value=\"\" name=\"this_page\">&nbsp;<input type=\"button\" name=\"page_link_button\" ";
 if ($lim==100){
 print " onclick=\"reset_formW();go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 }else{
 print " onclick=\"go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 }

 print " value=\"Go\" class=\"bluebutton40\" >";
 print "</form>\n";
 print "<hr><pre>";
 print "<br>function PageLinkGo2()";
 print "<br>&lt;form name=\"form_go_button\">";
 print "<br>&lt;input type=\"hidden\" name=\"rec\" value=\"$rec\" >";
 print "<br>&lt;input type=\"hidden\" name=\"nh\" value=\"$numhits\" >";
 print "<br>&lt;input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\" >";
 print "<br>&lt;input type=\"hidden\" name=\"this_limit\" value=\"$lim\" >";
 print "<br>&lt;input type=\"hidden\" name=\"this_DPN\" value=\"$DisplayPageNumber\" >";
 print "<br>&lt;input type=\"text\" size=\"2\" value=\"\" name=\"this_page\">";
 print "<br>&lt;input type=\"button\" name=\"page_link_button\" ";
 print " onclick=\"go_to_page('jump',$DisplayPageNumber,$lim,$numhits,$MaxPageNumber,$inc,$dec)\" ";
 print "<br>&lt;/form>";
 print "</pre><hr>";
 print "<br>include_pagelink_AUTHOR.php function PageLinkGo2 calls go_to_page()";
 print "</div>";
}//end function PageLinkGo2();




//--- end of php functions


?>


