<html>
<head>
<title>na_loc_cet</title>
<script language="javascript">
//from  ida_090723.php 


function my_both_select(){
//alert("both");
if ( document.state_form.state_select[0].selected==true
  && document.state_form.denom_select[0].selected==true ) {
	alert("Please make a selection from State and/or Denomination.");
	return;
	}
parent.document.search_form.state.value="";//clear parent.state field
parent.document.search_form.denom.value="";//clear parent.denom field
parent.document.search_form.cetitle.value="";//clear parent.cetitle field
parent.document.search_form.smarkov_key.value= "den";

var sText  = new String("");
var sState = new String("");
var sDenom = new String("");
var sLabel = new String("");

for ( i=1; i< document.state_form.state_select.length; i++ ) {
	if (document.state_form.state_select[i].selected == true ) {
		sState = document.state_form.state_select[i].value;
		sText += document.state_form.state_select[i].value;
		break; //select only one
		}//end if
	}//end for

for ( i=1; i< document.state_form.denom_select.length; i++ ) {
	if (document.state_form.denom_select[i].selected == true ) {
		sDenom = document.state_form.denom_select[i].value;
		sText += document.state_form.denom_select[i].value;
		break;
		}//end if
	}//end for

parent.document.search_form.state.value=sState;
parent.document.search_form.denom.value=sDenom;
parent.document.search_form.CSDval.value= sState+" AND "+sDenom;
parent.document.search_form.smarkov_key.value= "den";
if (sState.length > 0 && sDenom.length == 0){
	sLabel = "State";
	parent.document.search_form.CSDval.value= sState;
}else if (sState.length == 0 && sDenom.length > 0){
	sLabel = "Denom.";
	parent.document.search_form.CSDval.value= sDenom;
}else if (sState.length > 0 && sDenom.length > 0){
	sLabel = "State and Denom.";
	parent.document.search_form.CSDval.value= sState+" AND "+sDenom;
}
//alert ("sState.length="+sState.length+"\nsDenom.length="+sDenom.length);
parent.document.search_form.smarkov_CSD.value= sLabel;
parent.document.all.CSD.innerHTML=sLabel;

}//end function my_both_select 


function pop_clear(){
	document.state_form.state_select[0].selected=true;
for ( i=1; i< document.state_form.state_select.length; i++ ) {
        document.state_form.state_select[i].selected = false;
	}
	document.state_form.denom_select[0].selected=true;
for ( i=1; i< document.state_form.denom_select.length; i++ ) {
        document.state_form.denom_select[i].selected = false;
	}
	parent.document.search_form.state.value="";
	parent.document.search_form.denom.value="";
	parent.document.search_form.CSDval.value="";
	//parent.document.all.CSD.innerHTML="Cover Entry Title";
	}

/*
need to add onKeypress code to make 4 digits mandatory
*/
///usage: onKeypress="return digits_only_rule(event,this)"
function digits_only_rule (event,sbox) {

var e = event;
var KS; //keystroke value
var rmc = 2; //right mouse click IE
   // KS the keystroke entered
  if ( typeof(e.which) != 'undefined' ) {//netscape
        KS = e.which;
        rmc = 3; //right mouse click netscape
   }else {
        KS = e.keyCode;
   }

  if ((KS > 47) && (KS < 58)) { return true;} //integer
   if (KS == 8) return true; // Backspace
   if (KS == 9) return true; // Tab
   ////if (KS == 32) return true; //whitespace


   alert("Only integer numbers are allowed in this field.");
   return false;

}///end function


</script>

<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body></div class="form2">
<form name="state_form" >
<table border="00"  cellpadding="1" cellspacing="0" width="380">
<tr><td valign="top" width="50%">
<div class="form2">
Search by State<br>
<?php
$menu=8;
print "<select name=\"state_select\" size=\"$menu\" >";
?>
<option value="" selected>none selected</option>
<option value="GA">Georgia</option>
<option value="MD">Maryland</option>
<option value="NC">North Carolina</option>
</option value="NJ">New Jersey</option>
</option value="PA">Pennsylvania</option>
<option value="SC">South Carolina</option>
<option value="VA">Virginia</option>
<option value="State Unknown">Unknown</option>
</select>
</div>
</td><td valign="top">
<div class="form2">
Search by Denomination<br />
<?php
print "<select name=\"denom_select\" size=\"$menu\"  >";
?>
<option value="" selected>none selected</option>
<option value="Bapt">Baptist</option>
<option value="Cath">Catholic</option>
<option value="Cong">Congregational</option>
<option value="Epis">Episcopal</option>
<option value="Luth">Lutheran</option>
<option value="Meth">Methodist</option>
<option value="Pres">Presbyterian</option>
<option value="Quaker">Quaker</option>
<option value="Denom. Unknown">Unknown</option>
</select>
<br />
</div></td></tr><tr><td valign="top" colspan="2"><div class="form2"><input type="button" name="enter_both" value="Search"
class="bluebutton110" onclick="my_both_select()">&nbsp;Select an item from one or both menus, then click Search.
</div>
</td></tr>
<tr><td valign="top" colspan="2"><div class="form2"><input type="button" name="clear_both" value="Clear" class="bluebutton110" onclick="pop_clear()">&nbsp;Clear selected items.
</div>
</td></tr></table>
</form name="state_form">
</div>
</body>
</html>
