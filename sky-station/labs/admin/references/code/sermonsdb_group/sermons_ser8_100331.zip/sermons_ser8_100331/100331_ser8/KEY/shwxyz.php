<html>
<head>
<title>shwxyz</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shw";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- W-X-Y-Z</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Wait for the Hope of Righteousness by Faith</option>
<option>Waiting patiently, till the change come</option>
<option>Walk in the Spirit</option>
<option>Walking circumspectly</option>
<option>Walking Circumspectly, Of</option>
<option>Walking Circumspectly in Evil Days, On</option>
<option>Walking with God, On</option>
<option>Walking worthy of ye Lord unto all pleasing</option>
<option>Way of Peace, The</option>
<option>We ... are compassed ... with so great a cloud of witnesses</option>
<option>We are ambassadors for Xt</option>
<option>We must all appear before the Judgment-Seat of Xt</option>
<option>We must all appear before the Judgment Seat of Christ</option>
<option>We preach not ourselves, but Christ Jesus</option>
<option>We preach not ourselves, but Xt Jesus</option>
<option>We Preach Xt. crucified</option>
<option>We speak not as pleasing Men, but God</option>
<option>We will serve the Lord</option>
<option>Wealth</option>
<option>Wealth, On</option>
<option>Wedding Sermon</option>
<option>What is a man profited?</option>
<option>What is a man profited if he shall gain the whole world</option>
<option>What is to be done for the inheritance of eternal life, On</option>
<option>What manner of Persons ought we to be</option>
<option>Whatsoever ye would that Men should do to you</option>
<option>When I have [a] convenient season, I will call for thee</option>
<option>When the fulness of the Time ... God sent forth h[is] Son</option>
<option>When the unclean spirit is gone out of a man</option>
<option>While ye Child was yet alive</option>
<option>Whipping & thorns</option>
<option>Whitsunday, For</option>
<option>Who gave Jacob for a Spoil, & Israel to the Robbers?</option>
<option>Whole armour of God, The</option>
<option>Wicked presume upon their Impunity</option>
<option>Wickedness and destruction of the old world, On the</option>
<option>Wickedness its own Punishment</option>
<option>Wickedness of Christians no proof against Christianity, The</option>
<option>Wilkinson, John, sermons</option>
<option>Wine & Milk without Money & without Price</option>
<option>Wisdom's Happiness and Sin's Misery</option>
<option>Wisdom, Money, and Knowledge</option>
<option>Wisdom is justified of all his children</option>
<option>Wisdom of fearing God, The</option>
<option>Wisdom of God, On the</option>
<option>Wise Son Maketh a Glad Father, A</option>
<option>Without me ye can do nothing</option>
<option>Wonderful Compassions of Christ to the greatest Sinners, The</option>
<option>Word of God, On the</option>
<option>Words of Eternal Life, The</option>
<option>Work of Christ, For the</option>
<option>Work out your own Salvation</option>
<option>Work out your own Salvation with Fear and Trembling</option>
<option>Working</option>
<option>Working with Fear & Trembling</option>
<option>Works in sin, Of</option>
<option>Works of Christ, On the</option>
<option>Worldliness, On</option>
<option>Worldly wisdom spiritually improved</option>
<option>Worship, On</option>
<option>Worship in spirit and truth, On</option>
<option>Worthiness of Heavenly Glory</option>
<option>Wrongful Actions of Nations, On the</option>
<option>Ye cannot serve God & Mammon</option>
<option>Ye shall not swear by my Name falsely</option>
<option>Ye should do as I have done to you</option>
<option>Yoke of Christ easy, The</option>
<option>Your labor is not in vain in the Lord</option>
<option>Youth on being Sober-minded, To</option>
<option>Youth Reminded of A Judgment to Come</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
