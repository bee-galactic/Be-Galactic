<html>
<head>
<title>she</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="she";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- E</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Ear & the eye -- proofs of the existence of a God, The</option>
<option>Early piety, On</option>
<option>Earth a Place of Troubles, The</option>
<option>Earthly happiness, On</option>
<option>Ease, Of</option>
<option>Easiness of Christ's yoke, The</option>
<option>Easter, For</option>
<option>Easter, On</option>
<option>Easter Duty</option>
<option>Easter duty, On</option>
<option>Easter Sermon</option>
<option>Easter Sunday, On</option>
<option>Education, On</option>
<option>Effects of Sin, Ye</option>
<option>Eight Beatitudes, On ye</option>
<option>Eighth Article of the Creed, On the</option>
<option>Eighth Commandment, On the</option>
<option>Eleventh and twelfth articles of the Creed, On the</option>
<option>Encouragement to persevere in well-doing</option>
<option>End and the Means, The</option>
<option>End of Christ's giving himself for us</option>
<option>End of the perfect & upright man, The</option>
<option>Envy, On</option>
<option>Epiphany</option>
<option>Epiphany, For the</option>
<option>Epiphany, On the</option>
<option>Epiphany, On ye</option>
<option>Episcopal Charitable Institution, For the</option>
<option>Establishment of the Xn Church, On the</option>
<option>Eternal life</option>
<option>Eternity</option>
<option>Eternity, On</option>
<option>Eternity of God, On the</option>
<option>Eucharist, On the</option>
<option>Eucharist: Frequentation</option>
<option>Eucharist: The Great Supper</option>
<option>Eucharist: The Old Law and the New</option>
<option>Eucharist as Thanksgiving(1), On the</option>
<option>Eucharist as Thanksgiving(2), On the</option>
<option>Evening Prayer, On</option>
<option>Everlasting Life, On</option>
<option>Every man shall receive his own reward</option>
<option>Every one that loveth is born of God</option>
<option>Evil, On</option>
<option>Evil of Punishment, On the</option>
<option>Example of Nehemiah, The</option>
<option>Examples to Christians</option>
<option>Excellence of the Holy Scriptures, On the</option>
<option>Excellency of the knowledge of Christ Jesus, The</option>
<option>Except a man be born again He cannot see the Kingdom of God</option>
<option>Except ye repent, ye shall all in like manner perish</option>
<option>Excommunication of John Causse, On the</option>
<option>Exhortation to fraternal Charity, An</option>
<option>Exodus 33: 18-19, On</option>
<option>Experience -- hope</option>
<option>Ezek 33, 33 Sermon 2d</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
