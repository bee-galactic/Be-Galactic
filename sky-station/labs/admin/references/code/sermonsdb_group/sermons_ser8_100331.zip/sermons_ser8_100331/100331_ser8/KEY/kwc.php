<html>
<head>
<title>kwc</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwc";
document.pform.submit();
}//end function pchange()
</script>
</head>
<link rel="stylesheet" type="text/css" href="../ser.css" />
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- C</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Caesar</option>
<option>Cain</option>
<option>Cain and Abel</option>
<option>calamities, acceptance of</option>
<option>calamities, purpose of</option>
<option>calamities as judgments from God</option>
<option>Calvary</option>
<option>Calvin, John</option>
<option>Campbell</option>
<option>Cana, marriage feast of</option>
<option>Canaan, conquest of</option>
<option>Canaanites</option>
<option>Cane, F.</option>
<option>canonical scripture</option>
<option>Canterbury, St. Thomas of</option>
<option>Canticles, Book of</option>
<option>Carey, D.</option>
<option>Carey, Rachel, funeral of</option>
<option>Carey, Sally, funeral of</option>
<option>Carr, Elizabeth</option>
<option>Carr, Jon</option>
<option>Carrington, Col. George, funeral of</option>
<option>Carter, Priscilla</option>
<option>Carter, Robert, funeral of</option>
<option>Cassandra</option>
<option>catechism</option>
<option>Catholic Church</option>
<option>Catholic Church, criticism of</option>
<option>Catholic Church, persecution of</option>
<option>Catholicism, defeat of</option>
<option>Catholicism, opposition to</option>
<option>Causse, Rev. John B.</option>
<option>Cavenaughs</option>
<option>certainty of dissolution of the world</option>
<option>certainty of last judgment</option>
<option>certainty of salvation</option>
<option>chapel, dedication of</option>
<option>chapel, opening of</option>
<option>Chapman, Nuthill</option>
<option>character, man's</option>
<option>charities, misuse of</option>
<option>charity</option>
<option>charity, Christian</option>
<option>charity, fraternal</option>
<option>charity, fundamental Christian doctrine</option>
<option>charity, necessity of</option>
<option>charity, persuasion to</option>
<option>charity school</option>
<option>Charles I, execution of</option>
<option>Charlottesville</option>
<option>chastisement</option>
<option>chastity</option>
<option>cheer, good</option>
<option>cheerfulness</option>
<option>cheerfulness, from obedience</option>
<option>Chew, Thomas John</option>
<option>children</option>
<option>children, Christ's love for</option>
<option>children, discipline of</option>
<option>children, duties of</option>
<option>children, duty to educate</option>
<option>children, duty to obey parents</option>
<option>children, duty towards</option>
<option>children, education of</option>
<option>children, importance of to God</option>
<option>children, joy of</option>
<option>children, overindulgence of</option>
<option>children, parents' duties to</option>
<option>children, poor, duties to</option>
<option>children, proper education of</option>
<option>children, religious education of</option>
<option>children, teaching music to</option>
<option>children, training by parents</option>
<option>children of clergymen</option>
<option>Children of Light</option>
<option>chosen people</option>
<option>Christ's coming, preparation for</option>
<option>Christ's disciples</option>
<option>Christ's divinity denied</option>
<option>Christ's incarnation</option>
<option>Christ's influence</option>
<option>Christ's love</option>
<option>Christ's yoke, easiness of</option>
<option>Christ, acknowledgement of</option>
<option>Christ, actions of</option>
<option>Christ, ambassadors for</option>
<option>Christ, Ascension of</option>
<option>Christ, atonement of</option>
<option>Christ, authority of</option>
<option>Christ, baptism of</option>
<option>Christ, belief in</option>
<option>Christ, betrayal of</option>
<option>Christ, betrayal of by Judas</option>
<option>Christ, birth of</option>
<option>Christ, blessings of</option>
<option>Christ, blood of</option>
<option>Christ, body and blood of</option>
<option>Christ, body of</option>
<option>Christ, burial of</option>
<option>Christ, character of</option>
<option>Christ, church founded by</option>
<option>Christ, Church of</option>
<option>Christ, commission to the Apostles</option>
<option>Christ, commitment to</option>
<option>Christ, compassion of</option>
<option>Christ, confidence in</option>
<option>Christ, contemplation of his sufferings</option>
<option>Christ, crucifixion of</option>
<option>Christ, David's prophecy of</option>
<option>Christ, death of</option>
<option>Christ, defended by Peter</option>
<option>Christ, denied by Peter</option>
<option>Christ, descent from David</option>
<option>Christ, dignity of</option>
<option>Christ, divine and human nature of</option>
<option>Christ, divine power of</option>
<option>Christ, divinity of</option>
<option>Christ, dominion of</option>
<option>Christ, duty to imitate</option>
<option>Christ, emulation of</option>
<option>Christ, exaltation of</option>
<option>Christ, example of</option>
<option>Christ, faith in</option>
<option>Christ, fellowship with God through</option>
<option>Christ, forgiveness in</option>
<option>Christ, frequenting of synagogues</option>
<option>Christ, fulfillment of prophecy</option>
<option>Christ, healing power of</option>
<option>Christ, hour of</option>
<option>Christ, humanity of</option>
<option>Christ, humiliation of</option>
<option>Christ, humility of</option>
<option>Christ, imitation of</option>
<option>Christ, incarnation of</option>
<option>Christ, intercession of</option>
<option>Christ, invitation of</option>
<option>Christ, Jesus</option>
<option>Christ, justification through</option>
<option>Christ, knowledge of</option>
<option>Christ, life of</option>
<option>Christ, love for mankind</option>
<option>Christ, love of</option>
<option>Christ, man's savior</option>
<option>Christ, martyrdom of</option>
<option>Christ, mercy of</option>
<option>Christ, mildness of toward sinners</option>
<option>Christ, ministry of</option>
<option>Christ, miracles of</option>
<option>Christ, moral system of</option>
<option>Christ, mysteries of</option>
<option>Christ, mystical body of</option>
<option>Christ, mystical union with</option>
<option>Christ, name of</option>
<option>Christ, nativity of</option>
<option>Christ, obedience of</option>
<option>Christ, obedience to</option>
<option>Christ, opposition to</option>
<option>Christ, pardon of sinners</option>
<option>Christ, passion of</option>
<option>Christ, persecution of</option>
<option>Christ, preaching of</option>
<option>Christ, preparation of the people of</option>
<option>Christ, prepared for</option>
<option>Christ, presence of</option>
<option>Christ, presence of in Eucharist</option>
<option>Christ, proper expression of love for</option>
<option>Christ, prophecies of</option>
<option>Christ, prophecy of</option>
<option>Christ, prudence of</option>
<option>Christ, qualities of</option>
<option>Christ, reconciliation to</option>
<option>Christ, remembrance of</option>
<option>Christ, resurrection of</option>
<option>Christ, revelation of</option>
<option>Christ, roles of</option>
<option>Christ, sacrifice of</option>
<option>Christ, salvation through</option>
<option>Christ, scourging of</option>
<option>Christ, second coming of</option>
<option>Christ, sepulchre of</option>
<option>Christ, similarity to Moses</option>
<option>Christ, soldiers of</option>
<option>Christ, son of God</option>
<option>Christ, special relationship with John</option>
<option>Christ, spirit of</option>
<option>Christ, sufferings of</option>
<option>Christ, sufferings of commemorated</option>
<option>Christ, teachings of</option>
<option>Christ, temptation of</option>
<option>Christ, transfiguration of</option>
<option>Christ, virtues of</option>
<option>Christ, witnessing for</option>
<option>Christ, yoke of</option>
<option>Christ as advocate</option>
<option>Christ as advocate for sinners</option>
<option>Christ as an example</option>
<option>Christ as Judge</option>
<option>Christ as king</option>
<option>Christ as Lord</option>
<option>Christ as mediator</option>
<option>Christ as Messiah</option>
<option>Christ as priest</option>
<option>Christ as prophet</option>
<option>Christ as redeemer</option>
<option>Christ as savior</option>
<option>Christ as teacher</option>
<option>Christ Church, Baltimore, choir instituted</option>
<option>Christ Church, Baltimore, consecration of</option>
<option>Christ Church, Baltimore, financing of</option>
<option>Christ Church, Savannah</option>
<option>Christ compared to Moses</option>
<option>Christ prophesied</option>
<option>Christian anger</option>
<option>Christian armor</option>
<option>Christian character</option>
<option>Christian charity</option>
<option>Christian Church, establishment of</option>
<option>Christian comfort</option>
<option>Christian conduct</option>
<option>Christian conversation</option>
<option>Christian deportment</option>
<option>Christian dispensation</option>
<option>Christian doctrine</option>
<option>Christian duty</option>
<option>Christian education</option>
<option>Christian faith</option>
<option>Christian hope</option>
<option>Christian indifference</option>
<option>Christian life</option>
<option>Christian life, living a</option>
<option>Christian life, obligations of</option>
<option>Christian life, quality of</option>
<option>Christian martyrdom</option>
<option>Christian pleasure</option>
<option>Christian rebirth</option>
<option>Christian religion</option>
<option>Christian unity</option>
<option>Christian unity, benefit of</option>
<option>Christian virtue</option>
<option>Christianity, based on reason</option>
<option>Christianity, benefits of accepting</option>
<option>Christianity, benefits of to the world</option>
<option>Christianity, consolations of</option>
<option>Christianity, conversion to</option>
<option>Christianity, damaged by schism</option>
<option>Christianity, decay of</option>
<option>Christianity, defense of</option>
<option>Christianity, different than Judaism</option>
<option>Christianity, effects of</option>
<option>Christianity, evidences of</option>
<option>Christianity, genuine</option>
<option>Christianity, growth of</option>
<option>Christianity, insincere</option>
<option>Christianity, legal support of</option>
<option>Christianity, objections to</option>
<option>Christianity, obligations of</option>
<option>Christianity, philosophy of</option>
<option>Christianity, progress of</option>
<option>Christianity, proofs of</option>
<option>Christianity, rationalist approach to</option>
<option>Christianity, reasonableness of</option>
<option>Christianity, rejection of</option>
<option>Christianity, spread of</option>
<option>Christianity, success of</option>
<option>Christianity, truth of</option>
<option>Christians, community of</option>
<option>Christians, complacent</option>
<option>Christians, courage of early</option>
<option>Christians, damned</option>
<option>Christians, degeneracy of</option>
<option>Christians, denominational differences</option>
<option>Christians, examples to</option>
<option>Christians, fair-weather</option>
<option>Christians, idle</option>
<option>Christians, lukewarm</option>
<option>Christians, obligations of</option>
<option>Christians, persecution of</option>
<option>Christians, persecution of by Jews</option>
<option>Christians, persecution of early</option>
<option>Christians, privileges of</option>
<option>Christians, sincere</option>
<option>Christians, temptations of early</option>
<option>Christians, treatment of early</option>
<option>Christmas</option>
<option>Christmas, sermon for</option>
<option>Church, constitution and order of</option>
<option>Church, doctrine of</option>
<option>Church, duty to support</option>
<option>Church, Fathers of the</option>
<option>Church, founded by Christ</option>
<option>Church, history of ancient</option>
<option>Church, infallibility of</option>
<option>Church, proper behavior in</option>
<option>Church, role of</option>
<option>Church, support of the</option>
<option>Church, true</option>
<option>Church, unity of</option>
<option>Church, visible</option>
<option>church and state, relationship of</option>
<option>church and state, separation of</option>
<option>church as bride</option>
<option>Church as one body</option>
<option>church as wife</option>
<option>church attendance, poor</option>
<option>church attendance for social reasons</option>
<option>Church Fathers</option>
<option>Church of Christ</option>
<option>Church of England</option>
<option>Church of England, loyalty to non-conformists</option>
<option>Churches, erection and preservation of</option>
<option>Cicero</option>
<option>circumcision</option>
<option>City on a hill</option>
<option>Claggett, Bishop Thomas John</option>
<option>Claggett, Bishop Thomas John, duty to support</option>
<option>Claggett, Bishop Thomas John, parish support of</option>
<option>Clark, Sarah</option>
<option>Clay, Mary Sen.</option>
<option>Clement XIII</option>
<option>clergy, as examples</option>
<option>clergy, compensation of</option>
<option>clergy, corruption of</option>
<option>clergy, duties of</option>
<option>clergy, financial support of</option>
<option>clergy, giving good example</option>
<option>clergy, orders of</option>
<option>clergy, respect for</option>
<option>clergy of St. Paul</option>
<option>clerical orders, role of</option>
<option>Clerk, Ann</option>
<option>Clifton, Jacobus</option>
<option>Cobbett, William</option>
<option>Colegate, Mrs., funeral of</option>
<option>Colegate, Thomas, funeral of</option>
<option>Coleman, John</option>
<option>Colombiere, Rev. Claude de la</option>
<option>comfort, Christian</option>
<option>comfort, divine</option>
<option>commandment, first</option>
<option>commandment, great</option>
<option>commandments</option>
<option>commandments, duty to obey</option>
<option>commandments, keeping</option>
<option>commandments, respect for</option>
<option>commerce, foolish dependence on</option>
<option>commitment</option>
<option>commitment to Christ</option>
<option>communicants, worthy</option>
<option>communion</option>
<option>Communion, benefits of</option>
<option>Communion, fear of taking</option>
<option>communion, frequent</option>
<option>Communion, Holy</option>
<option>Communion, importance of</option>
<option>Communion, preparation for</option>
<option>Communion, sacrament of</option>
<option>communion, unworthy</option>
<option>Communion office, excellency of</option>
<option>communion office of the Church</option>
<option>communion with God</option>
<option>community, benefits of</option>
<option>community service</option>
<option>companions, influence of</option>
<option>company, bad</option>
<option>comparison of man with God</option>
<option>comparison of man with God's other creatures</option>
<option>compassion</option>
<option>compassion of Christ</option>
<option>Conception, Immaculate</option>
<option>concerts, evil of sabbath</option>
<option>concord, consequences of</option>
<option>concord, duty of community to maintain</option>
<option>concord, lack of</option>
<option>concord, necessity of</option>
<option>conduct, Christian</option>
<option>conduct, good</option>
<option>conduct, man's</option>
<option>confession</option>
<option>confession, general</option>
<option>confession, method of</option>
<option>confirmation</option>
<option>confirmation, rite of</option>
<option>conflagration, final</option>
<option>Confucianism</option>
<option>congregation, duties of</option>
<option>congregational duty to communion office</option>
<option>conscience</option>
<option>conscience, authority of</option>
<option>conscience, condemnation of</option>
<option>conscience, good</option>
<option>conscience, illumination of good</option>
<option>conscience, on</option>
<option>conscience, powers of</option>
<option>Consecration of the Elements</option>
<option>consolation</option>
<option>consolation, sources of</option>
<option>consolation of religious music</option>
<option>Constantine, conquest of paganism</option>
<option>contentment</option>
<option>contentment, a sign of virtue</option>
<option>Continental Army</option>
<option>Continental Congress</option>
<option>conversation, Christian</option>
<option>conversation, good</option>
<option>conversation, heavenly</option>
<option>conversion</option>
<option>conversion, sincere</option>
<option>conversion, speedy</option>
<option>Cook, Isabel</option>
<option>Cooper, Mrs., and child, funeral of</option>
<option>Corinth</option>
<option>Corinthians</option>
<option>Cornelius</option>
<option>Cornelius, character of</option>
<option>Cornwallis, surrender of</option>
<option>Corporation for the Relief of Widows and Children</option>
<option>Corpus Christi</option>
<option>Corpus Christi, Feast of</option>
<option>corruption of the soul</option>
<option>Cosden, Jeremiah, ordination of</option>
<option>country, duty to</option>
<option>Covenant, Christian</option>
<option>Covenant, New</option>
<option>covenant of grace</option>
<option>covenant of works</option>
<option>covetousness</option>
<option>Cox, Mary</option>
<option>Crasset, Rev. Jean</option>
<option>Craxall, Mrs., funeral of</option>
<option>Creation</option>
<option>Creed, 10th article</option>
<option>Creed, 11th article</option>
<option>Creed, 12th article</option>
<option>Creed, 1st article</option>
<option>Creed, 3rd article of</option>
<option>Creed, 5th article of</option>
<option>Creed, 6th article</option>
<option>Creed, 8th article</option>
<option>Creed, Apostles</option>
<option>Cromwell, Mrs., funeral of</option>
<option>Cromwell, Oliver</option>
<option>Cross, creeping to the</option>
<option>Cross, sign of the</option>
<option>crucifixion</option>
<option>crucifixion, caused by sin</option>
<option>crucifixion, fulfillment of prophecy</option>
<option>crucifixion of Christ</option>
<option>Curtain, James, funeral of</option>
<option>Cyprian</option>
<option>Cyrus</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
