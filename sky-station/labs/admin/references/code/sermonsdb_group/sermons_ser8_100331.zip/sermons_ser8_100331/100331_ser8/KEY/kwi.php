<html>
<head>
<title>kwi</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwi";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- I</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>idleness</option>
<option>idleness, avoidance of</option>
<option>idleness, bane of virtue</option>
<option>idleness, evils of</option>
<option>idolatry</option>
<option>ignorance</option>
<option>ignorance, religious</option>
<option>ignorance, state of</option>
<option>ill health, the result of imprudence</option>
<option>imitation of Christ</option>
<option>immorality</option>
<option>immorality of Maryland clergy</option>
<option>immortality</option>
<option>immortality, belief in</option>
<option>immortality, doctrine of</option>
<option>impatience</option>
<option>impenitence</option>
<option>impermanence</option>
<option>imprudence, ill health the result of</option>
<option>Incarnation</option>
<option>Incarnation of Christ</option>
<option>Independence, American</option>
<option>Indian, American, religions of</option>
<option>Indian attacks</option>
<option>Indian massacres</option>
<option>Indian War, Georgia</option>
<option>Indian Wars</option>
<option>Indians, American, conversion of</option>
<option>Indians, barbarity of</option>
<option>Indians, conversion of</option>
<option>Indians, nature of</option>
<option>indifference, Christian</option>
<option>indolence</option>
<option>industry</option>
<option>industry, early instruction</option>
<option>infant baptism</option>
<option>infant damnation</option>
<option>infidelity</option>
<option>infidels</option>
<option>infidels, conversion of</option>
<option>infidels, refuting of</option>
<option>infirmity, sins of</option>
<option>influence of Christ</option>
<option>influence of the world</option>
<option>ingratitude</option>
<option>ingratitude of mankind</option>
<option>iniquities defined</option>
<option>iniquity</option>
<option>iniquity, departing from</option>
<option>injuries from others, receiving</option>
<option>injustice</option>
<option>innocence</option>
<option>innocent pleasure</option>
<option>insane asylum</option>
<option>inspiration, divine</option>
<option>instruction, religious</option>
<option>integrity</option>
<option>intellect, fallibility of</option>
<option>intellect, inferiority to morality</option>
<option>intemperance</option>
<option>intemperance in prayer</option>
<option>intemperant Christians, changeability of</option>
<option>Iredell</option>
<option>Isaac</option>
<option>Isaiah</option>
<option>Isaiah, prophecies of</option>
<option>Israel, deliverance from Egypt</option>
<option>Israel, famine in</option>
<option>Israel, God's kindmess to</option>
<option>Israel, God's kindness to</option>
<option>Israelites, emancipation of</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
