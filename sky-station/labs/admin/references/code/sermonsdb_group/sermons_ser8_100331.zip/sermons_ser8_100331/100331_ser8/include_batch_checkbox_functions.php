<?php
#include "./ser-header_frames.php";
#include "./ser-header_links.php";
$doublequote='"';

// ----------------------------- Begin HTML output ---------
$doublequote = '"';
$spacer= 
" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
////////////print "<html><head><title>view all</title>\n";
?>

<link rel="stylesheet" type="text/css" href="ser.css" />
<script language="javascript">

//==========batch checkbox functions=======================================

//batch select and print use the batch_print_list field instead of serid_list


//search_only has multiple document.forms, other pages have one document.form
//pass the name of the form (f) so all pages use same functions
//use: set_chbx_search sets initial values of checkboxes for:
//	 view_author_title_index
//	 view_search_index
//	 view_search_only
//	 view_cart_index

//when an index page is loaded, this function occurs automatically
function set_chbx_search(f,p) {
//f is $this_form_name, p is $pid
var F = new String(f);
//alert ("set_chbx_search:\n F="+F+"\nSPID="+p);
var SPID = new String(p);
var PID  = new String(p);
    SPID = ","+SPID+",";
var cart_list = new String (document.formW.batch_print_list.value);
    cart_list = cart_list+",";


  if (cart_list.indexOf(SPID)>-1) {
	eval("document."+F+".chbx"+PID+".checked=true");
  }else{
	eval("document."+F+".chbx"+PID+".checked=false");
  }



//former function save_pid_list(p) for check_all and uncheck_all
//when an index page is loaded, this function occurs automatically
//hard code document.pageformA for index pages 
//use eval on passed form name for view_search_only.php

//identify list of pid's on this page
//save as: this_page_pid_list

if (location.href.indexOf("only") < 0 ) {
document.pageformA.this_page_pid_list.value=document.pageformA.this_page_pid_list.value+","+PID;
document.formW.this_page_pid_list.value=document.pageformA.this_page_pid_list.value;
//alert("document.pageformA.this_page_pid_list.value="+document.pageformA.this_page_pid_list.value);
}else{
eval("document."+F+".this_page_pid_list.value=document."+F+".this_page_pid_list.value"+","+"PID");
eval("document.formW.this_page_pid_list.value=document."+F+".this_page_pid_list.value");
}


//alert("end function set_chbx_search");

}//end function set_chbx_search



//search_only has multiple document.forms, other pages have one document.form
//pass the name of the form (f) so all pages use same functions
//use: reset_chbx_search sets change values of checkboxes for:
//	 view_author_title_index
//	 view_search_index
//	 view_search_only
//	 view_cart_index

function reset_chbx_search(f,s,p,a) {
//f is $this_form_name, s is this, p is $pid, a is $acc
//checkbox.name is chbx$pid
//s is this
//p is $pid
//a is $acc

var F = new String(f);
var SPID = new String(p);
var ACC  = new String(a);

//alert("s.checked="+s.checked);

//alert ("reset_chbx:\n this_form_name="+F+"\nSPID="+SPID+"\ns.checked="+s.checked);
if (s.checked == false) {
        //s.checked=false;-- doremove
        doremove_search(F,SPID,ACC)
}else{
        //s.checked=true;-- dosave
        dosave_search(F,SPID,ACC);
}

}//end function reset_chbx_search



//search_only has multiple document.forms, other pages have one document.form
//pass the name of the form (f) so all pages use same functions
//use: doremove_search is called by reset_chbx_search

function doremove_search(f,p,a){
//f is $this_form_name
//p is $pid
//a is $acc
var F = new String(f);
var acc = new String(a);
var SPID = new String(p);
//alert("dosave_search\nACC="+acc+"\nF="+F+"\nSPID="+SPID);
var RPID = new String(SPID);
    RPID =","+RPID+",";
var cart_list = new String (document.formW.batch_print_list.value);
    cart_list = cart_list+",";
//alert ("doremove\nRPID="+RPID+"\ncart_list="+cart_list);
    cart_list = cart_list.replace(RPID,",");
    var LEN = cart_list.lastIndexOf(",");
    cart_list=cart_list.substring(0,LEN);
    cart_list = cart_list.replace(",,",",");

	
	eval("document."+F+".batch_print_list.value=cart_list");
    	document.formW.batch_print_list.value=cart_list;
}//end function doremove_search(s)



//search_only has multiple document.forms, other pages have one document.form
//pass the name of the form (f) so all pages use same functions
//use: dosave_search is called by reset_chbx_search

function dosave_search(f,p,a){
//f is $this_form_name
//p is $pid
//a is $acc

var ACC = new String(a);
var F =  new String(f);
var SPID = new String(p);

//alert("dosave_search\nACC="+ACC+"\nF="+F+"\nSPID="+SPID);

var cart_list = new String (document.formW.batch_print_list.value);
    cart_list = ","+cart_list+",";
    cart_list = cart_list.replace(",,",",");
var checkPID = ","+SPID+",";
//alert ("cart_list="+cart_list+"\ncheckPID="+checkPID);

	eval("document."+F+".batch_print_list.value+=','+SPID;");
        document.formW.batch_print_list.value += ","+SPID;

}//end function dosave_search(s)



///saves all checkboxes on the current page to the cart
///only available for index pages!!!
///the list of this_page_pid_list made by function set_chbx_search (save_pid_list)

function check_all(this_page){

//alert("check_all("+this_page+")");

var tppl = document.pageformA.this_page_pid_list.value;

var TPPL = new String(tppl);
var TPPA = new Array();
    TPPA = TPPL.split(",");

var WPL = new String (document.formW.batch_print_list.value);
var WPA = new Array();
    WPA = WPL.split(",");
var WPB = new String(WPL);//output

var msg = "TPPL="+TPPL+"\n\n";
for (i=0;i<TPPA.length;i++) {
      msg +="\nTPPA["+i+"]="+TPPA[i];
      }

var msgW = "\n\nWPL="+WPL;

for (i=0;i<WPA.length;i++) {
      msgW +="\nWPA["+i+"]="+WPA[i];
      }

//index start at i=1, never compare or add 0 init value
var set_save=0;

for (j=0;j<TPPA.length;j++) {
set_save=0;//you are looking for a match
	for (i=0;i<WPA.length;i++) {
		if (TPPA[j]==WPA[i]) {
			set_save=1;//you found the match
			break;
			}
	}
if (set_save==0) {
	WPB += ","+TPPA[j];
	}
}

//alert("check_all:\n"+msg+msgW+"\n\nWPB="+WPB);

	document.pageformA.batch_print_list.value = WPB;
        document.formW.batch_print_list.value = WPB;

//alert ("check_all:\ndocument.pageformA.submit()\nlocation.href="+location.href)
//document.pageformA.submit();


	//soft check
	//TPPA is the array of this_page_pid_list
	//make them all be checked, but do not submit the page
	for (i=1;i<TPPA.length;i++) {
		eval("document.pageformA.chbx"+TPPA[i]+".checked=true");
		}


}// end function check_all


///unchecks all checkboxes on the current page to the cart
///only available for index pages!!!
///the list of this_page_pid_list made by function set_chbx_search (save_pid_list)

function uncheck_all ( this_page) {

var tppl = document.pageformA.this_page_pid_list.value;

var TPPL = new String(tppl);
var TPPA = new Array();
    TPPA = TPPL.split(",");

var WPL = new String (document.formW.batch_print_list.value);
var WPA = new Array();
    WPA = WPL.split(",");
var WPB = new String("0");//output

var msg = "TPPL="+TPPL+"\n\n";
for (i=0;i<TPPA.length;i++) {
      msg +="\nTPPA["+i+"]="+TPPA[i];
      }

var msgW = "\n\nWPL="+WPL;

for (i=0;i<WPA.length;i++) {
      msgW +="\nWPA["+i+"]="+WPA[i];
      }


//index start at 1, never compare or remove 0 init value
var set_remove=0;

for(i=1;i<WPA.length;i++) {
set_remove=0;//default is do not remove, unless  you find a match
   for (j=0;j<TPPA.length;j++) {
        if (TPPA[j]==WPA[i]){
                set_remove=1;//you found a match
                }
        }//end for j
if(set_remove==0) { WPB += ","+WPA[i]; }
}//end for i

//alert(msg+msgW+"\n\nWPB="+WPB);

	document.pageformA.batch_print_list.value=WPB;
        document.formW.batch_print_list.value = WPB;

//alert ("uncheck_all:\ndocument.pageformA.submit()\nlocation.href="+location.href)

	//soft remove
	//TPPA is the array of this_page_pid_list
	//make them all be unchecked, but do not submit form
	for (i=1;i<TPPA.length;i++) {
		eval("document.pageformA.chbx"+TPPA[i]+".checked=false");
		}

}// end function uncheck_all



//==========end batch checkbox functions===================================

</script>

