<html>
<head>
<title>loc</title>
<script language="javascript">
//from  ser-header_vsearch.php 

function my_select() {
//alert("select_loc");
var sText = new String();

for ( i=0; i< document.loc_form.slibloc_code_select.length; i++ ) {
	if (document.loc_form.slibloc_code_select[i].selected == true ) {
		//alert(document.loc_form.slibloc_code_select[i].text);
		sText = document.loc_form.slibloc_code_select[i].value;
		//tText = document.loc_form.slibloc_code_select[i].text;
		break;
		}//end if
	}//end for
//document.search_form.slibloc_code.value = sText;
//parent.document.search_form.sloc.value = "";///// tText;
parent.document.search_form.slibloc_code.value = sText;
parent.document.search_form.smarkov_key.value= "loc";

}//end function select_loc
</script>



<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>

<body><div class="form2"><!--########loc_form start-->
<form name="loc_form">
[Location Code]......Location (Repository)<br />

<?php
include "size_set_CILN.php";
print "<select name=\"slibloc_code_select\" size=\"$menu_size\" onchange=\"my_select()\">";
?>

<option  value="" selected>none selected</option>
<option  value="Bodleian">[Bodleian]...Bodleian Library, Univ. of Oxford, Oxford,</option>
<option  value="Bodleian">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Great Britain</option>
<option  value="CSmH">[CSmH]......Henry H. Huntington Library, San Marino, CA</option>
<option  value="DGU">[DGU]........Georgetown University, Washington, DC </option>
<option  value="DLC">[DLC].........Library of Congress, Washington, DC </option>
<option  value="GU">[GU]...........University of Georgia, Athens, GA </option>
<option  value="MdDA">[MdDA].......F. Garner Ranney Archives, Episcopal Diocese</option>
<option  value="MdDA">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;of Maryland, Baltimore, Maryland</option>
<option  value="MdHi">[MdHi]........Maryland Historical Society, Baltimore, MD</option>
<option  value="MdWC">[MdWC].....Washington College, Chestertown, MD </option>
<option  value="MH-H">[MH-H].......Houghton Library, Harvard University,</option>
<option  value="MH-H">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cambridge, MA </option>
<option  value="MHi">[MHi]..........Massachusetts Historical Society, Boston, MA </option>
<option  value="MNtcA">[MNtcA]......Andover Newton Theolog. School Libr.,</option>
<option  value="MNtcA">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Newton Centre, MA </option>
<option  value="MWA">[MWA]........American Antiquarian Society, Worcester, MA </option>
<option  value="Nc">[Nc]............Dept. of Archives and History, NC State Libr.,</option>
<option  value="Nc">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Raleigh, NC</option>
<option  value="NcD">[NcD]..........Duke University, Durham, NC</option>
<option  value="NcU">[NcU]..........University of N. Carolina at Chapel Hill,</option>
<option  value="NcU">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chapel Hill, NC</option>
<option  value="NjP">[NjP]..........Princeton University, Princeton, NJ</option>
<option  value="NjR">[NjR]..........Rutgers, The State University of New Jersey,</option>
<option  value="NjR">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;New Brunswick, NJ</option>
<option  value="NoCode">[NoCode].....Stored in a Repository with No Library Code</option>
<option  value="ScHi">[ScHi].........South Carolina Historical Society, Charleston, SC</option>
<option  value="ScU">[ScU]..........University of South Carolina, Columbia, SC</option>
<option  value="Vi">[Vi].............Virginia State Library, Richmond, VA</option>
<option  value="ViHi">[ViHi]..........Virginia Historical Society, Richmond, VA</option>
<option  value="ViRU">[ViRU].........Virginia Baptist Historical Society</option>
<option  value="ViRU">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;University of Richmond, Richmond, VA</option>
<option  value="ViRUT">[ViRUT]........Union Theological Seminary, Richmond, VA </option>
<option  value="ViU">[ViU]............University of Virginia, Charlottesville, VA</option>
<option  value="ViWC">[ViWC].........Colonial Williamsburg, Inc., Williamsburg, VA</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select><br />
</form>
</div>

</body>
</html>
