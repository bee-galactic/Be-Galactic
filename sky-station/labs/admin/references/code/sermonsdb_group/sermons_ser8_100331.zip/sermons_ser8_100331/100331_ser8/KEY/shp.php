<html>
<head>
<title>shp</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shp";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- P</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Pain of loss, On ye</option>
<option>Palm Sunday, On</option>
<option>Parable of Lazarus, On the</option>
<option>Parable of the Housholder, The</option>
<option>Parable of the lost Sheep & piece of Silver, The</option>
<option>Parable of the prodigal son, On the</option>
<option>Parable of the rich man and Lazarus, The</option>
<option>Parable of the Sower, The</option>
<option>Parable of the Steward, On</option>
<option>Parable of the two sons, The</option>
<option>Parable of the Unjust Steward, The</option>
<option>Parable of the Vineyard let to husbandmen, The</option>
<option>Pardoning Mercy</option>
<option>Pardoning one's enemies, On</option>
<option>Pardoning our Enemies, On</option>
<option>Parents and Children, On</option>
<option>Passion, On the</option>
<option>Passion and Resurrection, On the</option>
<option>Passion of Christ, On the</option>
<option>Passion of Xt, On the</option>
<option>Passion Sermon</option>
<option>Pastoral duties, On</option>
<option>Path of the just is as the shining Light, The</option>
<option>Patience, Of</option>
<option>Patience, On</option>
<option>Patience of God, On the</option>
<option>Patient forbearance of God, On the</option>
<option>Patriotism, On</option>
<option>Payment of tribute to Caesar, The</option>
<option>Peace, Of</option>
<option>Peace, On</option>
<option>Peace and Tribulation</option>
<option>Peace dispensed by Xt to his disciples, The</option>
<option>Peace from Loving God's Law, On</option>
<option>Peace I leave with you</option>
<option>Peace of Jesus Christ, On the</option>
<option>Peace to the Wicked, On No</option>
<option>Penance</option>
<option>Penance, On</option>
<option>Pentecost</option>
<option>Pentecost, On</option>
<option>Pentecost Day, On</option>
<option>Perfection required, On the</option>
<option>Perseverance, Of</option>
<option>Perseverance in Faith & Hope</option>
<option>Persuasive to charity</option>
<option>Peter's Denial of his Lord</option>
<option>Petition of the Mother of Zebedee's Children, From the</option>
<option>Pharisee & the Publican, The</option>
<option>Phillipians 2d Ch & 8 vs</option>
<option>Pleasantness of religion, The</option>
<option>Pleasing Man and God, 2, On</option>
<option>Pleasing Men and God, On</option>
<option>Poor, On the</option>
<option>Power of bad habits, The</option>
<option>Power of the Gospel, The</option>
<option>Praise, On</option>
<option>Prayer, On</option>
<option>Prayer and Justification, On</option>
<option>Preach the Word</option>
<option>Preparation for Death, On</option>
<option>Preparation for judgment, On</option>
<option>Presence of God, On the</option>
<option>Presumptuous Sins, On</option>
<option>Pride, On</option>
<option>Prodigal Son, On the</option>
<option>Profanity, On</option>
<option>Promise of a prophet like unto Moses, The</option>
<option>Promise of God, On the</option>
<option>Promises of God, On the</option>
<option>Proper Distribution of the Elements ... of the Lord's Supper</option>
<option>Prophecy concerning Shiloh, The</option>
<option>Prophecy of the Destruction of Jerusalem, The</option>
<option>Prophetic Character of Christ, On the</option>
<option>Propriety of a reverent ... deportment in ye house of God</option>
<option>Protestant and Catholic churches, On the</option>
<option>Proverbs 30: 8-9, On</option>
<option>Proverbs 3:7, On</option>
<option>Proving and Holding to Truth, On</option>
<option>Psalm 100: 2, On</option>
<option>Psalm 119, On</option>
<option>Psalm 119: 165, On</option>
<option>Psalm 119: 97, On</option>
<option>Psalm 144:3, On</option>
<option>Psalmody, On</option>
<option>Public Fast-day to a Minute-company at Charlottesville, On</option>
<option>Public Worship</option>
<option>Punishment of Disobedience, The</option>
<option>Pure and Undefiled Religion</option>
<option>Purgatory</option>
<option>Purgatory, On</option>
<option>Purification, On the</option>
<option>Purification, On ye</option>
<option>Purifying One's Soul, On</option>
<option>Putting on the Lord Jesus Christ</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
