<html>
<head>
<title>shuv</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shuv";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- U-V</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Uncertainty of existence, On the</option>
<option>Uncertainty of life, & suddenness of death, The</option>
<option>Unclean thoughts, On</option>
<option>Unfit for Heaven</option>
<option>Unity</option>
<option>Unity of God, The</option>
<option>Universal Love & Charity</option>
<option>Unsearchable Wisdom of God, in his dealings with men, On the</option>
<option>Unstable as Water thou shalt not excell</option>
<option>Untitled Ms. Sermons 1686 and 1707</option>
<option>Unworthy communion, On</option>
<option>Upright poor man & the perverse rich one</option>
<option>Use and abuse of the World, The</option>
<option>Use of time, On the</option>
<option>Vanity, On</option>
<option>Vanity of human Life</option>
<option>Venial Sin, Of</option>
<option>Venial sin, On</option>
<option>Veracity of God, On the</option>
<option>Vice of Ingratitude, On the</option>
<option>Vine and Its Branches, On the</option>
<option>Virgin Mary, On the</option>
<option>Visionary schemes of happiness, On</option>
<option>Visitation-sermon</option>
<option>Visitation of the third District, For the</option>
<option>Vocation to Sanctity, On our</option>


<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
