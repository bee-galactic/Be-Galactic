<html>
<head>
<title>na_loc_cet</title>
<script language="javascript">
//from  ser-header_vsearch.php 


function my_ida_select() {
var sText = new String("");
var date_ct = 0;

for ( i=1; i< document.ida_form.ida_select.length; i++ ) {
	if (document.ida_form.ida_select[i].selected == true ) {
		date_ct++;
		if (sText.length > 1) sText += " OR ";
		sText += document.ida_form.ida_select[i].value;
		if(date_ct==5)break;
		}//end if
	}//end for
//alert("sText = "+sText);
parent.document.search_form.sida.value = sText;
parent.document.search_form.smarkov_key.value= "ida";
//clear listbox
document.ida_form.ida_select[0].selected=true;
for ( i=1; i< document.ida_form.ida_select.length; i++ ) {
        document.ida_form.ida_select[i].selected = false;
	}
}//end function my_ida_select 


function pop_clear(){
	document.ida_form.ida_select[0].selected=true;
	parent.document.search_form.sida.value="";
	}

</script>

<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body></div class="form2">
<form name="ida_form" >
<p />
<table border="0" cellpadding="2" cellspacing="0">
<tr><td valign="top" >
<div class="form2">
Search by Index Date.<p/>
Select up to 5 items from the list, then click the Enter Index Date button.
<p>
To Select multiple items, press down on the CTRL key and click on each item.
<p>
&nbsp;<a href="http://dlc.lib.utk.edu/~cdeane/sermonsdb/ser8/date_search_explain.htm" target="_blank">More about Date Search.</a>
<p>
<input type="button" name="enter_indexdate" value="Enter Index Date(s)"
class="bluebutton160" onclick="my_ida_select()"><br />
<input type="button" name="clear_date" value="Clear Date(s)"
class="bluebutton160" onclick="pop_clear()">
</td><td valign="top">
<?php
include "size_set_IDA.php";
print "<select name=\"ida_select\" size=\"$menu_size\" multiple >";
?>
<option value="" selected>none selected</option>
<option value="1686">1686</option>
<option value="1686-1707">1686-1707</option>
<option value="1689">1689</option>
<option value="1692-1723">1692-1723</option>
<option value="1700-1799">1700-1799</option>
<option value="1700?-1799?">1700?-1799?</option>
<option value="1704">1704</option>
<option value="1705-1752">1705-1752</option>
<option value="1707">1707</option>
<option value="1710-1713">1710-1713</option>
<option value="1710-1714">1710-1714</option>
<option value="1712-1734">1712-1734</option>
<option value="1713-1761">1713-1761</option>
<option value="1715">1715</option>
<option value="1715-1716">1715-1716</option>
<option value="1716">1716</option>
<!-- option value="1718-1770">1718-1770</option 100316 -->
<option value="1722-1753">1722-1753</option>
<option value="1723">1723</option>
<option value="1725">1725</option>
<option value="1726">1726</option>
<option value="1728">1728</option>
<option value="1729">1729</option>
<option value="1730">1730</option>
<option value="1730-1749">1730-1749</option>
<option value="1732">1732</option>
<option value="1734">1734</option>
<option value="1734-1767">1734-1767</option>
<option value="1736-1803">1736-1803</option>
<option value="1738">1738</option>
<option value="1738-1749">1738-1749</option>
<option value="1739-1777?">1739-1777?</option>
<option value="1740-1748">1740-1748</option>
<option value="1740-1761">1740-1761</option>
<option value="1742-1746">1742-1746</option>
<option value="1742-1767">1742-1767</option>
<option value="1742-1787">1742-1787</option>
<option value="1742-1789">1742-1789</option>
<option value="1743">1743</option>
<option value="1743-1770">1743-1770</option>
<option value="1744">1744</option>
<option value="1745">1745</option>
<option value="1745-1790">1745-1790</option>
<option value="1746">1746</option>
<option value="1746-1779">1746-1779</option>
<option value="1747">1747</option>
<option value="1748">1748</option>
<option value="1748">1749</option>
<option value="1749-1756">1749-1756</option>
<option value="1749-1772">1749-1772</option>
<!-- option value="1749?">1749?</option -->
<option value="1750">1750</option>
<option value="1750-1788">1750-1788</option>
<option value="1751">1751</option>
<option value="1752">1752</option>
<option value="1752-1785">1752-1785</option>
<option value="1753">1753</option>
<option value="1753-1784">1753-1784</option>
<option value="1754">1754</option>
<!-- option value="1754(?)">1754(?)</option -->
<option value="1754-1765">1754-1765</option>
<option value="1755">1755</option>
<!-- option value="1755?">1755?</option -->
<option value="1756">1756</option>
<option value="1757">1757</option>
<option value="1757-1763">1757-1763</option>
<option value="1757-1801">1757-1801</option>
<option value="1758">1758</option>
<option value="1758-1768">1758-1768</option>
<option value="1759">1759</option>
<option value="1759-1760">1759-1760</option>
<option value="1760">1760</option>
<option value="1760-1777">1760-1777</option>
<option value="1760-1804">1760-1804</option>
<option value="1763">1763</option>
<option value="1763-1773">1763-1773</option>
<option value="1763-1774">1763-1774</option>
<option value="1763-1793">1763-1793</option>
<option value="1764">1764</option>
<option value="1765">1765</option>
<option value="1765-1770, 1784-1795">1765-1770, 1784-1795</option>
<option value="1766">1766</option>
<!-- option value="1766-1772">1766-1772</option -->
<option value="1766-1786">1766-1786</option>
<option value="1766-1790">1766-1790</option>
<option value="1766-1791">1766-1791</option>
<option value="1766-1803">1766-1803</option>
<option value="1767">1767</option>
<option value="1768">1768</option>
<option value="1769">1769</option>
<option value="1769-1770">1769-1770</option>
<option value="1769-1783">1769-1783</option>
<option value="1769-1793">1769-1793</option>
<option value="1769-1808">1769-1808</option>
<option value="1769-1809">1769-1809</option>
<option value="1769-1820">1769-1820</option>
<option value="1769-1820">1769-1820</option>
<option value="1769">1769</option>
<option value="1770">1770</option>
<option value="1770-1775">1770-1775</option>
<option value="1770-1780?">1770-1780?</option>
<option value="1770">1770</option>
<option value="1771">1771</option>
<option value="1771-1811">1771-1811</option>
<option value="1772">1772</option>
<option value="1773">1773</option>
<option value="1773-1818">1773-1818</option>
<option value="1773">1773</option>
<option value="1774">1774</option>
<option value="1774-1775">1774-1775</option>
<option value="1774-1794">1774-1794</option>
<option value="1774-1800">1774-1800</option>
<option value="1774-1806">1774-1806</option>
<option value="1774-1811">1774-1811</option>
<option value="1774-1815">1774-1815</option>
<option value="1774-1840">1774-1840</option>
<option value="1775">1775</option>
<option value="1775-1807">1775-1807</option>
<!-- option value="1775?">1775?</option -->
<option value="1776">1776</option>
<option value="1776-1783">1776-1783</option>
<option value="1777">1777</option>
<!-- option value="1777">1777</option -->
<option value="1778">1778</option>
<!-- option value="1778?">1778?</option -->
<option value="1779">1779</option>
<option value="1780">1780</option>
<!-- option value="1780?">1780?</option -->
<option value="1781">1781</option>
<option value="1782">1782</option>
<option value="1783">1783</option>
<option value="1783-1817">1783-1817</option>
<option value="1784">1784</option>
<option value="1784-1813">1784-1813</option>
<option value="1784-1823">1784-1823</option>
<option value="1784">1784</option>
<option value="1785">1785</option>
<option value="1785-1800">1785-1800</option>
<option value="1786">1786</option>
<option value="1786-1789">1786-1789</option>
<option value="1786-1837">1786-1837</option>
<!-- option value="1786?">1786?</option -->
<option value="1787">1787</option>
<option value="1787-1816">1787-1816</option>
<!-- option value="1787?">1787?</option -->
<option value="1788">1788</option>
<option value="1789">1789</option>
<!-- option value="1789?">1789?</option -->
<option value="178[6]">178[6]</option>
<option value="1790">1790</option>
<option value="1790-1815">1790-1815</option>
<!-- option value="1790?">1790?</option -->
<option value="1791">1791</option>
<option value="1791-1815">1791-1815</option>
<option value="1791-1841">1791-1841</option>
<option value="1791-1841?">1791-1841?</option>
<option value="1792">1792</option>
<option value="1792-1793">1792-1793</option>
<option value="1792-1802">1792-1802</option>
<option value="1792-1828">1792-1828</option>
<option value="1793">1793</option>
<option value="1794">1794</option>
<option value="1794-1815">1794-1815</option>
<option value="1794-c.1815">1794-c.1815</option>
<!-- option value="1794">1794</option -->
<option value="1795">1795</option>
<!-- option value="1795">1795</option -->
<!-- option value="1795?">1795?</option -->
<option value="1796">1796</option>
<option value="1797">1797</option>
<option value="1798">1798</option>
<option value="1798-c.1815">1798-c.1815</option>
<option value="1799">1799</option>
<!-- option value="1799">1799</option -->
<option value="1800">1800</option>
<option value="1801">1801</option>
<option value="1802">1802</option>
<option value="1803">1803</option>
<option value="1805">1805</option>
<option value="1807-1822">1807-1822</option>
<option value="Undated.">Undated.</option>
</select></td></tr></table></form></body></html>
