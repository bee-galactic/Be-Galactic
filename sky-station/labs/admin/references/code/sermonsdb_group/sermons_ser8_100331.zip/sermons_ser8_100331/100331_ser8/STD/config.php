<?php
/*
  make constants

*/
// paths
define('LTSPATH','/home/paulc/public_html/lts');
define('LTSWEBPATH','/~paul/lts');
//define('USEREDIT',7);
// the default fallback email to contact
define('SYSEMAIL',"pc37@utk.edu");
?>
