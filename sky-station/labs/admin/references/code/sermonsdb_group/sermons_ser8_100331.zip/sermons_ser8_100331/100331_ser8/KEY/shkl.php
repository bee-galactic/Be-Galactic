<html>
<head>
<title>shkl</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shkl";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- K-L</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Ker, Sermons by Jacob</option>
<option>Keys of Hell and Death, On</option>
<option>Kingdom come, Thy</option>
<option>Kingdom of God shall be taken from you, The</option>
<option>Last Judgment, On the</option>
<option>Last Judgment, On Works Revealed at</option>
<option>Last Judgment, The</option>
<option>Laying-up Treasures in Heaven, On</option>
<option>Lead us not into temptation</option>
<option>Lecture delivered at Marsh creek January 8th. 1794, A</option>
<option>Lecture upon 2 Sam 24 Ch, A</option>
<option>Lent, For</option>
<option>Lent: Fasting</option>
<option>Lent: The Parable of the Sower</option>
<option>Let me die the death of the righteous</option>
<option>Let not the wise man glory in his wisdom</option>
<option>Let us not be weary in well-doing</option>
<option>Let us run with Patience the Race</option>
<option>Let us therefore fear</option>
<option>Let your Requests be made known unto God</option>
<option>Life & immortality bro't to life by Xt</option>
<option>Life and Doctrine of Christ, The</option>
<option>Life everlasting</option>
<option>Light for the Righteous</option>
<option>Lisbon Earthquake, About</option>
<option>Liturgy, On the</option>
<option>Living a good life, Of</option>
<option>Living a Holy Life</option>
<option>Living Fully in Faith</option>
<option>Living Fully in Faith through Christ</option>
<option>Living the Christian Religion</option>
<option>Living unto Him, who died &c &c</option>
<option>Living unto the Lord</option>
<option>Looking unto Jesus</option>
<option>Lord's Day</option>
<option>Lord's Day Morn:</option>
<option>Lord's Prayer, On</option>
<option>Lord's Supper, Of the</option>
<option>Lord's Supper, On the</option>
<option>Lord's Supper (2), On the</option>
<option>Lord -- Man's Shepherd, The</option>
<option>Lord Day Aft:</option>
<option>Loss and gain of the soul</option>
<option>Love, Of</option>
<option>Love, On</option>
<option>Love not the World</option>
<option>Love of Brethren</option>
<option>Love of Christ, On</option>
<option>Love of God, On the</option>
<option>Love of God in redemption, The</option>
<option>Love of God in the salvation of man, The</option>
<option>Love of Jesus, On the</option>
<option>Love of our neighbor, Of ye</option>
<option>Love of the World, On</option>
<option>Loving men more than Christ, On</option>
<option>Loving Not the World, On</option>
<option>Loving of Enemies</option>
<option>Loving one another, Of</option>
<option>Loving our enemies, On</option>
<option>Lukewarm Christians, On</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
