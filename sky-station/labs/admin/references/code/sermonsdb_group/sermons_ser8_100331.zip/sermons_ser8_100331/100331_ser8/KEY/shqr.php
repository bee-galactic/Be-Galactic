<html>
<head>
<title>shqr</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
//if(!confirm("stext="+stext))return;
stext=stext.replace("rest","%rest%");
//if(!confirm("stext="+stext))return;
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shqr";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- Q-R</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Questions of John's Disciples, On the</option>
<option>Rabbi, we know, that thou art a Teacher come from God</option>
<option>Race for Heaven, The</option>
<option>Rash Judgment, On</option>
<option>Read, Robert, see Preade, Robert</option>
<option>Read, Thomas, see Preade, Robert</option>
<option>Reasonableness of Serving God, The</option>
<option>Reasons for rejoicing in the Lord</option>
<option>Reasons for the exercise of divine mercy towards Sinners</option>
<option>Receiving injuries from others, On</option>
<option>Redeeming the time, Of</option>
<option>Reed, George A., see Reed, George A. V</option>
<option>Reforming from Vicious Habits</option>
<option>Regal Character of Christ, On the</option>
<option>Regeneration</option>
<option>Regeneration, On</option>
<option>Regeneration and not returning to heathen habits, On</option>
<option>Regeneration and the Law of God</option>
<option>Rejoicing, On</option>
<option>Rejoicing in hope</option>
<option>Rejoicing in the Lord</option>
<option>Rejoicing in ye Lord</option>
<option>Relapse, On</option>
<option>Religion, Of</option>
<option>Religion the rest of all that labour</option>
<option>Religious Education of Children, The</option>
<option>Religious Instruction, On</option>
<option>Religious Retreats Prayer and Communion with God, On</option>
<option>Remedies for sin, On</option>
<option>Remember now thy Creator</option>
<option>Remember now thy Creator in the Days of thy Youth</option>
<option>Remember Thy Creator</option>
<option>Remission of sin, & the consequence expected</option>
<option>Remission of sins</option>
<option>Remorse, On</option>
<option>Remorse for sin, On</option>
<option>Remorse of Conscience</option>
<option>Renewing your Mind</option>
<option>Renouncing God, On</option>
<option>Renunciation of the world, On</option>
<option>Repent and believe the Gospel</option>
<option>Repentance</option>
<option>Repentance, Of</option>
<option>Repentance, On</option>
<option>Repentance--Fragment</option>
<option>Repentance: Fragment</option>
<option>Repentance (1), On</option>
<option>Repentance (2), On</option>
<option>Repentance and Faith, On</option>
<option>Reputation, On</option>
<option>Resignation</option>
<option>Resignation of the heart to God, On the</option>
<option>Resting in, & waiting for the Lord</option>
<option>Resurrection, On the</option>
<option>Resurrection of Christ, Of the</option>
<option>Resurrection of Lazarus, The</option>
<option>Resurrection of the Body, On the</option>
<option>Resurrection of the body, The</option>
<option>Resurrection of the Dead, On the</option>
<option>Retirement & Meditation, On</option>
<option>Retirement from Worldly affairs</option>
<option>Revelation, On</option>
<option>Revelation not untrue, because man was unworthy of it</option>
<option>Revenge, On</option>
<option>Rich man & Lazarus, The</option>
<option>Rich Man and Lazarus, The</option>
<option>Righteousness, Temperance, and Judgment to come</option>
<option>Rising generation exhorted</option>
<option>Rule of Divine Providence</option>
<option>Rule of Equity, The</option>


<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
