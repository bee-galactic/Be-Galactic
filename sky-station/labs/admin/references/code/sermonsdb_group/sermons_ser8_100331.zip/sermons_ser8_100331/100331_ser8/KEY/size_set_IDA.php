<?php
#size_set_IDA.php
#size set for IDA


$menu_size="20";
$menu_size="14";

?>
