<?php
//require "dblink.php";
//$link2=DBLink('localhost','hitcount','hcuser','vl3f578');
$q1= "SELECT SUM(hits) FROM hitcounts WHERE filename='welcome.php' AND directory='sermons' ";
$r1 = mysql_query($q1, $link2) or die ("Error in   query: $q1. " . mysql_error());
while (list($h) = mysql_fetch_row($r1)) {
  print "<p style=\"font: 9pt sans-serif;\">";
  print "This page has been accessed $h times since Feb. 14, 2011.</p>";
}
?>

