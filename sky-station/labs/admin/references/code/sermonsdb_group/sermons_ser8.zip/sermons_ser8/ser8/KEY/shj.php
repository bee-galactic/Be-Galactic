<html>
<head>
<title>shj</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shj";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- J</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Jail, For the</option>
<option>James 1:22, On</option>
<option>Jesus, Light of the World, On</option>
<option>Jesus Christ our Lord</option>
<option>Jesus put forth his hand</option>
<option>Jesus Xt was sent to bless men, & to reclaim them from sin</option>
<option>Jews, Sin, and the Law, On</option>
<option>Job 29: 11-13, On</option>
<option>Joel & Micah reconciled</option>
<option>Joel 1: 14-15, On</option>
<option>Jonah, The History of</option>
<option>Joshua's Resolution</option>
<option>Journal of my Mission to Virginia, A</option>
<option>Joy, On</option>
<option>Joy in Prosperity</option>
<option>Joy of Keeping Sacred the Lord's Day, The</option>
<option>Joy of the Lord is your strength, The</option>
<option>Jubilee, On the approaching</option>
<option>Jubilee Year</option>
<option>Judging One another</option>
<option>Judgment</option>
<option>Judgment, On</option>
<option>Judgment of the World, The</option>
<option>Just shall live by Faith, The</option>
<option>Justice, On</option>
<option>Justice and Equity</option>
<option>Justice between Master & Servant</option>
<option>Justice of God, On the</option>
<option>Justice twixt Rulers & Citizens</option>
<option>Justification by Christ's blood</option>
<option>Justification through Christ</option>
<option>Justified by faith</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
