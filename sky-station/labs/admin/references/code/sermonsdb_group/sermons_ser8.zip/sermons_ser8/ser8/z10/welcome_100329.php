<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging

welcome.php
database: cricket_ser.ser2_test2 on dlc


*/
?>


<?php

include "include_standard2.php";
include "include_upper.php";
include "include_standard.php";
#print $html_header;
$top = $_GET['top']; #this is the switch for top_htm public vs private
?>


<table summary="" border="00" xbgcolor="a00000" cellspacing="0" cellpadding="2" width="740" xwidth="640">
<tr><td align="left">
<div>
<div class="info">
<div class="infotag">
Introduction to and Instructions for the Sermons Database
</div>
</div>
</div>
</td></tr>
<tr><td>
<table border="01" xbgcolor="aaffaa" class="list" summary="" width="100%" cellpadding="2">
<tr class="value14nou"><td valign="top">
<p>For many years early semonic literature has proven to the key to the understanding of the New England mind through the study of Puritan texts and, by extension and implication of scholarly emphases, the American mind. 
<p>This bibliography is the first guide to the study of the manuscript sermon literature of the southern colonies/states of Maryland, Virginia, North Carolina, South Carolina, and Georgia. No other tool exists. This bibliographic database will help scholars to construct a fuller picture of the regional nature of the Southern mind before 1800 as well as its contribution to a national ethos, ultimately leading to a more balanced appraisal of American intellectual history by providing access to a considerable body of southern sermons to place alongside those of the northern and middle states for critical assessment.
<p>For the complete introductory frontmatter, as well as detailed instructions for usage, please <a href="Frontmatter.pdf" target="_blank">click here</a>. [pdf - 1.4MB]
<p>For Quick Start instructions for usage, please <a href="QUICK_START.pdf" target="_blank">click here</a>. [pdf - 70KB]
<?php

if ($top=='private'){
print '<p>Database last updated:&nbsp;&nbsp;';

$iquery_M = "SELECT DATE_FORMAT(UPDATE_TIME,'%M') FROM information_schema.TABLES WHERE TABLE_NAME LIKE 'ser2_test2' ";
$iquery_D = "SELECT CONVERT(DATE_FORMAT(UPDATE_TIME,'%d'),signed int) FROM information_schema.TABLES WHERE TABLE_NAME LIKE 'ser2_test2' ";
$iquery_Y = "SELECT DATE_FORMAT(UPDATE_TIME,'%Y') FROM information_schema.TABLES WHERE TABLE_NAME LIKE 'ser2_test2' ";
 
$result_M = mysql_query($iquery_M, $link) or die ("Error in query: $iquery. " . mysql_error());
$result_D = mysql_query($iquery_D, $link) or die ("Error in query: $iquery. " . mysql_error());
$result_Y = mysql_query($iquery_Y, $link) or die ("Error in query: $iquery. " . mysql_error());
if (list($updatetime_M) = mysql_fetch_row($result_M)) {
  print "[$updatetime_M ";
}
if (list($updatetime_D) = mysql_fetch_row($result_D)) {
  print "$updatetime_D, ";
}
if (list($updatetime_Y) = mysql_fetch_row($result_Y)) {
  print "$updatetime_Y]";
}

}

?>
<br />
</td></tr></table>
</td></tr></table>
</div>
<?php
#print $footer;

?>

</td></tr></table>
<form name="pageformA">
<input type="hidden" name="serid_list">
</form>

<script language=javascript src="elements.js"></script>
<script>

//document.pageformA.serid_list.value=document.formW.serid_list.value;

//show_elements defined in include_upper.php
show_elements=0;
if (show_elements==1) {
	elements();
}
</script>
<!-- --- >
/home/cdeane/public_html/sermonsdb/ser8/welcome.php
< !-- --->
</body>
</html>
