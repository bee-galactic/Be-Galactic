#chdups.py
#python chdups.py filename.txt


