<html>
<head>
<title>kwjk</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwjk";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- J</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Jack the Giant Killer, tale of</option>
<option>Jacob</option>
<option>Jacob's dream</option>
<option>Jacob, prophecy of Shiloh</option>
<option>Jacob, Richard, funeral of</option>
<option>James</option>
<option>James, son of Zebedee</option>
<option>James II</option>
<option>James II, dethroned</option>
<option>Jeans, Agnes</option>
<option>Jefferson, Jane Randolph</option>
<option>Jefferson, Thomas</option>
<option>Jehoshaphat, piety of King</option>
<option>Jehu</option>
<option>jeremiad</option>
<option>Jeremiah</option>
<option>Jeroboam</option>
<option>Jerusalem</option>
<option>Jerusalem, destruction of</option>
<option>Jerusalem, prophecy of the destruction of</option>
<option>Jesus, childhood of</option>
<option>Jesus, Feast of the Sacred Heart of</option>
<option>Jesus, life and character of</option>
<option>Jesus, Sermon on the Mount</option>
<option>Jesus, transfiguration of</option>
<option>Jewish Church, music in</option>
<option>Jewish synagogue</option>
<option>Jews</option>
<option>Jews, as chosen people</option>
<option>Jews, as persecutors of Christ</option>
<option>Jews, as representatives of mankind</option>
<option>Jews, Babylonian captivity of</option>
<option>Jews, beliefs of</option>
<option>Jews, captivity of</option>
<option>Jews, Christ's love for</option>
<option>Jews, Christians persecuted by</option>
<option>Jews, comfort of</option>
<option>Jews, conversion of</option>
<option>Jews, diaspora of</option>
<option>Jews, disobedience to Christ</option>
<option>Jews, expectations of Messiah</option>
<option>Jews, idolatry of</option>
<option>Jews, natural fierceness of</option>
<option>Jews, rejection of gospel by</option>
<option>Jews, relation to Christ</option>
<option>Jews, religion of</option>
<option>Jews, religious rites of</option>
<option>Jews, religious state of</option>
<option>Jews, Roman subjugation of</option>
<option>Jews, sins of</option>
<option>Jews, the persecutors of Christ</option>
<option>Job</option>
<option>Job, patience of</option>
<option>Job, redemption of</option>
<option>Joel, prophecies of</option>
<option>John, epistle of</option>
<option>John, gospel of</option>
<option>John, son of Zebedee</option>
<option>John, special relationship with Christ</option>
<option>John the Baptist</option>
<option>John the Baptist, as forerunner of Christ</option>
<option>John the Baptist, character of</option>
<option>John the Baptist, death of</option>
<option>John the Baptist, life of</option>
<option>John the Baptist, preaching of</option>
<option>Johnson, Mrs.</option>
<option>Jonathan</option>
<option>Jonathan, David's address to</option>
<option>Jones, Lem</option>
<option>Jones, Mrs., funeral of</option>
<option>Jones, Widow, funeral of</option>
<option>Jordan, Mrs.</option>
<option>Joseph</option>
<option>Joseph, interpretation of dreams by</option>
<option>Joseph, slavery of</option>
<option>Joseph, story of</option>
<option>Joseph, trials of</option>
<option>Joseph and his brethren</option>
<option>joy</option>
<option>joy, attainment of</option>
<option>joy, compatible with piety</option>
<option>joy, justness of</option>
<option>Jubal</option>
<option>Jubilee</option>
<option>Judah, Jacob's blessing of</option>
<option>Judah, John</option>
<option>Judaism, beliefs of</option>
<option>Judaism, defects of</option>
<option>Judas</option>
<option>Judas, character of</option>
<option>Judas, treachery of</option>
<option>judgment</option>
<option>judgment, last</option>
<option>judgment, preparation for</option>
<option>judgment, rash</option>
<option>Judgment Day</option>
<option>Judgment Day, preparation for</option>
<option>judgment of wicked</option>
<option>judgments of God</option>
<option>jugement, le</option>
<option>Julian the Apostate, conquest of paganism</option>
<option>just, the</option>
<option>justice</option>
<option>justice, obligations of</option>
<option>justice of God</option>
<option>justification</option>
<option>justification through Christ</option>
<option>Justin, martyr</option>
<option>justness</option>
<option>juvenile conduct, regulation of</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
