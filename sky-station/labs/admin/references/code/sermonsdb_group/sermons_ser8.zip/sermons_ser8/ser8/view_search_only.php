<?php
/*
  SER Project
	2008-01-18
  search or limit list
	with paging


copied from
edit_search.php   

THIS IS VERSION CONTAINS comment_long display
AND authors_note field (080818)
========================================
view_search_only.php   

comment out long comment, sermon_id, 
remove button for edit
add    checkbox for add_to_cart/remove, label this as Select

This is the client version where the ability to edit has been removed.


*/

##identify database table
$ser2_test2_alias = "ser2_test2";


$serid = $_GET['serid'];
$markov_CSD = $_GET['smarkov_CSD'];#have to do this at top!
/*
$serid_str = $_GET['serid_list'];
if (!$serid_str){
	$serid_str="0";
	}
*/
$display_choice = $_GET['display_choice']; #LINE 15
if (!$display_choice) {#take care of undefined index
        $display_choice=0;
        }

//-- declare functions

//--- end of functions

include "include_standard.php";
#print $html_header;
#print $html_header_closer;
include "./include_checkbox_functions.php";
include "./include_pagelink_SEARCH.php";
include "./include_search_functions.php";
include "./include_upper.php";


print "<table name=\"qtable\" border=\"00\" width=\"740\" cellpadding=\"2\" cellspacing=\"0\" xbgcolor=\"aaffff\"><tr><td>\n";
#print $html_header;
#print $html_header_closer;
#print "<table name=\"infotag_table\" border=\"01\" width=\"740\" cellpadding=\"2\" cellspacing=\"0\" xbgcolor=\"aaaaff\"></tr></td>\n";
print "<div class=\"info\">\n";
print "<div class=\"infotag\">\n";
print " Search Full Entries from the Sermons Database";
print "</div>\n";
print "</div>\n";
print "</td></tr>";
#print "</td></tr></table name=\"qtable\">\n";

/*
include "./include_checkbox_functions.php";
include "./include_pagelink_SEARCH.php";
include "./include_search_functions.php";
*/

$serid_str = $_GET['serid_list'];
#print "\$serid_string=$serid_str<hr>";
if ($serid_str==""){
        $serid_str="0";
        }

//===================================================
// inits for paging
$lim=5;
if ($display_choice==1) $lim=20;
if (!isset($rec)) $rec=0;
if (!isset($dec)) $dec=0;
if (!isset($inc)) $inc=0;

if (!isset($serid)) $serid=0;
if (!isset($top)) $top="public";
if (!isset($serid_list)) $serid_list=0;
if (!isset($smarkov_key)) $smarkov_key="nau";
if (!isset($sacc)) $sacc="0";
if (!isset($snameauthor)) $snameauthor=""; 
if (!isset($cetitle)) $cetitle="";
if (!isset($state)) $state="";
if (!isset($denom)) $denom="";
if (!isset($CSDval)) $CSDval="";
if (!isset($markov_CSD)) $markov_CSD="Cover Entry Title";
if (!isset($stitle)) $stitle="";
if (!isset($sloc)) $sloc="";
if (!isset($slibloc_code)) $slibloc_code="";
if (!isset($sibr)) $sibr="";
if (!isset($sida)) $sida="";
if (!isset($skey)) $skey="";
if (!isset($sht)) $sht="";
if (!isset($scmt)) $scmt="";
if (!isset($sbr)) $sbr="";
if (!isset($nopgs)) $nopgs="";
if (!isset($stest)) $stest="";

$lnk=$PHP_SELF;
$lnk.="?r=1";
if ($display_choice)$lnk.="&display_choice=$display_choice";
if ($serid) $lnk.="&serid=$serid";
if ($top) $lnk.="&top=$top";
if ($serid_list) $lnk.="&serid_list=$serid_list";
if ($smarkov_key) $lnk.="&smarkov_key=$smarkov_key";
if ($sacc) $lnk.="&sacc=$sacc";
if ($snameauthor) $lnk.="&snameauthor=$snameauthor";
if ($cetitle) $lnk.="&cetitle=$cetitle";
if ($state) $lnk.="&state=$state";
if ($denom) $lnk.="&denom=$denom";
if ($CSDval) $lnk.="&CSDval=$CSDval";
if ($markov_CSD) $lnk.="&smarkov_CSD=$markov_CSD";
if ($stitle)  $lnk.="&stitle=$stitle";
if ($sloc)  $lnk.="&sloc=$sloc";
if ($slibloc_code)  $lnk.="&slibloc_code=$slibloc_code";
if ($sibr)  $lnk.="&sibr=$sibr";
if ($sida)  $lnk.="&sida=$sida";
if ($skey)  $lnk.="&skey=$skey";
if ($sht)  $lnk.="&sht=$sht";
if ($scmt)  $lnk.="&scmt=$scmt";
if ($sbr)  $lnk.="&sbr=$sbr";
if ($nopgs)  $lnk.="&nopgs=$nopgs";
if ($stest)  $lnk.="&stest=$stest";

//
// $rec is the current pos in results, the beginning of the list of $lim results
// determine rec to retrieve a new block of results
#################nh is undefined 090828 chd


if ($inc)
  {
	$rec=$rec+$inc;
  if (($nh)&&($rec>=$nh)) $rec=$nh;
	}
if ($dec)
  {
	$rec=$rec-$dec;
  if ($rec <0) $rec=0;
	}

//end php functions
if ($smarkov_key==""){
	$smarkov_key="nau";
	}
?>

<script language="javascript">
var markov_key=new String("nau");

function submit_search_form(N){
var n=N;
document.search_form.display_choice.value=n;
//alert ("submit_search_form N="+n);

document.search_form.submit();
}

</script>


<?php
#print "<div class=\"form\" name=\"enclose_search_form\">\n";
#########################################SEARCH FORM################################################################

print "<form method=\"get\" action=\"./view_search_only.php\" name=\"search_form\">\n";
#print '<table xbgcolor="ffffcc" border="01" cellpadding="08" cellspacing="0" width="730" xbgcolor="ddddff">';
print '<tr><td class="form_left_flush">';
print "<font face=\"verdana\" size=\"2\">Choose search terms from selection menus or enter search terms by typing into the input boxes. <a href=\"./search_explain.php\" target=\"_blank\">More.</a></font><br />\n";
print '</td></tr></table>';

print '<table xbgcolor="ffffcc" border="01" cellpadding="08" cellspacing="0" xwidth="740" width="560" xbgcolor="ddddff">';
print '<tr><td rowspan="1" valign="top" width="454" class="form2">Search Term Input Boxes</td>';
print '<td class="form2">Search Term Selection Menus</td></tr>';
print '<tr><td rowspan="1" valign="top" width="454">';
print '<table border="1" cellpadding="2" cellspacing="0" bgcolor="ddeeff" xbgcolor="ffddff" xwidth="340" name="search_form_table">';

print "<input type=\"hidden\" name=\"top\"   value=\"$top\"  /> \n";
print "<input type=\"hidden\" name=\"serid_list\"   value=\"$serid_list\"  /> \n";
print "<input type=\"hidden\" name=\"smarkov_key\"  value=\"$smarkov_key\" />\n";
print '<input type="hidden" name="display_choice" value="0">';
print "<input type=\"hidden\" name=\"serid\"        value=\"$serid\" /> \n";
 

print '<tr><td align="right" class="form2">Accession # </td><td align="left" class="form2">';
print "<input type=\"text\" name=\"sacc\" size=\"6\" maxlength=\"6\" value=\"$sacc\" />\n";
print '</td></tr>';


/*
print '<tr><td align="right" class="form2">Keep Delete: </td><td align="left">';
print "<select name=\"stest\" size=\"1\" maxlength=\"6\" value=\"$stest\" >\n";
print '<option value="keep" selected>KEEP</option>';
print '<option value="delete">DELETE</option>';
print '<option value="">BOTH</option>';
print '</select>';
print '</td></tr>';
*/
print "<input type=\"hidden\" name=\"stest\" value=\"$stest\" /> \n";

print '<tr><td align="right" class="form2">Author</td><td align="left">';
print "<input type=\"text\" name=\"snameauthor\" size=\"21\" maxlength=\"40\" value=\"$snameauthor\" onblur=\"char_check(this)\"/>\n";
print '</td></tr>';

#hidden cetitle
print "<input type=\"hidden\" name=\"cetitle\" size=\"21\" maxlength=\"60\" value=\"$cetitle\" onblur=\"char_check(this)\" />\n";

#hidden state
print "<input type=\"hidden\" name=\"state\" size=\"21\" maxlength=\"60\" value=\"$state\" onblur=\"char_check(this)\" />\n";

#hidden denom
print "<input type=\"hidden\" name=\"denom\" size=\"21\" maxlength=\"60\" value=\"$denom\" onblur=\"char_check(this)\" />\n";

#display cetitle or (state and/or denom)
#smarkov_CSD hidden var for the LABEL $markov_CSD
print "<input type=\"hidden\" name=\"smarkov_CSD\" value=\"$markov_CSD\" />\n";
print '<tr><td align="right" class="form2"><div name="CSD" id="CSD">';
print $markov_CSD;
print '</div></td><td align="left">';
print "<input type=\"text\" name=\"CSDval\" size=\"21\" maxlength=\"60\" value=\"$CSDval\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';



print '<tr><td align="right" class="form2">Title </td><td align="left">';
print "<input type=\"text\" name=\"stitle\" size=\"21\" maxlength=\"40\" value=\"$stitle\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';

print '<tr><td align="right" class="form2">Repository</td><td align="left">';
print "<input type=\"text\" name=\"slibloc_code\" size=\"21\" value=\"$slibloc_code\"  />\n";
print "<input type=\"hidden\" name=\"sloc\" size=\"21\" maxlength=\"40\" value=\"$sloc\" READONLY />\n";
print '</td></tr>';


print '<tr><td align="right" class="form2">Book of Bible</td><td align="left">';
print "<input type=\"text\" name=\"sibr\" size=\"21\" maxlength=\"40\" value=\"$sibr\" onblur=\"char_check(this)\"  />\n";
print '</td></tr>';


print '<tr><td align="right" class="form2">Index Date</td><td align="left">';
print "<input type=\"text\" name=\"sida\" size=\"21\" maxlength=\"80\" value=\"$sida\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';


print '<tr><td align="right" class="form2">Commentary </td><td align="left">';
print "<input type=\"text\" name=\"scmt\" size=\"21\" maxlength=\"40\" value=\"$scmt\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';

print '<tr><td align="right" class="form2">Keyword/<br>Short Title</td><td align="left">';
print "<input type=\"text\" name=\"skey\" size=\"21\" maxlength=\"60\" value=\"$skey\" onblur=\"char_check(this)\" />\n";
print '</td></tr>';

print '<tr><td align="right" valign="center" class="form2">Reveal Results</td><td align="left">';
print "<input type=\"button\" onclick=\"submit_search_form(0)\" name=\"fullres\" value=\"Full Results\" class=\"bluebutton160\" /><br>\n";
print "<input type=\"button\" onclick=\"submit_search_form(1)\" name=\"oneline\" value=\"Line Results\" class=\"bluebutton160\" />\n";
print '</td></tr>';

print '<tr><td align="right" class="form2">Clear</td><td align="left">';
print "<input type=\"button\" name=\"myclear\" value=\"Clear / New Search\" onclick=\"my_search_clear()\" class=\"bluebutton160\" />\n";
print '</td></tr>';
print "</table>";
print "</form>";
print '</td>';

###xxx print '</div>';

print '<td valign="top">';
#print '<hr style="width:480; height:10; background:a00000;">';
print '<div class="form2" name="enclose_iframe">';###hr width 480 -- iframe_table width=480 <br>iframe width 476';
###print '<script>document.write("<br>document.search_form.smarkov_key.value="+document.search_form.smarkov_key.value);</script>';
print '</div name="enclose_iframe">';
print '<table name="iframe_table" border="1" cellpadding="2" cellspacing="0" width="426" xwidth="480" bgcolor="000080"><tr><td align="center" valign="top">';
include "KEY/alpha3.php";
##print '##########iframe_table start';
#print '<iframe name="B" id="B_id" width="476" height="600" src="KEY/NLC.php"></iframe>';
$markov_src="KEY/$smarkov_key.php";

#print "markov_src=$markov_src<br>";
#print "<iframe name=\"B\" id=\"B_id\" width=\"476\" height=\"500\" src=\"$markov_src\"></iframe>";

print "<iframe name=\"B\" id=\"B_id\" width=\"426\" height=\"282\" src=\"$markov_src\"></iframe>";
################iframe_table end

print '</td></tr></table name="iframe_table"><!--END SEARCH FORM-->';

print '</td></tr></table>';
#######################################END SEARCH FORM#################################################################
###LINE 288 

if (($snameauthor) || ($cetitle) || ($state) || ($denom) || ($stitle)||($serid)||($sloc) || ($slibloc_code) ||($sacc) || ($sibr) 
|| ($sida) || ($skey) || ($sht) || ($scmt) || ($sbr) ||($nopgs) )
{
$iquery = "SELECT ser_test.pid, ser_test.sermon_id,ser_test.sermon_test_id, ser_test.nameauthor, ser_test.state, ";
$iquery.= " ser_test.denom, ser_test.dates, ser_test.ser_title, ser_test.cover_entry_title,  ser_test.book_title, ser_test.totalpgs, ";
$iquery.= " ser_test.placepub, ser_test.publisher, ser_test.date2, ser_test.ser_pgno, ser_test.placedate, ";
$iquery.= " ser_test.indexdate,  ser_test.nopgs, ser_test.bibref, ser_test.indexbibref, ser_test.comment, ";
$iquery.= " ser_test.libloc, ser_test.loc_repository, ser_test.libloc_code, ser_test.crossref, ser_test.shorttitle, ser_test.printface, ";
$iquery.= " ser_test.keywords, ser_test.pmb, ser_test.c_i, ser_test.accession, ser_test.update_date, ser_test.test ";
$iquery.= " , ser_test.comment_long, ser_test.authors_note ";
$iquery.= " FROM $ser2_test2_alias as ser_test ";
if ($serid>0 ) 
  {
	$iquery.= "WHERE ser_test.pid=$serid ";
        if ($stest)        $iquery.= " AND ser_test.test LIKE '%$stest%' ";
  }
else if ($sacc) 
  {
	#$iquery.= "WHERE ser_test.accession LIKE '$sacc%' ";
	$iquery.= "WHERE ser_test.accession = '$sacc' ";
        if ($stest)        $iquery.= " AND ser_test.test LIKE '%$stest%' ";

  }
else
  {
	#$iquery.= "WHERE ser_test.pid ";
	$iquery.= "WHERE 1 ";
	if ($snameauthor)  $iquery.= " AND ser_test.nameauthor LIKE '%$snameauthor%' ";
	if ($cetitle)	   $iquery.= " AND ser_test.cover_entry_title LIKE '%$cetitle%' ";
	if ($state)	   $iquery.= " AND ser_test.state LIKE '%$state%' ";
	if ($denom)	   $iquery.= " AND ser_test.denom LIKE '%$denom%' ";
  	if ($stitle)       $iquery.= " AND ser_test.ser_title LIKE '%$stitle%' ";
  	#if ($sloc)         $iquery.= " AND ser_test.libloc LIKE '%$sloc%' ";
	if ($slibloc_code) $iquery.= " AND ser_test.libloc_code  = '$slibloc_code'";
        if ($sibr)         $iquery.= " AND ser_test.indexbibref LIKE '%$sibr%' ";

	###indexdate
	$sida2 = $sida;
	$sida2 = ereg_replace(" OR ","%' OR ser_test.indexdate LIKE '%",$sida2);
        if ($sida)         $iquery.= " AND ( ser_test.indexdate LIKE '%$sida2%' ) ";

        if ($skey)         $iquery.= " AND (ser_test.shorttitle LIKE '%$skey%' OR ser_test.keywords LIKE '%$skey%' ) ";
	#####if ($sht)	   $iquery.= " AND (ser_test.shorttitle LIKE '%$sht%') ";


        if ($scmt)         $iquery.= " AND ser_test.comment LIKE '%$scmt%' ";
        if ($sbr)          $iquery.= " AND ser_test.comment LIKE '%$sbr%' ";
        if ($nopgs)        $iquery.= " AND ser_test.comment LIKE '%$nopgs%' ";
        if ($stest)        $iquery.= " AND ser_test.test LIKE '%$stest%' ";

  }

$iquery.= " AND (ser_test.test LIKE '%keep%') ";
$iquery.= " order by replace(replace(ser_test.nameauthor,\"[\",\"\"),'$doublequote',\"\"), replace(ser_test.shorttitle,\"[\",\"\") ";
$result = mysql_query($iquery, $link) or die ("Error in query: $iquery. " . mysql_error());
$numhits = mysql_num_rows($result);

$iquery2="$iquery"." LIMIT $rec,$lim ";

print '<input type="hidden" name="test_iquery" value="';
print $iquery;
print '" >';
print '<input type="hidden" name="test_iquery2" value="';
print $iquery2;
print '" >';

print "</form>\n";
#print "</div name=\"enclose_search_form\">\n";
#####print $iquery;


##full results[display_choice=0] or line results[1]

$iresult = mysql_query($iquery2, $link) or die ("Error in   query: $iquery2. " . mysql_error());

// $pid,$sid,$na,$st,$dn,$da,$srt,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$xref,$pfc,$sht,$kyw, $pmb,$ci,$acc,$update_date, $test

if ($numhits > 1 ) 
{
	print "<div class=\"form\">\n";
	print "A total of $numhits results were returned for the search criteria above.";
	print "</div>";
}else if ($numhits == 1)  {
	print "<div class=\"form\">\n";
	print "Only $numhits result was returned for the search criteria above.";
	print "</div>";
}


#print "$iquery2 <hr />";
####LINE 371 



if (mysql_num_rows($iresult)) 
 {
//print "$iquery2 <hr />";
 //=====================
   	PageLinkTop();
 //=====================


 #print "<table border=\"$display_choice\" class=\"list\" summary=\"\" xborder=\"01\" width=\"98%\" cellpadding=\"4\">\n";
 print "<table border=\"1\" class=\"list\" summary=\"\" xwidth=\"620\" width=\"760\" cellpadding=\"4\">\n";
 $bg="bg2";
 $this_form_name="pageformA";

 ##use pageformA for line display_choice=1 and for full display_choice=0
 $this_form_name="pageformA";
 print "<form name=\"pageformA\" xaction=\"view_search_only.php\">";
 print "<input type=\"hidden\" name=\"this_page_pid_list\" value=\"0\"> \n";
 print "<input type=\"hidden\" name=\"other_page_pid_list\" value=\"0\"> \n";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\">\n";
 print "<input type=\"hidden\" name=\"top\" value=\"$top\">\n";


 if ($display_choice==0) {//full display

 print "<tr >";
 print "<td class=\"label\">&nbsp;</td>\n";
 print "</tr>\n";
 }else{//line display
/*
 ##use pageformA for line display_choice=1 and for full display_choice=0
 $this_form_name="pageformA";
 print "<form name=\"pageformA\" xaction=\"view_search_only.php\">";
 print "<input type=\"hidden\" name=\"this_page_pid_list\" value=\"0\"> \n";
 print "<input type=\"hidden\" name=\"other_page_pid_list\" value=\"0\"> \n";
 print "<input type=\"hidden\" name=\"serid_list\" value=\"$serid_str\">\n";
*/

 ####################code block from view_author_title_index##########

 print "<table border=\"1\" class=\"list\" summary=\"\" width=\"760\" cellpadding=\"2\" cellspacing=\"0\">\n";

 /*----------------------------------*/
 print "<tr><td colspan=\"5\" >";
 print "<input type=\"button\" name=\"save_this_page_pids\" value=\"Check All This Page\" onclick=\"check_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"remove_this_page_pids\" value=\"Uncheck All This Page\" onclick=\"uncheck_all('A');\" class=\"bluebutton200\">&nbsp;";
 print "<input type=\"button\" name=\"clearpageformA\" value=\"Clear All\" onclick=\"clear_all();\" class=\"bluebutton200\">&nbsp;";
 //print "<input type=\"button\" name=\"showpageformA\" value=\"Show All\" onclick=\"show_all();\" class=\"bluebutton200\">&nbsp;";
 print "</td></tr>\n";
/* ---------------------------------*/
 print "<tr >";
 print "<td width=\"5%\" class=\"value14so\">Select</td>";
 print "<td width=\"7%\" class=\"value14so\">&nbsp;Acc&nbsp;#</td>";
 print "<td xwidth=\"5%\" class=\"value14so\">Author</td>";
 print "<td xwidth=\"5%\" class=\"value14so\">Short Title</td>";
 print "<td width=\"12%\" class=\"value14so\">Index Date</td>\n";
 print "</tr>\n";


 ####################code block from view_author_title_index##########

 }


 while (list($pid,$sid,$sid_test,$na,$st,$dn,$da,$srt,$cetitle,$sbt,$tpgs,$ppub,$pub,$da2,$pno,$pda,$ida,$npgs,$br,$ibr,$cmt,$loc,$loc_repository,$loc_code,$xref,$sht,$pfc,$kyw,$pmb,$ci,$acc,$update_date, $test, $cmt_long,$anote) = mysql_fetch_row($iresult))
  {
	  if($display_choice==0) {#start display_choice=0 display full results LINE 391

		  if ($bg=="bg1") $bg="bg2";
		  elseif ($bg=="bg2") $bg="bg1";
		  print "<tr class=\"$bg\">\n";
		  print "<td width=\"620\">\n";
		  /*
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Sermon ID #: </div>\n";
		  print "<div class=\"cont\">$sid</div>\n";
		  print "</div>\n";
		  */
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Accession Number:</div>\n";
		  print "<div class=\"cont\">$acc $update_date</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Author:</div>\n";
#$na=htmlentities($na); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$na</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">State/Denom/Dates:</div>\n";
		  print "<div class=\"cont\"> $st $dn $da</div>\n";
		  print "</div>\n";
		  print "<br />";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Cover Entry Title:</div>\n";
#$srt=htmlentities($cetitle); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$cetitle</div>\n";
		  print "</div>\n";
		  print "<br />";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Title:</div>\n";
#$srt=htmlentities($srt); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$srt</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Place/Date Preached:</div>\n";
		  $pda=htmlentities($pda);
		  print "<div class=\"cont\">$pda</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Index Date:</div>\n";
		  $ida=htmlentities($ida);
		  print "<div class=\"cont\">$ida</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Number Pages:</div>\n";
		  $npgs=htmlentities($npgs);
		  print "<div class=\"cont\">$npgs</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Biblical Ref.:</div>\n";
#$br=htmlentities($br); # remove this to make <i>...</i> work
		  print "<div class=\"cont\">$br</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Index Biblical Ref.:</div>\n";
		  $ibr=htmlentities($ibr); # remove this to make <i>...</i> work
			  print "<div class=\"cont\">$ibr</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Commentary:</div>\n";
#$cmt=htmlentities($cmt); #remove this line to make <i>...</i> work
		  print "<div class=\"cont\">$cmt</div>\n";
		  print "</div>\n";


		  print "<div class=\"item\">";
		  print "<div class=\"label\">Repository (Code):</div>\n";
		  $loc_repository=htmlentities($loc_repository);
		  $loc_repository_2=$loc_repository;
		  $loc_code=htmlentities($loc_code);
		  $loc_code_2=$loc_code;
		  print "<div class=\"cont\">$loc_repository ($loc_code)</div>\n";

		  $s2 = ereg_replace(";","",$loc);

		  if ($s2 != $loc_code) {
			  print "</div>\n";
			  print "<div class=\"item\">";
			  print "<div class=\"label\">Repository Details:</div>\n";
			  $loc=htmlentities($loc);
			  $loc_2=$loc;
			  print "<div class=\"cont\">$loc</div>\n";
		  }



		  print "</div>\n";

		  print "<div class=\"item\">";
		  print "<div class=\"label\">Short Title:</div>\n";
		  #$sht=htmlentities($sht); #remove this line to make <i>...</i> work
		  print "<div class=\"cont\">$sht</div>\n";
		  print "</div>\n";
		  print "<div class=\"item\">";
		  print "<div class=\"label\">Keywords:</div>\n";
		  print "<div class=\"cont\">$kyw</div>\n";
		  print "</div>\n";


############# checkbox for $display_choice=0 full display
  	print "<div class=\"item\">";
  	print "<div class=\"label\">Select:</div>\n";
  	print "<div class=\"cont\">";
	print "&nbsp;<input type=\"checkbox\" name=\"chbx";
        print $pid;
        print "\" ";
        print " onclick='reset_chbx_search(\"";
        print $this_form_name;
        print "\",this,\"";
        print $pid;
        print "\",\"";
        print $acc;
        print "\");' ";
        #print "style=\"height:25px;width:25px;\">";
        print "style=\"height:20px;width:20px;\">";
 	print "To select this entry, please check the box.";
        
        
        print "<script language=\"javascript\">";
        #print "var msg=new String(\"set_chbx_search $pid\"); ";
        #print "alert(msg);"
        print "set_chbx_search(\"";
        print $this_form_name;
        print "\",\"";
        print $pid;
        print "\");";
        print "</script>";


		  print "</div>\n";
		  print "</div>\n";


		  print "</div>\n";

############# do notadd checkbox $display_choice=0 full display

 print "<tr >";
 print "<td class=\"label\">&nbsp;</td>\n";
 print "</tr>\n";


		  print "</div>\n";
		  //-----------------
		  print "</td>\n";
		  print "</tr>\n";
#end $display_choice=0
}else if($display_choice==1) {#$display_choice=1 //line results  LINE 801
	#print "display_choice=$display_choice pid=$pid";

	print "<tr>";
        ####################code block from view_author_title_index##########
	print "<td valign=\"top\" class=\"value14so\">&nbsp;";

        print "&nbsp;<input type=\"checkbox\" name=\"chbx";
        print $pid;
        print "\" ";
        print " onclick='reset_chbx_search(\"";
        print $this_form_name;
        print "\",this,\"";
        print $pid;
        print "\",\"";
        print $acc;
        print "\");' ";
        #print "style=\"height:25px;width:25px;\">";
        print "style=\"height:20px;width:20px;\">";


        print "<script language=\"javascript\">set_chbx_search(\"";
        print $this_form_name;
        print "\",\"";
        print $pid;
        print "\");";
	print "</script>";


        print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	print "<a  href=\"view_one_acc.php?serid=";
        print $pid;
	print "&accid=";
	print $acc;
        print "\" target=\"_blank\">";
        print $acc;
        #print "($pid)";
        print "</a>";

	print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	print $na;
	print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	#print $srt;
	print $sht; #title:$srt #shortttile $sht
	print "</td><td valign=\"top\" class=\"value14so\">&nbsp;";
	#print $da;
	print "$ida"; #dates:$da #indexdate: $ida
	print "</td>";



        ####################code block from view_author_title_index##########

        print "</tr>\n";
	} #end if ($display_choice==1) # line display

  } //end while - the while serves display_choice==0 and display_choice == 1
  print "</form name=\"pageformA\">";

 print "</table>";
 //=====================
    	PageLinkBottom();
 //=====================
 }// end if	mysql
else 
{
	print "<div class=\"form\">\n";
	print "No results returned for the search criteria above.";
	print "</div>";
}
} //end  if (($snameauthor) || ($stitle)||($serid)||($sloc) || ($slibloc_code) )
print "</div>\n";
##print $footer;
?>
<script language=javascript src="elements.js"></script>
<script>
//document.write("<br>document.pageformA.this_page_pid_list.value="+document.pageformA.this_page_pid_list.value+"<br>");
//document.write("<br>document.formW.serid_list.value="+document.formW.serid_list.value+"<br>");
//document.write("document.formW.this_page_pid_list.value="+document.formW.this_page_pid_list.value+"<HR><HR>");
//show_elements defined in include_standard.php
show_elements=0;
if (show_elements==1) {
        elements();
}
</script>
</body>
</html>
