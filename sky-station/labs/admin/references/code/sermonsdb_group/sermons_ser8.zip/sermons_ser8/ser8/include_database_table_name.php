
<?php
#include_database_table_name.php
#-------------------begin with a line of php comment
#name the database table being used

$ser2_test2_alias = "ser2_test2";


/*---------------------

This file is included in the file include_standard.php.

The one line of information contained in this file is
propagated to other files in this directory (listed below).

-bash-3.2$ grep 'include "include_standard.php"' * | more
date_search_explain.htm:include "include_standard.php";
edit_update.php:include "include_standard.php";
include_database_table_name.php:date_search_explain.htm:include "include_standard
.php";
include_database_table_name.php:edit_update.php:include "include_standard.php";
include_database_table_name.php:view_accession_print.php:include "include_standar
d.php";
include_database_table_name.php:view_authortitle_print_all.php:include "include_s
tandard.php";
include_database_table_name.php:view_authortitle_print.php:include "include_stand
ard.php";
include_database_table_name.php:view_batch2_print.php:include "include_standard.p
hp";
include_database_table_name.php:view_batch2_select.php:include "include_standard.
php";
include_database_table_name.php:view_batch_print.php:include "include_standard.ph
p";
include_database_table_name.php:view_batch_select.php:include "include_standard.p
hp";
include_database_table_name.php:view_cart_index.php:include "include_standard.php
";
include_database_table_name.php:view_cart_print.php:include "include_standard.php
";
include_database_table_name.php:view_condensed_print_all.php:include "include_sta
ndard.php";
include_database_table_name.php:view_condensed_print.php:include "include_standar
d.php";
include_database_table_name.php:view_noheaders_print.php:include "include_standar
d.php";
include_database_table_name.php:view_one_acc.php:include "include_standard.php";
include_database_table_name.php:view_print_options.php:include "include_standard.
php";
include_database_table_name.php:view_search_only.php:include "include_standard.ph
p";
include_database_table_name.php:view_short_print.php:include "include_standard.ph
p";
include_database_table_name.php:welcome.htm:include "include_standard.php";
include_database_table_name.php:welcome.php:#include "include_standard.php";
include_database_table_name.php:welcome.php:########## needed here because no inc
lude "include_standard.php";
include_database_table_name.php:welcome_private.php:include "include_standard.php
";
include_database_table_name.php:welcome_public.php:#include "include_standard.php
";
view_accession_print.php:include "include_standard.php";
view_authortitle_print_all.php:include "include_standard.php";
view_authortitle_print.php:include "include_standard.php";
view_batch2_print.php:include "include_standard.php";
view_batch2_select.php:include "include_standard.php";
view_batch_print.php:include "include_standard.php";
view_batch_select.php:include "include_standard.php";
view_cart_index.php:include "include_standard.php";
view_cart_print.php:include "include_standard.php";
view_condensed_print_all.php:include "include_standard.php";
view_condensed_print.php:include "include_standard.php";
view_noheaders_print.php:include "include_standard.php";
view_one_acc.php:include "include_standard.php";
view_print_options.php:include "include_standard.php";
view_search_only.php:include "include_standard.php";
view_short_print.php:include "include_standard.php";
welcome.htm:include "include_standard.php";
welcome.php:#include "include_standard.php";
welcome.php:########## needed here because no include "include_standard.php";
welcome_private.php:include "include_standard.php";
welcome_public.php:#include "include_standard.php";

----------------------*/


?>
