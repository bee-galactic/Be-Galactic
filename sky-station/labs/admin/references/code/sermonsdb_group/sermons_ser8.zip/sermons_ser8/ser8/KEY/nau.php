<html>
<head>
<title>na_loc_cet</title>
<script language="javascript">
//from  ser-header_vsearch.php 


function my_na_select() {
var sText = new String();

for ( i=0; i< document.na_form.na_select.length; i++ ) {
	if (document.na_form.na_select[i].selected == true ) {
		sText = document.na_form.na_select[i].value;
		break;
		}//end if
	}//end for
//document.search_form.snameauthor.value = sText;
parent.document.search_form.snameauthor.value = sText;
parent.document.search_form.smarkov_key.value= "nau";
}//end function my_na_select 

</script>

<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body><div class="form2">

<!--########na_form table start-->
<form name="na_form" >
Author<br />

<?php
include "size_set_CILN.php";
print "<select name=\"na_select\" size=\"$menu_size\" onchange=\"my_na_select()\">";
?>

<option value="" selected>none selected</option>

<option value="ADDISON, HENRY">ADDISON, HENRY</option>
<option value="ALLEN, JOHN">ALLEN, JOHN</option>
<option value="ANONYMOUS">ANONYMOUS</option>
<option value="ASHBY, JAMES">ASHBY, JAMES</option>
<option value="ATTWOOD, PETER">ATTWOOD, PETER</option>
<option value="BEADNALL, JAMES">BEADNALL, JAMES</option>
<option value="BEESTON, FRANCIS">BEESTON, FRANCIS</option>
<option value="BEND, JOSEPH GROVE JOHN">BEND, JOSEPH GROVE JOHN</option>
<option value="BITOUZEY, GERMAIN BARNABAS">BITOUZEY, GERMAIN BARNABAS</option>
<option value="BLAIR, JOHN DURBARROW">BLAIR, JOHN DURBARROW</option>
<option value="BOARMAN, JOHN">BOARMAN, JOHN</option>
<option value="BOARMAN, SYLVESTER">BOARMAN, SYLVESTER</option>
<option value="BOLTON, JOHN">BOLTON, JOHN</option>
<option value="BOONE, JOHN">BOONE, JOHN</option>
<option value="BUCHAN, ROBERT">BUCHAN, ROBERT</option>
<option value="CARROLL, JAMES">CARROLL, JAMES</option>
<option value="CARROLL, JOHN">CARROLL, JOHN</option>
<option value="CHASE, THOMAS">CHASE, THOMAS</option>
<option value="CLAGGETT, THOMAS JOHN">CLAGGETT, THOMAS JOHN</option>
<option value="CLAY, CHARLES">CLAY, CHARLES</option>
<option value="COKE, THOMAS">COKE, THOMAS</option>
<option value="COLEMAN, JOHN">COLEMAN, JOHN</option>
<option value="COOPER, MYLES">COOPER, MYLES</option>
<option value="CRADOCK, THOMAS">CRADOCK, THOMAS</option>
<option value="CRAIG, JOHN">CRAIG, JOHN</option>
<option value="D____, EARL">D____, EARL</option>
<option value="DAVIES, SAMUEL">DAVIES, SAMUEL</option>
<option value="DAWSON, THOMAS">DAWSON, THOMAS</option>
<option value="DAWSON, WILLIAM">DAWSON, WILLIAM</option>
<option value="DENT, HATCH">DENT, HATCH</option>
<option value="DIDERICH, BERNARD">DIDERICH, BERNARD</option>
<option value="DIGGES, JOHN">DIGGES, JOHN</option>
<option value="DOZIER, RICHARD">DOZIER, RICHARD</option>
<option value="DUKE, WILLIAM">DUKE, WILLIAM</option>
<option value="DUNLAP, WILLIAM">DUNLAP, WILLIAM</option>
<option value="ELLINGTON, EDWARD">ELLINGTON, EDWARD</option>
<option value="FARMER, FERDINAND">FARMER, FERDINAND</option>
<option value="FARRAR, JAMES">FARRAR, JAMES</option>
<option value="FERGUSON, COLIN">FERGUSON, COLIN</option>
<option value="FRAMBACH, JAMES">FRAMBACH, JAMES</option>
<option value="FRINK, SAMUEL">FRINK, SAMUEL</option>
<option value="FURMAN, RICHARD">FURMAN, RICHARD</option>
<option value="GANTT, EDWARD JR.">GANTT, EDWARD JR.</option>
<option value="GERARD, THOMAS">GERARD, THOMAS</option>
<option value="GOLDIE, GEORGE">GOLDIE, GEORGE</option>
<option value="GORDON, JOHN">GORDON, JOHN</option>
<option value="GOUNDRIL, GEORGE">GOUNDRIL, GEORGE</option>
<option value="GREATON, JOSEPH">GREATON, JOSEPH</option>
<option value="GREEN, ENOCH">GREEN, ENOCH</option>
<option value="HARDING, ROBERT">HARDING, ROBERT</option>
<option value="HARRIS, MATTHIAS">HARRIS, MATTHIAS</option>
<option value="HART, OLIVER">HART, OLIVER</option>
<option value="HEMPHILL, JOHN">HEMPHILL, JOHN</option>
<option value="HINDMAN, JACOB H.">HINDMAN, JACOB H.</option>
<option value="HINDMAN, JAMES">HINDMAN, JAMES</option>
<option value="HOLMES, ABIEL">HOLMES, ABIEL</option>
<option value="HUMPHREYS, JOHN V.">HUMPHREYS, JOHN V.</option>
<option value="HUNTER, GEORGE">HUNTER, GEORGE</option>
<option value="HUNTER, WILLIAM">HUNTER, WILLIAM</option>
<option value="JENKINS, AUGUSTINE">JENKINS, AUGUSTINE</option>
<!--<option value="JOSEPH, GOV. WILLIAM">JOSEPH, GOV. WILLIAM</option> commented out, bds, 2009-05-18-->
<option value="KER, JACOB">KER, JACOB</option>
<option value="LEWIS, JOHN">LEWIS, JOHN</option>
<option value="LIVERS, ARNOLD">LIVERS, ARNOLD</option>
<option value="LORD, JOSEPH">LORD, JOSEPH</option>
<!--<option value="MACRAE, CHRISTOPHER">MACRAE, CHRISTOPHER</option> commented out, bds, 2009-05-18-->
<option value="MANNERS, MATHIAS">MANNERS, MATHIAS</option>
<option value="MARECHAL, AMBROSE">MARECHAL, AMBROSE</option>
<option value="MATTHEWS, IGNATIUS">MATTHEWS, IGNATIUS</option>
<option value="MAURY, JAMES">MAURY, JAMES</option>
<option value="MAURY, WALKER">MAURY, WALKER</option>
<option value="MCCORKLE, SAMUEL EUSEBIUS">MCCORKLE, SAMUEL EUSEBIUS</option>
<option value="MEACHAM, JAMES">MEACHAM, JAMES</option>
<option value="MESSENGER, JOSEPH">MESSENGER, JOSEPH</option>
<option value="MILLER, ROBERT JOHNSTON">MILLER, ROBERT JOHNSTON</option>
<option value="MOLYNEUX, RICHARD">MOLYNEUX, RICHARD</option>
<option value="MOLYNEUX, ROBERT">MOLYNEUX, ROBERT</option>
<option value="MONCURE, JOHN">MONCURE, JOHN</option>
<option value="MORRIS, PETER">MORRIS, PETER</option>
<option value="MOSLEY, JOSEPH">MOSLEY, JOSEPH</option>
<option value="NEALE, BENNET">NEALE, BENNET</option>
<option value="NEALE, HENRY">NEALE, HENRY</option>
<option value="NEALE, LEONARD">NEALE, LEONARD</option>
<option value="PAT(T)ILLO, HENRY">PAT(T)ILLO, HENRY</option>
<option value="PAXTON, ROBERT">PAXTON, ROBERT</option>
<option value="PEAD, DEUEL">PEAD, DEUEL</option>
<option value="PETTIGREW, CHARLES">PETTIGREW, CHARLES</option>
<option value="PILE, HENRY">PILE, HENRY</option>
<option value="PLUNKETT, ROBERT">PLUNKETT, ROBERT</option>
<option value="PREADE, ROBERT">PREADE, ROBERT (see also READ)</option>
<option value="PULTON, THOMAS">PULTON, THOMAS</option>
<option value="PURCELL, HENRY">PURCELL, HENRY</option>
<option value="READ, ROBERT">READ, ROBERT (see also PREADE)</option>
<option value="READ, THOMAS">READ, THOMAS (see also PREADE)</option>
<option value="REED, GEORGE A.">REED, GEORGE A.</option> 
<option value="REED, GEORGE A. V.">REED, GEORGE A. V.</option>
<!--<option value="REED, GEORGE A.">REED, GEORGE A.</option> commented out, bds, 2009-05-18-->
<!--<option value="REED, GEORGE A.">REED, GEORGE A.</option> commented out, bds, 2009-05-18-->
<option value="ROELS, BENJAMIN LOUIS">ROELS, BENJAMIN LOUIS</option>
<option value="SAVERY, WILLIAM">SAVERY, WILLIAM</option>
<option value="SELDEN, MILES">SELDEN, MILES</option>
<option value="SEWALL, CHARLES">SEWALL, CHARLES</option>
<option value="SIMPSON, ARCHIBALD">SIMPSON, ARCHIBALD</option>
<option value="SITTENSPERGER, MATHIAS">SITTENSPERGER, MATHIAS</option>
<option value="SLOAN(E), SAMUEL">SLOAN(E), SAMUEL</option>
<option value="SMITH, ARMISTEAD">SMITH, ARMISTEAD</option>
<option value="SMITH, HEZEKIAH">SMITH, HEZEKIAH</option>
<option value="STILLMAN, SAMUEL">STILLMAN, SAMUEL</option>
<option value="TENNENT, WILLIAM III">TENNENT, WILLIAM III</option>
<option value="TOLER, HENRY">TOLER, HENRY</option>
<option value="TURQUAND, PAUL">TURQUAND, PAUL</option>
<option value="WALTON, JAMES">WALTON, JAMES</option>
<option value="WILLIAMS, JOHN">WILLIAMS, JOHN</option>
<option value="WOOT(T)ON, JAMES">WOOT(T)ON, JAMES</option>
<option value="YELLOW, GEORGE">YELLOW, GEORGE</option>
<option value="YOUNG, JOHN SR.">YOUNG, JOHN SR.</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select><br />
</form>
</div>

</body>
</html>
