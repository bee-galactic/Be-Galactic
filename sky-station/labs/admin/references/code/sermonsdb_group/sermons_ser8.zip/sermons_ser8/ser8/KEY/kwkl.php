<html>
<head>
<title>kwl</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwkl";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- K-L</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Kelly, Mrs., funeral of</option>
<option>Kelso, J., funeral of</option>
<option>kindness</option>
<option>king's power, divine source of</option>
<option>King Agrippa</option>
<option>Kingdom of God</option>
<option>Kingdom of God, nature of</option>
<option>Kingston Parish, Mathews Co., Va</option>
<option>knowledge</option>
<option>knowledge, importance of</option>
<option>knowledge, limitations of human</option>
<option>knowledge, regulation of zeal through</option>
<option>knowledge of Christ</option>
<option>knowledge of self</option>
<option>Knox, Dr</option>
<option>La Colombiere, Rev. Claude de</option>
<option>labor</option>
<option>labor, necessity of</option>
<option>Lacedemonians, negligence of</option>
<option>Lafayette, imprisonment of</option>
<option>language of religious service</option>
<option>Last Days</option>
<option>Last Days, signs of</option>
<option>Last Judge, quality of</option>
<option>last judgment</option>
<option>last judgment, certainty of</option>
<option>last judgment, results of</option>
<option>last judgment, subjects of</option>
<option>last judgment, terrors of</option>
<option>Last Supper</option>
<option>laughter</option>
<option>law</option>
<option>law, ceremonial</option>
<option>law, curse of</option>
<option>law, divine</option>
<option>law, human</option>
<option>law, moral</option>
<option>law, Mosaic</option>
<option>law, sacrifices of the</option>
<option>law of God</option>
<option>Lawrence, Mrs., funeral of</option>
<option>laws, God's</option>
<option>laws, type of</option>
<option>lawsuits, sinfulness of</option>
<option>Lazarus</option>
<option>Lazarus, Christ's raising of</option>
<option>Lazarus, parable of</option>
<option>Lazarus, parable of the rich man and</option>
<option>Lazarus, resurrection of</option>
<option>Lazarus the beggar, parable of</option>
<option>learning, human</option>
<option>learning, religion weakened by</option>
<option>Lee, Robert Edward</option>
<option>Lent</option>
<option>Lenten sermon</option>
<option>Lesk, Mr.</option>
<option>Lewis, Rev. John</option>
<option>liberal education, necessity of</option>
<option>liberty</option>
<option>liberty, enemies of</option>
<option>liberty-school</option>
<option>life, as probationary state</option>
<option>life, brevity of</option>
<option>life, eternal</option>
<option>life, everlasting</option>
<option>life, overfondness for</option>
<option>life, religious</option>
<option>life, spiritual</option>
<option>life, transitoriness of</option>
<option>life, trials of</option>
<option>life, uncertainty of</option>
<option>light, inward</option>
<option>lightning, death by</option>
<option>limitations of pleasing men</option>
<option>Lion's Den, Daniel and</option>
<option>Lisbon earthquake</option>
<option>liturgy, Anglican</option>
<option>liturgy, Episcopalian</option>
<option>Livers, Rev. Arnold</option>
<option>living a Christian life</option>
<option>living righteously</option>
<option>Livy</option>
<option>Lloyd, Anne, funeral of</option>
<option>Lloyd, Edward, funeral of</option>
<option>Lloyd, Nancy</option>
<option>loaves and fishes, miracle of</option>
<option>Locke</option>
<option>long suffering</option>
<option>Lord's Day, joy of</option>
<option>Lord's Prayer</option>
<option>Lord's Prayer, explanation of</option>
<option>Lord's Supper</option>
<option>Lord's Supper, blessing of the elements of</option>
<option>Lord's Supper, cup in</option>
<option>Lord's Supper, duties regarding the</option>
<option>Lord's Supper, duty in receiving</option>
<option>Lord's Supper, exhortation</option>
<option>Lord's Supper, memorials of</option>
<option>Lord's Supper, nature of</option>
<option>Lord's Supper, neglect of</option>
<option>Lord's Supper, preparation for</option>
<option>Lord's Supper, proper distribution of</option>
<option>Lord's Supper, purpose of</option>
<option>Lord, fear of</option>
<option>Lord, joy of the</option>
<option>Lord, light of</option>
<option>Lord, name of</option>
<option>Lord, service to</option>
<option>Lord, spirit of the</option>
<option>loss</option>
<option>loss, pain of</option>
<option>lost sheep, parable of</option>
<option>Lot</option>
<option>Louis XIV</option>
<option>Louis XVI, murder of</option>
<option>love</option>
<option>love, brotherly</option>
<option>love, duty to</option>
<option>Love, God is</option>
<option>love, God's</option>
<option>love, universal</option>
<option>love of Christ</option>
<option>love of enemies</option>
<option>love of God</option>
<option>love of neighbors</option>
<option>love of the world</option>
<option>love one another</option>
<option>Loyal Society of Citizens</option>
<option>loyalty to church</option>
<option>loyalty to crown</option>
<option>Loyola, St. Ignatius</option>
<option>Luke</option>
<option>Luke, on the Lord's Prayer</option>
<option>lukewarm Christians</option>
<option>lukewarmness</option>
<option>Lunsford, Lewis, death of</option>
<option>lust</option>
<option>lust, suppression of</option>
<option>lust, victory over</option>
<option>Luther, Martin</option>
<option>Lycurgus</option>
<option>lying</option>
<option>lying, evil effects of</option>
<option>Lyttleton</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
