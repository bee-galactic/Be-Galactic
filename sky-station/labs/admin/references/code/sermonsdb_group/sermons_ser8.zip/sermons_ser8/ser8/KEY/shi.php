<html>
<head>
<title>shi</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shi";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- I</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>I am a Companion of all of them that fear thee</option>
<option>I am with you always</option>
<option>I have lived in all good conscience before God</option>
<option>I know that thou wilt bring me to Death</option>
<option>If the Son therefore shall make you free, ye shall be free indeed</option>
<option>If thou wilt enter into life, keep the Commandments</option>
<option>If ye live after the flesh ye shall die</option>
<option>Imitating Christ's Life, On</option>
<option>Imitating God, Of</option>
<option>Immaculate Conception, On the</option>
<option>Immensity of God, On the</option>
<option>Immortality, On</option>
<option>Immortality of the Soul, On the</option>
<option>Immutability of God, On the</option>
<option>Impiety & Folly of Dependence upon the World, The</option>
<option>Importance of Knowledge, The</option>
<option>Importance of Salvation, On the</option>
<option>Importance of Salvation, The</option>
<option>Importance of works, On the</option>
<option>Impossibility of Serving God & Mammon, The</option>
<option>In my prosperity I said, I shall never be moved</option>
<option>In Praise of God</option>
<option>In trust with the Gospel</option>
<option>Incentives to holiness</option>
<option>Increase in grace, On</option>
<option>Inefficacy of morality without faith, The</option>
<option>Infallibility, On</option>
<option>Infallibility of the Church, On the</option>
<option>Infant's Cause advocated, The</option>
<option>Inferno, De</option>
<option>Infidelity</option>
<option>Ingratitude to God, On</option>
<option>Inimitable goodness & excellence of the Saviour, The</option>
<option>Innocence, On</option>
<option>Insisting of the law and the prophets</option>
<option>Intercession of Christ, On the</option>
<option>Introduction of the Book of Common Prayer, On the</option>
<option>Inward light, On</option>
<option>It is a fearful thing to fall into the Hands of the living God</option>
<option>It is appointed unto man once to die</option>
<option>its evils, &c, &c</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
