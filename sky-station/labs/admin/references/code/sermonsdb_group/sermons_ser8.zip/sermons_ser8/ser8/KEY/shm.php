<html>
<head>
<title>shm</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shm";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- M</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Madgalain, or ye. Poenitent Sinner</option>
<option>Man's blessed End, Of</option>
<option>Manner of our Lord's introducing his prayer, The</option>
<option>Mark the perfect Man, and behold the upright</option>
<option>Marks of a true Xtian</option>
<option>Marks of Religious Sincerity</option>
<option>Marriage</option>
<option>Marriage, On</option>
<option>Marriage of Cana of Galilee, The</option>
<option>Mary's better choice</option>
<option>Mass, 1st Discourse on the</option>
<option>Mass, 3rd Discourse on the</option>
<option>Mass, On the</option>
<option>Matrimony: John, II, 1-2</option>
<option>Men reject the Gospel, because their deeds are evil</option>
<option>Mercy, On</option>
<option>Mercy of God, On the</option>
<option>Mercy towards children, On</option>
<option>Merry Heart, A</option>
<option>Merry Sermon, The</option>
<option>Method of Confessing</option>
<option>Miracles, On</option>
<option>Mission of Moses & Aaron to Pharaoh, The</option>
<option>Mixture of good & bad, The</option>
<option>Mixture of rich and poor</option>
<option>Moderation</option>
<option>Moderation, Of</option>
<option>Mortal Sin, On</option>
<option>Mortal sin, On</option>
<option>Mortification</option>
<option>Mortification of our passions, On the</option>
<option>Mortification of Passions</option>
<option>Murder, On</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
