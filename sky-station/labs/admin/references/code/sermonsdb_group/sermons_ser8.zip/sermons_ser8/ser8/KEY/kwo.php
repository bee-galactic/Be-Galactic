<html>
<head>
<title>kwo</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="kwo";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Keyword -- O</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>obedience</option>
<option>obedience, demanded by God</option>
<option>obedience, necessity of</option>
<option>obedience, rewards for</option>
<option>obedience to God</option>
<option>obedience to magistrates</option>
<option>obedience to parents</option>
<option>obedience to pastors</option>
<option>obligations to God</option>
<option>offertory</option>
<option>Oglesby, Sha.</option>
<option>Old Testament, doctrines of</option>
<option>Old Testament, rejection of</option>
<option>Old Testament, truth of</option>
<option>olive tree</option>
<option>Olliman, Jacob</option>
<option>Oman</option>
<option>omniscience of God</option>
<option>oral tradition, validity of</option>
<option>ordination</option>
<option>original sin</option>
<option>orphans</option>
<option>orphans, duties to</option>
<option>orphans, rights of</option>
<option>orthodoxy</option>
<option>Osborn, Col.</option>
<option>over-indulgence, dangers of</option>
<option>Owen, Mrs.</option>
<option>Owings, Mr</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
