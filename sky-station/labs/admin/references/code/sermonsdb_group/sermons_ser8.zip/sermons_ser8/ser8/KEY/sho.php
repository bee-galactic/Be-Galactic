<html>
<head>
<title>sho</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="sho";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- O</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>O that they were wise</option>
<option>Obedience, On</option>
<option>Obedience neither impossible, nor extremely difficult</option>
<option>Obedience to God, On</option>
<option>Objection from the number, the abilities, & the virtue of infidels</option>
<option>Objections against Christianity removed</option>
<option>Observance of God's Commandments, The</option>
<option>Observance of the Seventh day, On the</option>
<option>Observation of the Sabbath, On the</option>
<option>Occasioned ... Baltimore by the Yellow Fever</option>
<option>Office of the Preacher, The</option>
<option>Offices of the Church, On</option>
<option>Omnipotence of God, The</option>
<option>Omniscience of God</option>
<option>One Thing Needful, The</option>
<option>Opening of the Chappel Amelia, At the</option>
<option>Ordination, On</option>
<option>Origin of Love, The</option>
<option>Our Father, which art in Heaven</option>
<option>Our fellowship is with the Father & with his son</option>
<option>Our last end, On</option>
<option>Our Lord's Incarnation, Of</option>
<option>Our Lord, Of</option>
<option>Out of the Heart proceed evil Thoughts, For</option>
<option>Over-righteousness</option>
<option>Overcoming evil with good</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
