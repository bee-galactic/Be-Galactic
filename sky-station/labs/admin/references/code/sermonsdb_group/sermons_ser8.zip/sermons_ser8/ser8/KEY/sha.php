<html>
<head>
<title>sha</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="sha";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- A</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Abiding in Christ</option>
<option>Abstaining from all appearance of evil</option>
<option>Abuses of speech, On the</option>
<option>Accessory to others sins, On being</option>
<option>Account Book, Charles Clay, 1773-1818</option>
<option>Action sermon from 1 Corr 1st Ch & 9 vs</option>
<option>Action sermon from Isai 53 ch & 10 vs</option>
<option>Action sermon from Zech 6 ch 13 vs</option>
<option>Acts 10:38, On</option>
<option>Acts 2: 40, On</option>
<option>Adapted to the Sacrament</option>
<option>Address ... to the Episcopalians in Virginia, An</option>
<option>Address on a day of fasting</option>
<option>Advantages of doing penance, On the</option>
<option>Advantages of simplicity & godly sincerity, On the</option>
<option>Advent, For</option>
<option>Advent, On</option>
<option>Advent. Haggai's prophecy</option>
<option>Affliction</option>
<option>Affliction, On</option>
<option>Affliction and Salvation</option>
<option>Afflictions, No. 1</option>
<option>Afflictions, No. 2</option>
<option>Afflictions, No. 3</option>
<option>Afflictions, On</option>
<option>Afflictions a Blessing from God</option>
<option>Against evil speaking</option>
<option>Against habitual Discontent</option>
<option>Against Idleness</option>
<option>Against Love of ye World</option>
<option>Against over-solicitous & inordinate concern for the World</option>
<option>Against over-solicitous & inordinate concern for this world</option>
<option>Against the fear of death</option>
<option>Against the immoderate Pursuit of Pleasure</option>
<option>Agur's petition</option>
<option>All is Vanity & Vexation of Spirit</option>
<option>All nations of the earth blessed in the Seed of Abraham</option>
<option>All Saints</option>
<option>All Saints, For</option>
<option>All Saints, On the feast of</option>
<option>All Souls</option>
<option>All Souls' Day, On</option>
<option>Almost Persuaded, The</option>
<option>Amazing bounty of God to man, On the</option>
<option>Ambition, On</option>
<option>And I will pray the Father</option>
<option>Anent afflictions</option>
<option>Angels, Of</option>
<option>Anger</option>
<option>Anger, Of</option>
<option>Anger, On</option>
<option>Anger without sinning, On</option>
<option>Annunciation, On the</option>
<option>Apostles' Creed, On the</option>
<option>Appeal for School Funds, An</option>
<option>Appearance of an approaching Rupture with France, On the</option>
<option>Archibald Simpson Manuscript Sermons</option>
<option>Argument from Miracles, The</option>
<option>Argument from prophecy, The</option>
<option>Argument from the excellent effects of Xtianity, The</option>
<option>Argument from the excellent nature of Christianity, The</option>
<option>Argument from the Life & Character of Jesus, The</option>
<option>Arise ye and Depart</option>
<option>As the Lord liveth, the man ... shall surely die</option>
<option>Ascension, For the</option>
<option>Ascension, On the</option>
<option>Ascension of our Lord, The</option>
<option>Ascensionis, In festo</option>
<option>Ash Wednesday</option>
<option>Ash Wednesday, On</option>
<option>Ask now the beasts, & they shall teach thee</option>
<option>Asking for wisdom of God</option>
<option>Asking in Jesus' Name, On</option>
<option>Associating with sinners, On</option>
<option>Assumption, On the</option>
<option>Assumption of Mary, On the</option>
<option>Assumption of our Lady, On ye</option>
<option>Atonement of Christ, The</option>
<option>Avarice, On</option>
<option>Avoidance of sin, On the</option>
<option>Awakening Sleepers to the Light of Christ</option>
<option>Awaking from sleep &c</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
