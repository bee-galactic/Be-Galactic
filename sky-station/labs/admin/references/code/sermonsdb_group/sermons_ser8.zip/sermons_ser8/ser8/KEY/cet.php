<html>
<head>
<title>cet</title>
<script language="javascript">
//from  ser-header_vsearch.php 


function my_cet_select() {
parent.document.search_form.denom.value="";//clear parent.denom field
parent.document.search_form.state.value="";//clear parent.state field
//alert ("cet test");
var sText = new String();

for ( i=0; i< document.cet_form.cet_select.length; i++ ) {
	if (document.cet_form.cet_select[i].selected == true ) {
		sText = document.cet_form.cet_select[i].value;
		}//end if
	}//end for
//document.search_form.cetitle.value = sText;
parent.document.search_form.cetitle.value = sText;
parent.document.search_form.smarkov_key.value= "cet";
parent.document.search_form.CSDval.value = sText;
parent.document.all.CSD.innerHTML="Cover Entry Title";
parent.document.search_form.smarkov_CSD.value= "Cover Entry Title";
//alert("sText="+sText);
}//end function my_cet_select 
</script>

<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body>

<form name="cet_form" >
<div class="form2">Cover Entry Title</div>
<?php
include "size_set_CILN.php";
print "<select name=\"cet_select\" size=\"$menu_size\" onchange=\"my_cet_select()\">";
?>
<option  value="" selected>none selected &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </option>

<option value="Archibald Simpson Manuscript Sermons">Archibald Simpson Manuscript Sermons</option>
<option value="The Cause of Children advocated">The Cause of Children advocated... [by Charles Pettigrew]</option>
<option value="Christmas%John Coleman">Christmas [Two Sermons by John Coleman]</option>
<option value="Five Sermons by George Goundril">Five Sermons by George Goundril</option>
<option value="Five Sermons by John Coleman">Five Sermons by John Coleman</option>
<option value="Hatch Dent">Four Sermons [by Hatch Dent]</option>
<option value="Fourtie eight sermons preached by Mr. Robert Paxton">Fourtie eight sermons preached by Mr. Robert Paxton</option>
<option value="The infant%s Cause advocated, from the Declarations of Christ by Charles Pettigrew">The infant's Cause advocated... [by Charles Pettigrew]</option>
<option value="Sermon %Notes% of Joseph Lord">[Sermon "Notes" of Joseph Lord]</option>
<option value="Sermons [by Archibald Simpson]">Sermons [by Archibald Simpson]</option>
<option value="Sermons by Enoch Green">[Sermons by Enoch Green.]</option>
<option value="Sermons by Jacob Ker">[Sermons by Jacob Ker]</option>
<option value="Sermons of Thomas Cradock">[Sermons of Thomas Cradock]</option>

<option value="Sermons on Various Occasions by the Rev. Paul Turquand, Rector of St. Mathews Parish, Volume I">Sermons... Rev. Paul Turquand...St. Mathews Parish, Vol I.</option>

<option value="Sermons on Various Occasions by the Rev. Paul Turquand, Rector of St. Mathews Parish, Volume II">Sermons... Rev. Paul Turquand...St. Mathews Parish, Vol II.</option>

<option value="Sermons on Various Occasions by the Rev. Paul Turquand, Rector of St. Mathews Parish, Volume III">Sermons... Rev. Paul Turquand...St. Mathews Parish, Vol III.</option>

<option value="Sermons preached after 1800 by John Durbarrow Blair">[Sermons preached after 1800 by John Durbarrow Blair]</option>
<option value="Sermons Vollume Thirteenth [by Archibald Simpson]">Sermons Vollume Thirteenth [by Archibald Simpson]</option>
<option value="Seven Mss. Sermons Delivered [by Samuel Frink] in Christ Church, Savannah. 1767-1771">Seven Mss. Sermons... S. Frink...Savannah. 1767-1771</option>

<option value="Textbook of Sermons heard by Richard Dozier in Westmoreland County, Virginia, 1771-1811">[Textbook of Sermons...R. Dozier...Westmoreland Co...Va]</option>

<option value="Three Sermons (1770) of an unidentified minister.">[Three Sermons (1770) of an unidentified minister.]</option>
<option value="Two Sermons (1775) by Charles Clay">[Two Sermons (1775) by Charles Clay]</option>
<option value="Two Sermons (1770) on Job 34 by Charles Clay">[Two Sermons (1770) on Job 34 by Charles Clay]</option>
<option value="Two Sermons (1799) by John Coleman">[Two Sermons (1799) by John Coleman]</option>
<option value="Two Sermons [by John Coleman (Acc. # 796)]">Two Sermons [by John Coleman (Acc. # 796)].</option>
<option value="Two Sermons [by John Coleman (Acc. # 799)]">Two Sermons [by John Coleman (Acc. # 799)].</option>
<option value="Two Sermons [by John Coleman (Acc. # 802)]">Two Sermons [by John Coleman (Acc. # 802)].</option>
<option value="Two sermons and a charge by Oliver Hart.">[Two sermons and a charge by Oliver Hart]</option>
<option value="Two Sermons by Edward Gantt">Two Sermons by Edward Gantt</option>
<option value="Two Sermons by Henry Addison">[Two Sermons by Henry Addison]</option>
<option value="[Two Sermons on the Death of Elder Lewis Lunsford by Henry Toler.]">[Two Sermons...by Henry Toler.]</option>
<option value="Two Sermons by John Coleman (Acc. # 770)">[Two Sermons by John Coleman (Acc. # 770)]</option>
<option value="Two Sermons by John Coleman (Acc. # 790)">[Two Sermons by John Coleman (Acc. # 790)]</option>
<option value="Two Sermons by John Coleman (Acc. # 793)">[Two Sermons by John Coleman (Acc. # 793)]</option>
<option value="[Two Sermons by Robert Preade (Read?).]">[Two Sermons by Robert Preade (Read?).]</option>
<option value="[Untitled Ms. Sermons 1686 and 1707.]">[Untitled Ms. Sermons 1686 and 1707.]</option>
<option value="Wilkinson, John--sermons">Wilkinson, John--sermons</option>
</select>
</form>

</body>
</html>
