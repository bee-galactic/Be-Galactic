<html>
<head>
<title>shd</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

stext=stext.replace("'","%");
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shd";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- D</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Daemoniac, The</option>
<option>Danger of consenting to smaller offences, The</option>
<option>Danger of ill advice, On the</option>
<option>Danger of impenitence, On the</option>
<option>Danger of Mocking Religion, The</option>
<option>Danger of relapsing into former Sins, On ye</option>
<option>Danger of riches, The</option>
<option>Dangerous to live in sin</option>
<option>Daniel & the Den of Lions</option>
<option>Dawson, Thomas, see Dawson, William</option>
<option>Day of death better than the day of one's birth</option>
<option>Day of judgment, On the</option>
<option>Days of Darkness, On</option>
<option>De Domini Cana.--un [sic. unum?] Deum</option>
<option>Death, On</option>
<option>Death, On Preparation for</option>
<option>Death: Fragments</option>
<option>Death as an Enemy, On</option>
<option>Death Cannot Praise God</option>
<option>Death of Edward Lloyd, On the</option>
<option>Death of the Just, On the</option>
<option>Death of the Old Year, On the</option>
<option>Decay of Christianity, The</option>
<option>Decree on the death of Pius VI</option>
<option>Dedication of a chapel to the Virgin Mary, On the</option>
<option>Dedication to God</option>
<option>Defective righteousness of the Scribes & Pharisees</option>
<option>Delaying to repent, On</option>
<option>Delight in the Lord, On</option>
<option>Delighting in God</option>
<option>Deliverance from sea dangers</option>
<option>Deliverance from sin, the End of Christ's coming</option>
<option>Delusions of the world, On the</option>
<option>Denial of the Existence of God, The</option>
<option>Departing from Iniquity</option>
<option>Descent into Hell, The</option>
<option>Description of Judgment Day</option>
<option>Desire of righteousness, Of the</option>
<option>Detraction, On</option>
<option>Devotion, On</option>
<option>Devotion to Saints and their relics, On</option>
<option>Devotion to the blessed virgin, On the</option>
<option>Difficulty of Salvation, On the</option>
<option>Discourse on Regulators in 1768</option>
<option>Discourse on ... Christ crucified, & the brazen Serpent</option>
<option>Discourses Delivered in Charleston</option>
<option>Disease of Sin</option>
<option>Displaying our light before men to the glory of God, On</option>
<option>Dispositions for confession</option>
<option>Dispositions necessary to receive ... penance</option>
<option>Dispute with Papists (1), On the</option>
<option>Dispute with Papists (2), On the</option>
<option>Dispute with Papists (3), On the</option>
<option>Dispute with Papists (4), On the</option>
<option>Distinction between Doers & mere Hearers of the word</option>
<option>Divine Assistance and Revelation, Concerning</option>
<option>Divine goodness, On</option>
<option>Divine Government the Joy of our World, The</option>
<option>Divine Inspiration of the Scriptures, On the</option>
<option>Divine Providence, Of a</option>
<option>Divine Wrath and Mercy, On</option>
<option>Divinity of Christ & the Truth of His Revelation, The</option>
<option>Doctrine, Morals, and Blasphemy, On</option>
<option>Doctrine of the Church, The</option>
<option>Doctrine of the Triune God, The</option>
<option>Doing honor to priests, On</option>
<option>Doubting, On</option>
<option>Draw nigh to God</option>
<option>Duties of a Xtian Minister, The</option>
<option>Duties of Parents: Ephesians, VI, 4</option>
<option>Duties Regarding the Sacrament of the Lord's Supper</option>
<option>Duty in the Receiving of the Lord's Supper</option>
<option>Duty of Man to his Creator, On the</option>
<option>Duty of Parents to Educate their Children, The</option>
<option>Duty of parents to their children, On the</option>
<option>Duty of Praise, On the</option>
<option>Duty of Submission to God, The</option>
<option>Duty of Xtians under afflictions</option>
<option>Duty to God, On</option>
<option>Duty towards children, On</option>
<option>Dying unto sin, and living unto righteousness</option>

<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
