<html>
<head>
<title>shf</title>
<script language="javascript">
function pchange(){
var stext=new String();
for (i=1;i<document.pform.pselect.length;i++) {
	if (document.pform.pselect[i].selected==true){
		stext= document.pform.pselect[i].text;
		stext=stext.replace("...","%");
		break;
		}
	}

//if(!confirm("stext="+stext))return;
stext=stext.replace("'","%");
stext=stext.replace("after easter","%after easter%");
//if(!confirm("stext="+stext))return;
parent.document.search_form.skey.value=stext;
parent.document.search_form.smarkov_key.value="shf";
document.pform.submit();
}//end function pchange()
</script>
<link rel="stylesheet" type="text/css" href="../ser.css" />
</head>
<body >
<form name="pform" id="id_pform">
<div class="form2">Short Title -- F</div>
<?php
include "size_set.php";
?>
<option  value="" selected>none selected</option>

<option>Faith</option>
<option>Faith, Hope, and Charity</option>
<option>Faith, On</option>
<option>Faith & Good Works, Upon</option>
<option>Faith & means necessary to a successful seeking of God</option>
<option>Faith and Patience, On</option>
<option>Faith in God, On</option>
<option>Faith the Gift of God. 1786</option>
<option>Faithful discharge of duty, On a</option>
<option>Faithful discharge of Duty, On a</option>
<option>Fallacy of certain specious doctrines detected, The</option>
<option>False Prophets</option>
<option>False prophets, On</option>
<option>Farewell Sermon</option>
<option>Fast (May 9, 1798), For the</option>
<option>Fast appointed by public authority, For a</option>
<option>Fast on account of the Philadelphia Epidemic</option>
<option>Fast Sermon, A</option>
<option>Fast Sermon Preached in 1756 on I Kings 21:29, A</option>
<option>Fasting, On</option>
<option>Fate of the Unrighteous</option>
<option>Fear, & service of god, The</option>
<option>Fear of God, On the</option>
<option>Fear of the Lord, On</option>
<option>Feast of All Saints, On the</option>
<option>Feast of all Saints, The</option>
<option>Feast of Corpus Christi, On the</option>
<option>Feast of Lent, On the</option>
<option>Feast of St. Ignatius, On the</option>
<option>Feast of the name of Jesus, On the</option>
<option>Feast of the Sacred Heart, On the</option>
<option>Fervent in Spirit</option>
<option>Festa Sancti P. Ignatii, In</option>
<option>First Commandment, On the</option>
<option>First commandment, On the</option>
<option>Five Sermons by George Goundril</option>
<option>Five Sermons by John Coleman</option>
<option>Folly of making a mock at sin</option>
<option>Fools make a Mock at Sin</option>
<option>For Advent</option>
<option>For Advent. The religion of the ancient & modern heathen</option>
<option>For Christmas</option>
<option>For of such is the Kingdom of Heaven</option>
<option>For the Epiphany</option>
<option>For the Thanksgiving-day, 1792</option>
<option>Force of Truth, The</option>
<option>Forgetting those things which are behind</option>
<option>Form with the power, The</option>
<option>Fornication and Uncleanness, On</option>
<option>Fortitude & resolution, of</option>
<option>Founded on the event of the Pool of Bethesda</option>
<option>Four Sermons [by Hatch Dent]</option>
<option>Fourtie eight sermons preached by Mr. Robert Paxton</option>
<option>Fraud, On</option>
<option>Free Schools, For the</option>
<option>Free Will, On</option>
<option>Freedom is a blessing</option>
<option>Frequent communion, On</option>
<option>Frequent communion after easter, On</option>
<option>Friends, On</option>
<option>Friendship compatible with Christianity</option>
<option>Friendship of the World, The</option>
<option>From John XII, 13, No. 1</option>
<option>Frontier-mission, For the</option>
<option>Fruit of the Spirit, The</option>
<option>Fruits meet for repentance</option>
<option>Fruits of the Cross</option>
<option>Fruits of the Spirit, The</option>
<option>Fruits required from men are proportioned to their advantages</option>
<option>Fruits ye criterion of character</option>
<option>Fulness of Time, The</option>
<option>Fund proposed in Canon 16th, For the</option>
<option>Funeral of a Young Girl, At the</option>
<option>Funeral of Anne Lloyd, On the</option>
<option>Funeral sermon</option>
<option>Funeral Sermon</option>
<option>Funeral Sermon for Benjamin Howard, Esq</option>
<option>Funeral Sermon for J. Wells</option>
<option>Funeral Sermon for Mrs. Nancy Austin</option>
<option>Funeral Sermon Jan. 1799</option>
<option>Funeral Sermon on Col. 3:3-4</option>
<option>Funeral Sermon on Job 14:2</option>
<option>Funeral Sermon on Proverbs 23:25</option>
<option>Funeral sermon on younger Robert Carter at Nomini</option>
<option>Funeral Sermon ... By the Reverend Father Robert Harding</option>
<option>Funerals, On</option>
<option>Future happiness, Of</option>
<option>Future Judgement, On a</option>
<option>Future state of existence & its consolations, On a</option>
<option  value="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &#x263a;</option>
</select>
</form>
</body>
</html>
