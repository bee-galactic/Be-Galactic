<?php
/*
  There are 2 sections in this page that have php code, the first, c1.php, accesses
 the database and updates the counter.
 The second, c2.php, pulls the total number of hits from the counter for a display hits.
*/
$dir = "sermons";
//$myscript=$_SERVER['PHP_SELF'];
$fn = "welcome.php";
//if ($fn=="c1.php") exit();
//init
$link2=$h=0;
$err=$dberr="";
//if ($filename) Clean($filename);
//if ($)  Clean($);
require "dblink.php";
$link2=DBLink('localhost','hitcount','hcuser','vl3f578');
function DoQuery($query,$link)
 {
 if ( ! mysql_query( $query, $link ))
   {
   $dberror = mysql_error();
    $dberr = "$dberror";
    return($dberr);
    }
 }
include "counthit.php";
CountHit($link2,$dir,$fn,1);
?>

