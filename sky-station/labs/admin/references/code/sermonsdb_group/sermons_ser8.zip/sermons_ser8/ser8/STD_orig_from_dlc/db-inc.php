<?php
/*
 db-inc.php
 db setup include
 must be custom and LOCAL to each project/user

 cricket_ser.ser2_test2 on dlc

*/
/*originals*/
/*
$dbuser = "seruser";
$dbpass = "k6wi43k6";
$db = "ser";
*/

/* cricket_ser.ser do not use except for testing */
$dbuser = "cricket";
$dbpass = "FXMn5n3";
$db = "cricket_ser";
/**/
$link = mysql_connect( "localhost", $dbuser, $dbpass );
if ( ! $link ) 	die( "Couldn't connect to MySQL" );
mysql_select_db( $db, $link ) || die( "Could not open $db: , mysql_error()" );

?>
