<?php
#size_set_CILN.php
#size set for CET-IBR-LOC-NA


$menu_size="20";
$menu_size="14";

?>
