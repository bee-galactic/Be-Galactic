#exec_ingest3.py
#from
#exec_ingest.py 
#purpose - ingest one issue of alumnus

#developed in directory
#/home/cdeane/pubact/ALUMNUS/py/a91

#tested on dlwork with input data
#/gwork/cdeane/ALUM_FILES/ALUM/b2000test


#run by root, $DRUPAL_HOME

#commandline: python exec_ingest.py source_dir
#             python exec_ingest.py /gwork/cdeane/ALUM_FILES/ALU

#
#commandline: python exec_ingest2.py source_dir
#             python exec_ingest2.py /gwork/cdeane/ALUM_FILES/ALUM/b2000test
   


#########MAIN###############################
import os, sys
import datetime #for datetime
timestamp0=datetime.datetime.now()
logtime0 = str(timestamp0)

server  = "digital"
msg_server="\n             server: "+server+""
dashline = "----------------------------------------------"
dashline2 = "----------------------------------------------\n"
dashline3 = "\n----------------------------------------------\n"

cmpdate0 = logtime0.split(" ")
cmpdate1 = str(cmpdate0[0]).replace("-","")
cmpdate2 = str(cmpdate1[2:])+"_"


pgm           = sys.argv[0] #name of pgm
if len(sys.argv)<2:
        print "usage: python "+pgm+" source_dir  "
        sys.exit(0)
        #
	#
source_dir    = sys.argv[1] #name of source directory   ###F 
#source_year   = sys.argv[2] #4 digit name of year   ###F 
msg_source_dir ="\n   source_directory: "+source_dir+""


cmdline=">> python"

for item in sys.argv:
        s=item
        cmdline = cmdline +" "+item
        #
        #

print dashline2+logtime0+"\n"+cmdline

if (os.path.isdir(source_dir) == False) :
        print "source_dir: no such file: "+source_dir
        print "usage: "+cmdline
        sys.exit(0)
        #
        #

prefix_ibbp = "drush -v   --parent=collections:alumnus  --namespace=alumnus  --user=cdeane  --uri=http://localhost ibbp  --type=directory  --content-models=islandora:bookCModel  --strict=0   --create_pdfs=TRUE --target="

cmd_ingest = "drush -v   --user=cdeane  --uri=http://localhost islandora_batch_ingest ;"

cmd_date   = "date ;"


Flist = os.listdir(source_dir)
Flist.sort()

NPAGES=0
ctItem = 0
Mall =  dashline2+logtime0+"\n"+cmdline +dashline3
for item in Flist:
	itemtimestamp0=datetime.datetime.now()
	s0 = item
	s1 = s0.replace("\n","")
	LogName = "/gwork/cdeane/LOG/"+server+"/"+cmpdate2+"ingest_"+server+"_"+s1
	##X##LogName = "./localLOG/"+cmpdate2+"ingest_"+s1
	os.system(cmd_date)
	fullpath = source_dir+"/"+s1
	print dashline2+"LogName="+LogName+dashline3+"\nitemtimestamp0:"+str(itemtimestamp0)+"\ndirectory full path: "+fullpath
	Dlist =os.listdir(fullpath)
	for item in Dlist:
		d0=item
		d1=d0.replace("\n","")
		IssueName = d1
		fullpathsub = fullpath+"/"+d1
		print "\ndirectory fullpathsub: "+fullpathsub
		Elist=os.listdir(fullpathsub)
		Elen  =len(Elist) -1
		#print "pages: "+str(Elen)
		#
		#
        cmd_ibbp = prefix_ibbp+fullpath+"/ ;"
	print ">>>>> "+cmd_ibbp
	os.system(cmd_ibbp)
	print ">>>>> "+cmd_ingest
	os.system(cmd_ingest)
	#print ">>>>> "+cmd_date
	##X##os.system(cmd_date)
	itemtimestamp1=datetime.datetime.now()
	itemduration=itemtimestamp1-itemtimestamp0
	item_dura_array=str(itemduration).split(":")
	item_tot_secs= float(item_dura_array[0])*60.0*60.0 + float(item_dura_array[1])*60.0+float(item_dura_array[2])
	item_secs_per_page=float(item_tot_secs)/float(Elen)
	msg0="\n Issue:"+IssueName +dashline3
	msg1= "\ndirectory full path: "+fullpath +""
	msg1a="\n   item start time: "+str(itemtimestamp0)+""
	msg1b="\n  item finish time: "+str(itemtimestamp1)+""
	msg2 ="\n item process time: "+str(itemduration) +""
	msg3 ="\n             pages: "+str(Elen) + ""
	msg4 ="\n  seconds per page: "+str(item_secs_per_page)+"\n"
	msg_both_cmds = ">>>>> "+cmd_ibbp+"\n>>>>> "+cmd_ingest
	print dashline2+"\n"+msg_both_cmds+dashline3+msg0+msg_server+msg_source_dir+"\n"+msg1+"\n"+msg1a+"\n"+msg1b+"\n"+msg2+"\n"+msg3+"\n"+msg4
	msg5 = dashline3+"TEST PRINT"
	Pall = dashline2+msg_both_cmds+dashline3+msg0+msg_server+msg_source_dir+msg1+msg1a+msg1b+msg2+msg3+msg4+dashline
	Mall = Mall+Pall+dashline3
	L = open(LogName,"w")
	L.write(Pall)
	L.close()
	s3index = s1.find("_")+5
	s4 = s1[0:s3index]
	NPAGES = NPAGES+Elen
	if ctItem <1:
		first_s4 = str(s4)+"_"
		#
		#
	ctItem=ctItem+1
	#print "s4="+str(s4)
	#
	#


final_log_file = "/gwork/cdeane/LOG/"+server+"/"+cmpdate2+"ingest_"+server+"_summary_"+first_s4+"to_"+s4
##X##final_log_file = "./localLOG/"+cmpdate2+"ingest_"+server+"_summary_"+first_s4+"to_"+s4

#LogName = "/gwork/cdeane/LOG/"+cmpdate2+"ingest_"+s1

timestamp1=datetime.datetime.now()
duration=timestamp1-timestamp0
# duration: 0:00:00.012366
dura_array = str(duration).split(":")
total_seconds= float(dura_array[0])*60.0*60.0 + float(dura_array[1])*60.0+float(dura_array[2])
seconds_per_page=float(total_seconds)/float(NPAGES)
fini1= "\n       begin time: "+str(timestamp0)
fini2= "\n         end time: "+str(timestamp1)
fini3= "\n         duration: "+str(duration)
fini4= "\n      total pages: "+str(NPAGES)
fini5= "\n seconds per page: "+str(seconds_per_page)
fini6= "\n\n final_log_file:"+final_log_file+"\n"         
fini7=cmdline+"\n"
fini8=msg_both_cmds +"\n"

print dashline2+dashline2+dashline2+"\nINGEST SUMMARY\n"+dashline2
print msg_server+msg_source_dir
print fini1
print fini2
print fini3
print fini4
print fini5
print fini6
print fini7

Mall = Mall+dashline2+dashline2+dashline3+"INGEST SUMMARY"+dashline3
Mall = Mall+fini7+dashline2+fini8+dashline+msg_server+msg_source_dir+fini1+fini2+fini3+fini4+fini5+fini6+dashline2 +fini7
M= open(final_log_file,"w")
M.write(Mall)
M.close()


sys.exit(0)

